package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata;

import org.junit.Assert;
import org.junit.Test;

public class FlatNumberValidatorTest {
    private FlatNumberValidator flatNumberValidator = new FlatNumberValidator();

    @Test
    public void shouldBeValidWhenIsSimplyNumber() {
        Assert.assertTrue(testValidation("213"));
    }

    @Test
    public void shouldBeValidWhenIsNumberWithFlat() {
        Assert.assertTrue(testValidation("213/3A"));
    }

    @Test
    public void shouldBeInValidWhenIsNumberWithOnlySlash() {
        Assert.assertFalse(testValidation("213/"));
    }

    @Test
    public void shouldBeInValidWhenEmpty() {
        Assert.assertFalse(testValidation(""));
    }

    private boolean testValidation(String flatNumber) {
        return flatNumberValidator.isValid(flatNumber);
    }
}