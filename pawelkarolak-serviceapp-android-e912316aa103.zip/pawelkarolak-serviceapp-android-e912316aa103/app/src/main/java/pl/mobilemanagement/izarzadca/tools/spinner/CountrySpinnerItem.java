package pl.mobilemanagement.izarzadca.tools.spinner;


import java.util.ArrayList;
import java.util.List;

import pl.mobilemanagement.izarzadca.common.model.entity.Country;

public class CountrySpinnerItem implements SpinnerItem {
    private Country country;

    private CountrySpinnerItem(Country country) {
        this.country = country;
    }

    public static List<CountrySpinnerItem> createSpinnerItems(List<Country> countries) {
        final List<CountrySpinnerItem> countrySpinnerItems = new ArrayList<>();
        for (Country country : countries) {
            countrySpinnerItems.add(new CountrySpinnerItem(country));
        }
        return countrySpinnerItems;
    }

    public Country getCountry() {
        return country;
    }

    @Override
    public String toString() {
        return country.name;
    }
}