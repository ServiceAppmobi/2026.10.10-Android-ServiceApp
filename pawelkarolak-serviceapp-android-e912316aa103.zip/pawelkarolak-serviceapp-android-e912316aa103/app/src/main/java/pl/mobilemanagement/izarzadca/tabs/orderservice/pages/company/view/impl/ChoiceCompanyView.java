package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.impl;

import static pl.mobilemanagement.izarzadca.common.map.MapHelper.mapViewObservable;

import android.content.Context;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.map.MapCircleFactory;
import pl.mobilemanagement.izarzadca.common.map.MapData;
import pl.mobilemanagement.izarzadca.common.map.MapHelper;
import pl.mobilemanagement.izarzadca.common.map.MapMarkerStorage;
import pl.mobilemanagement.izarzadca.common.map.MapWithPos;
import pl.mobilemanagement.izarzadca.common.user.profile.UserService;
import pl.mobilemanagement.izarzadca.databinding.OrderServiceCompanyChoiceBinding;
import pl.mobilemanagement.izarzadca.tabs.orderservice.OrderBuilder;
import pl.mobilemanagement.izarzadca.tabs.orderservice.api.OrderServiceApi;
import pl.mobilemanagement.izarzadca.tabs.orderservice.di.DaggerOrderComponent;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.BaseView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.order.OrderRequest;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider.ServiceProvider;
import pl.mobilemanagement.izarzadca.tools.FileHelper;
import pl.mobilemanagement.izarzadca.tools.LCE;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;
import timber.log.Timber;

public class ChoiceCompanyView extends BaseView implements LCE<ServiceProvider> {
    private final CompanyOpinionDialog companyOpinionDialog;
    public Subscription detailClickObservable;

    @Inject
    OrderServiceApi orderServiceApi;

    @Inject
    UserService userService;

    private ChoiceServiceAdapter choiceServiceAdapter;
    private Subscription getServiceProvidersSubscription, userPositionSubscription, mapMarkersSubsription, makeOrderSubscription;

    private final OrderServiceCompanyChoiceBinding binding;

    private final Action1<String> changeButtonText;

    public ChoiceCompanyView(Context context, Action1<String> changeButtonText) {
        super(context);
        this.changeButtonText = changeButtonText;
        DaggerOrderComponent.builder().applicationComponent(App.component).build().inject(this);
        binding = OrderServiceCompanyChoiceBinding.bind(getChildAt(0));
        companyOpinionDialog = new CompanyOpinionDialog(getContext(), orderServiceApi);
    }

    @Override
    public void onNext() {
        super.onNext();
        final List<ServiceProvider> selectedProviders = choiceServiceAdapter.getSelectedProviders();
        if (selectedProviders.isEmpty()) {
            Validator validator = new Validator().addError(getString(R.string.not_selected_service_provider));
            ValidationErrorDialogHelper.show(getContext(), validator);
        } else {
            final OrderBuilder orderBuilder = pageViewListener.getOrderBuilder();
            orderBuilder.setProviders(selectedProviders);
            sendRequestOrder();
        }
    }

    private void sendRequestOrder() {
        final OrderBuilder orderBuilder = pageViewListener.getOrderBuilder();

        Observable<OrderRequest> orderRequestSingle = Observable.defer(() -> {
            List<String> allFiles = orderBuilder.getPhotos().getUriList();
            for (int i = 0; i < allFiles.size(); i++) {
                String inputFileUri = allFiles.get(i);
                if (inputFileUri != null) {
                    File cacheFile = FileHelper.cacheGalleryFile(getContext(), inputFileUri);
                    orderBuilder.getPhotos().setPhoto(i + 1, cacheFile.getAbsolutePath());
                }
            }

            OrderRequest order = orderBuilder.buildOrderRequest();
            return Observable.just(order);
        });

        makeOrderSubscription = orderRequestSingle
                .flatMap(orderRequest -> orderServiceApi.sendOrderService(orderRequest))
                .compose(Rx.applySchedulers())
                .compose(ProgressDialog.create(getContext()))
                .subscribe(aVoid -> pageViewListener.finishOrder(orderBuilder.buildSummary())
                        , throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    @Override
    protected void onAttached() {
        initCompanyAdapter();
        MapHelper.initMapView(binding.mapView);

        changeButtonText.call(getString(R.string.order_service_choose_companies));

        final Observable<GoogleMap> googleMapObservable =
                mapViewObservable(binding.mapView)
                        .zipWith(
                            userService.getProfilePreferOnlyCache().compose(Rx.applySchedulers()),
                            (googleMap, userProfile) -> new MapWithPos(googleMap, userProfile.lat, userProfile.lng)
                        )
                        .doOnNext(MapHelper::markCurrentUserPosition)
                        .map(mapWithUser -> mapWithUser.googleMap)
                        .cache();

        final OrderBuilder orderBuilder = pageViewListener.getOrderBuilder();
        final Observable<List<ServiceProvider>> serviceProviderObservable =
                orderServiceApi
                        .getServiceProviders(orderBuilder.buildProviderRequest())
                        .compose(Rx.applySchedulers())
                        .map(serviceProviderResponse -> serviceProviderResponse)
                        .compose(Rx.applyLCE(this))
                        .share();

        detailClickObservable = choiceServiceAdapter.companyDetailClickObservable()
                .subscribe(serviceProvider -> companyOpinionDialog.show(serviceProvider.id));

        userPositionSubscription = choiceServiceAdapter.companyClickObservable()
                .withLatestFrom(googleMapObservable, (serviceProvider, googleMap) -> new MapWithPos(googleMap, serviceProvider.getLatLng()))
                .subscribe(mapWithPos ->
                                mapWithPos.googleMap.animateCamera(CameraUpdateFactory.newLatLng(mapWithPos.userPos)),
                        throwable -> Timber.e(throwable, "On company click error"));

        MapMarkerStorage mapMarkerStorage = new MapMarkerStorage();
        mapMarkersSubsription =
                serviceProviderObservable
                    .doOnNext(mapData -> mapMarkerStorage.removePreviousMarkers())
                    .switchMap(serviceProviders -> Observable.zip(createObservablePoint(serviceProviders), googleMapObservable, MapData::new))
                    .subscribe(
                            data -> mapMarkerStorage.addMarkers(data.googleMap, data.markerOptionList),
                            throwable -> ApiErrorDialogHelper.show(getContext(), throwable),
                            () -> Timber.v("Completed")
                    );

        getServiceProvidersSubscription = serviceProviderObservable
                .subscribe(this::setData, throwable -> showConnectionError());
     }

    private Observable<List<MarkerOptions>> createObservablePoint(List<ServiceProvider> serviceProviders) {
        return Observable.just(mapToGeoPoints(serviceProviders))
                .map(latLng -> MapCircleFactory.createServiceOrdersMarkers(getContext(), latLng));
    }

    private List<LatLng> mapToGeoPoints(List<ServiceProvider> serviceProviders) {
        final List<LatLng> list = new ArrayList<>();
        for (ServiceProvider serviceProvider : serviceProviders) {
            list.add(serviceProvider.getLatLng());
        }
        return list;
    }

    private void initCompanyAdapter() {
        choiceServiceAdapter = new ChoiceServiceAdapter(isNotSelectedCompany -> {
            if (isNotSelectedCompany) {
                changeButtonText.call(getString(R.string.order_service_choose_companies));
            } else {
                changeButtonText.call(getString(R.string.order_service_choose_company));
            }
        });
        binding.recyclerView.listRecyclerView.setAdapter(choiceServiceAdapter);
    }

    @Override
    protected void onDetached() {
        MapHelper.safeDestroyMapView(binding.mapView);
        Rx.safeUnsubscribe(getServiceProvidersSubscription, userPositionSubscription, mapMarkersSubsription,
                makeOrderSubscription);
        companyOpinionDialog.hide();
    }

    @Override
    protected int titleResource() {
        return R.string.order_service_select_company;
    }

    @Override
    protected int layoutResource() {
        return R.layout.order_service_company_choice;
    }

    @Override
    public void showProgressBar() {
        binding.recyclerView.listProgress.setVisibility(VISIBLE);
    }

    @Override
    public void hideProgressBar() {
        binding.recyclerView.listProgress.setVisibility(GONE);
    }

    @Override
    public void hideError() {
        binding.recyclerView.listError.setVisibility(GONE);
    }

    @Override
    public void showEmptyListError() {
        binding.recyclerView.listError.setVisibility(VISIBLE);
        binding.recyclerView.listError.setText(R.string.order_service_select_company_cannot_find_providers);
    }

    @Override
    public void showConnectionError() {
        binding.recyclerView.listError.setVisibility(VISIBLE);
        binding.recyclerView.listError.setText(R.string.order_service_select_company_cannot_download_providers);
    }

    @Override
    public void setData(List<ServiceProvider> data) {
        choiceServiceAdapter.setDataList(data);
    }
}
