package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Date;

public class GetEmails implements Serializable {
    @SerializedName("createAt")
    public Date createAt;

    @SerializedName("emailFrom")
    public String emailFrom;
    @SerializedName("emailTo")
    public String emailTo;
    @SerializedName("topic")
    public String topic;
    @SerializedName("messageBody")
    public String messageBody;

}
