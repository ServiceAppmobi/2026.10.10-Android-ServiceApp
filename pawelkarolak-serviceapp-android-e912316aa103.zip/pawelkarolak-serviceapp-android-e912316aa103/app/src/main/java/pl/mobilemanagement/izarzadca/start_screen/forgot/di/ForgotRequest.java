package pl.mobilemanagement.izarzadca.start_screen.forgot.di;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.PersonalInfoController;

/**
 * Created by katak on 24.01.2017.
 */

public class ForgotRequest {
    @Expose
    @SerializedName("login")
    private String login;

    @Expose
    @SerializedName("email")
    private String email;

    public ForgotRequest(String loginOrEmail) {
        if(PersonalInfoController.isValidEmail(loginOrEmail))
            email = loginOrEmail;
        else
            login = loginOrEmail;
    }

    public String getUsername() {
        return login;
    }

    public String getEmail() {
        return email;
    }
}
