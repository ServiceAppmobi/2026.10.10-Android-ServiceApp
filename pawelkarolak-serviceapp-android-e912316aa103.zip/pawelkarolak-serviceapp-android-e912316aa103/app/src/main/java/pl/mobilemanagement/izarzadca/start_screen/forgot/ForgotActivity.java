package pl.mobilemanagement.izarzadca.start_screen.forgot;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.afollestad.materialdialogs.MaterialDialog;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.databinding.ActivityForgotBinding;
import pl.mobilemanagement.izarzadca.start_screen.forgot.di.DaggerForgotComponent;
import pl.mobilemanagement.izarzadca.start_screen.forgot.di.ForgotRequest;
import pl.mobilemanagement.izarzadca.start_screen.forgot.di.ForgotServiceApi;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.EditTextHelper;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;

public class ForgotActivity extends AppCompatActivity {

    EditText login;

    @Inject
    TokenDataSource tokenDataSource;

    @Inject
    ForgotServiceApi forgotServiceApi;
    private MaterialDialog progressDialog;
    private EarthlyLoadingDialog earthlyDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DaggerForgotComponent.builder().applicationComponent(App.component).build().inject(this);

        ActivityForgotBinding binding = ActivityForgotBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        login = binding.inputLoginTxt;
        binding.forgotButton.setOnClickListener(v -> onLoginClick());
        binding.backArrow.setOnClickListener(v -> finish());
    }

    private void onLoginClick() {
        final String loginOrEmail = EditTextHelper.getText(this.login);

        final ForgotRequest userForgotRequest = new ForgotRequest(loginOrEmail);

        forgotServiceApi.userForgot(userForgotRequest)
                .compose(Rx.applySchedulers())
                .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getSupportFragmentManager()))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                .subscribe(loginResponse -> {
                    Toast.makeText(getApplicationContext(), R.string.show_recovery_message, Toast.LENGTH_LONG).show();
                    finish();
                }, e -> ApiErrorDialogHelper.show(this, e));
    }
}
