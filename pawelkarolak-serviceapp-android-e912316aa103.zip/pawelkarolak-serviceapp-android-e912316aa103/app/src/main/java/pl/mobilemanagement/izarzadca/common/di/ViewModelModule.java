package pl.mobilemanagement.izarzadca.common.di;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import dagger.Binds;
import dagger.Module;
import dagger.multibindings.IntoMap;
import pl.mobilemanagement.izarzadca.start_screen.login.LoginViewModel;
import pl.mobilemanagement.izarzadca.tabs.MainActivityViewModel;
import pl.mobilemanagement.izarzadca.tabs.file_manager.FileManagerViewModel;

@Module
abstract class ViewModelModule {
    @Binds
    abstract ViewModelProvider.Factory bindViewModelFactory(DaggerViewModelFactory factory);

    @Binds
    @IntoMap
    @ViewModelKey(LoginViewModel.class)
    abstract ViewModel provideLoginViewModel(LoginViewModel loginViewModel);

    @Binds
    @IntoMap
    @ViewModelKey(MainActivityViewModel.class)
    abstract ViewModel provideMainActivityViewModel(MainActivityViewModel mainActivityViewModel);

    @Binds
    @IntoMap
    @ViewModelKey(FileManagerViewModel.class)
    abstract ViewModel provideFileManagerViewModel(FileManagerViewModel fileManagerViewModel);
}
