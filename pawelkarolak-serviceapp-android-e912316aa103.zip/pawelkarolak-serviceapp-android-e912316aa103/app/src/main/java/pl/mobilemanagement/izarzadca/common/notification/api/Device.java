package pl.mobilemanagement.izarzadca.common.notification.api;

public class Device {
    public final String handle;
    public final String deviceId;
    public final boolean isActive;
    public final String platform = "Android";

    public Device(String handle, String deviceId, boolean isActive) {
        this.handle = handle;
        this.deviceId = deviceId;
        this.isActive = isActive;
    }
}
