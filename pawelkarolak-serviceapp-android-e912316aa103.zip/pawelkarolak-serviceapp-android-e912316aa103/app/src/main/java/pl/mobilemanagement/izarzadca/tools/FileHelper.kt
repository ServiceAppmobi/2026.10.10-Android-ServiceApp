package pl.mobilemanagement.izarzadca.tools

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import androidx.core.net.toUri
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

object FileHelper {

    @JvmStatic
    fun cacheGalleryFile(context: Context, inputFileUri: String): File {
        if (!inputFileUri.startsWith(ContentResolver.SCHEME_CONTENT)) {
            return File(inputFileUri)
        }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val file = File(context.cacheDir, "$timeStamp.jpg")
        file.createNewFile()
        val inputStream = context.contentResolver.openInputStream(inputFileUri.toUri())
        inputStream.use {
            file.outputStream().use { output ->
                inputStream?.copyTo(output)
            }
        }
        return file
    }

}