package pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneregister;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PhoneVerification {
    @Expose
    @SerializedName("phone")
    private String phoneNumber;

    PhoneVerification(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
