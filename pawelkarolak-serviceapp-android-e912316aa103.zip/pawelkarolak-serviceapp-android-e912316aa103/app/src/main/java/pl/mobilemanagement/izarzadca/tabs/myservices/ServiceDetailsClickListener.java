package pl.mobilemanagement.izarzadca.tabs.myservices;

import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderServiceType;

public interface ServiceDetailsClickListener {

    void onOrderDetailsClick(String orderId, OrderServiceType orderType);

}
