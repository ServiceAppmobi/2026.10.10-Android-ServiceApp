package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.impl;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.RowAdapter;
import pl.mobilemanagement.izarzadca.databinding.ProviderRowBinding;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider.ServiceProvider;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.SelectedCompanyProviderChangedListener;
import rx.Observable;
import rx.subjects.PublishSubject;

class ChoiceServiceAdapter extends RowAdapter<ServiceProvider, ChoiceServiceAdapter.VH> {
    private final PublishSubject<ServiceProvider> clickListener = PublishSubject.create();
    private final PublishSubject<ServiceProvider> detailClick = PublishSubject.create();

    private final SelectedCompanyProviderChangedListener listener;
    private final HashSet<ServiceProvider> selectedProviders = new HashSet<>();

    public ChoiceServiceAdapter(SelectedCompanyProviderChangedListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ProviderRowBinding binding = ProviderRowBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new VH(binding);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        holder.bind(getItem(position));
    }

    @Override
    public void setDataList(List<ServiceProvider> data) {
        super.setDataList(data);
        updateSelectedProviders();
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).id.hashCode();
    }

    private boolean isProviderSelected(ServiceProvider serviceProvider) {
        return selectedProviders.contains(serviceProvider);
    }

    private void updateSelectedProviders() {
        listener.onSelectedProvidersChange(selectedProviders.isEmpty());
    }

    public Observable<ServiceProvider> companyClickObservable() {
        return clickListener;
    }

    public List<ServiceProvider> getSelectedProviders() {
        if (selectedProviders.isEmpty()) {
            return getDataList();
        } else {
            return new ArrayList<>(selectedProviders);
        }
    }

    public Observable<ServiceProvider> companyDetailClickObservable() {
        return detailClick.asObservable();
    }


    class VH extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final ProviderRowBinding binding;
        private ServiceProvider serviceProvider;

        VH(ProviderRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            binding.getRoot().setOnClickListener(this);
            binding.providerDetails.setOnClickListener(this);
        }

        public void bind(final ServiceProvider serviceProvider) {
            this.serviceProvider = serviceProvider;

            final String title = serviceProvider.name + " " + serviceProvider.distance;
            binding.providerName.setText(title);

            binding.providerAddress.setText(String.format("%s %s", serviceProvider.postalCode, serviceProvider.city));

            final String formattedOpinionCount = getFormattedOpinionCount(serviceProvider);
            binding.providerOpinionCount.setText(formattedOpinionCount);

            binding.providerOpinionStar.setRating(serviceProvider.rating);

            final boolean isSelected = isProviderSelected(serviceProvider);

            binding.getRoot().setSelected(isSelected);
        }

        @Override
        public void onClick(View v) {
            int id = v.getId();
            if (id == R.id.providerDetails) {
                detailClick.onNext(serviceProvider);
            } else if (v == binding.getRoot()) {
                clickListener.onNext(serviceProvider);
                final boolean providerSelected = isProviderSelected(serviceProvider);
                if (providerSelected) {
                    selectedProviders.remove(serviceProvider);
                } else {
                    selectedProviders.add(serviceProvider);
                }
                updateSelectedProviders();
                binding.constraintLayout.setSelected(!providerSelected);
            }
        }

        @NonNull
        private String getFormattedOpinionCount(ServiceProvider serviceProvider) {
            final String opinion = binding.getRoot().getContext().getString(R.string.service_order_place, serviceProvider.ratingsNumber);
            return "(" + opinion + ")";
        }
    }
}
