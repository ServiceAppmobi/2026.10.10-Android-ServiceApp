package pl.mobilemanagement.izarzadca.tabs.myorders.di;

import dagger.Module;
import dagger.Provides;
import pl.mobilemanagement.izarzadca.common.di.api.Auth;
import pl.mobilemanagement.izarzadca.tabs.myorders.api.ClientOrdersApi;
import retrofit2.Retrofit;

@Module
public class MyOrdersModule {

    @Provides
    @MyOrdersScope
    public ClientOrdersApi providesMyOrdersApi(@Auth Retrofit retrofit) {
        return retrofit.create(ClientOrdersApi.class);
    }
}