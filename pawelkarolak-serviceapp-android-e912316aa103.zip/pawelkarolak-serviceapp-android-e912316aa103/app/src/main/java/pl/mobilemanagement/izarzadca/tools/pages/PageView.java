package pl.mobilemanagement.izarzadca.tools.pages;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import androidx.annotation.LayoutRes;
import androidx.annotation.StringRes;
import pl.mobilemanagement.izarzadca.R;

public abstract class PageView<T> extends LinearLayout {
  protected PageListener<T> pageViewListener;

  private boolean isDetached = true;

  public PageView(Context context, AttributeSet attrs) {
    super(context, attrs);
    init();
  }

  public PageView(Context context) {
    super(context);
    init();
  }

  protected final String getString(@StringRes int stringRes) {
    return getContext().getString(stringRes);
  }

  private void init() {
    inflate(getContext(), layoutResource(), this);
  }

  public final void viewAttach(PageListener pageListener) {
    this.pageViewListener = pageListener;
    isDetached = false;
    onAttached();
  }

  protected void onAttached() {

  }

  public final void viewDetach() {
    pageViewListener = null;
    isDetached = true;
    onDetached();
  }

  protected void onDetached() {

  }

  final protected T getCurrentBuilder() {
    return pageViewListener.getCurrentBuilder();
  }

  public final CharSequence getTitle(int position) {
    return getContext().getString(R.string.registration_title, position, getTitle());
  }

  private CharSequence getTitle() {
    return getContext().getString(titleResource());
  }

  @StringRes
  protected abstract int titleResource();

  @LayoutRes
  protected abstract int layoutResource();

  public boolean isDetached() {
    return isDetached;
  }
}
