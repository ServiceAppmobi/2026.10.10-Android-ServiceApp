package pl.mobilemanagement.izarzadca.tools;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Validator {
    final private List<String> errors = new ArrayList<>();

    public boolean isValid() {
        return errors.isEmpty();
    }

    public Validator addError(String errorMsg) {
        errors.add(errorMsg);
        return this;
    }
    public void addError(List<String> errorMsg) {
        errors.addAll(errorMsg);
    }

    public List<String> getErrors() {
        return Collections.unmodifiableList(errors);
    }
    public Validator validateWith(Validator validator) {
        errors.addAll(validator.getErrors());
        return this;
    }
}
