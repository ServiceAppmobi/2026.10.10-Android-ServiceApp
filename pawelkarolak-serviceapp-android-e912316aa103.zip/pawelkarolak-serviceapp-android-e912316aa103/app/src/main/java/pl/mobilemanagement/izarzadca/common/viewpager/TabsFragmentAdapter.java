package pl.mobilemanagement.izarzadca.common.viewpager;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import java.util.List;

public class TabsFragmentAdapter<T extends Fragment> extends FragmentPagerAdapter {
  private final List<T> fragments;

  public TabsFragmentAdapter(@NonNull FragmentManager fm, @NonNull List<T> tabFragments) {
    super(fm);
    this.fragments = tabFragments;
  }

  @Override
  public T getItem(int position) {
    return fragments.get(position);
  }

  @Override
  public int getCount() {
    return fragments.size();
  }
}