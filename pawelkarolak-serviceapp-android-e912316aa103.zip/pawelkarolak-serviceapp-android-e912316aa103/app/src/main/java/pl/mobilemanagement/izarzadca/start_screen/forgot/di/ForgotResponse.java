package pl.mobilemanagement.izarzadca.start_screen.forgot.di;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import pl.mobilemanagement.izarzadca.common.user.AccountType;

/**
 * Created by katak on 24.01.2017.
 */

public class ForgotResponse {


}