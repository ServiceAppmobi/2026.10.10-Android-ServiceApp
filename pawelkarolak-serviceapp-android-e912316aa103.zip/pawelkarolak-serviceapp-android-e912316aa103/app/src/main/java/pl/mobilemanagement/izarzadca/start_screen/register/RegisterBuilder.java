package pl.mobilemanagement.izarzadca.start_screen.register;

import java.io.Serializable;

import pl.mobilemanagement.izarzadca.common.invite.contact.InviteType;
import pl.mobilemanagement.izarzadca.common.model.api.CustomerRegister;
import pl.mobilemanagement.izarzadca.common.model.entity.AccountTypeName;
import pl.mobilemanagement.izarzadca.common.model.entity.Country;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.CompanyInfo;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model.PersonalData;

public class RegisterBuilder implements Serializable {
    private String phoneNumber;
    private String userName;
    private String password;
    private String verificationCode;
    private PersonalData personalData;
    private Country country;
    private AccountTypeName accountTypeName;
    private Double longitude;
    private Double latitude;

    public boolean createdByPropertyManager = false;
    public String accessToken = "";
    public InviteType inviteType = null;

    public CompanyInfo companyInfo = null;

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public PersonalData getPersonalData() {
        return personalData;
    }

    public void setPersonalData(PersonalData personalData) {
        this.personalData = personalData;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public AccountTypeName getAccountTypeName() {
        return accountTypeName;
    }

    public void setAccountTypeName(AccountTypeName accountTypeName) {
        this.accountTypeName = accountTypeName;
    }

    public String getPhoneNumberWithPrefix() {
        return country.areaCode + phoneNumber;
    }

    public CustomerRegister createCustomerRegisterModel() {
        return CustomerRegister.create(this);
    }

    public void setLocation(double altitude, double longitude) {
        this.latitude = altitude;
        this.longitude = longitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }
}
