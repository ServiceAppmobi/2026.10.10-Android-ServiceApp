package pl.mobilemanagement.izarzadca.start_screen.register;

import android.app.Activity;
import android.content.Context;

import pl.mobilemanagement.izarzadca.start_screen.login_or_register.SocialData;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.CompanyDataView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneactivate.PhoneActivateView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneregister.PhoneNumberView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.UserDataView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.PagesAdapter;
import pl.mobilemanagement.izarzadca.tools.pages.PageListener;
import pl.mobilemanagement.izarzadca.tools.pages.PageView;

public class RegisterPagerAdapter extends PagesAdapter<RegisterBuilder> {
    private final Context context;
    private final Activity activity;

    private final SocialData socialData;

    private final LocationListener locationListener;

    public RegisterPagerAdapter(
            Context context,
            OnTitleChangedListener titleChangedListener,
            PageListener<RegisterBuilder> pageViewListener,
            LocationListener locationListener,
            Activity activity,
            SocialData socialData
    ) {
        super(titleChangedListener, pageViewListener);
        this.context = context;
        this.activity = activity;
        this.socialData = socialData;
        this.locationListener = locationListener;
    }

    public PageView<RegisterBuilder> createViewByPos(int pos) {
        return switch (pos) {
            case 0 -> new PhoneNumberView(context);
            case 1 -> new PhoneActivateView(context, activity);
            case 2 -> new UserDataView(context, activity, socialData, locationListener);
            case 3 -> new CompanyDataView(context, activity);
            default -> throw new UnsupportedOperationException();
        };
    }


    @Override
    public int getCount() {
        return 4;
    }
}