package pl.mobilemanagement.izarzadca.common.invite.di;

import dagger.Module;
import dagger.Provides;
import pl.mobilemanagement.izarzadca.common.di.api.Auth;
import pl.mobilemanagement.izarzadca.common.invite.api.InviteFriendApi;
import retrofit2.Retrofit;

@Module
public class ContactModule {
    @Provides
    InviteFriendApi provideInviteFriendApi(@Auth Retrofit retrofit) {
        return retrofit.create(InviteFriendApi.class);
    }
}
