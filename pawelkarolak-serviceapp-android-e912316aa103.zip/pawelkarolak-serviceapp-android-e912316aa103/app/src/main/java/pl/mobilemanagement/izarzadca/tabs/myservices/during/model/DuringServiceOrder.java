package pl.mobilemanagement.izarzadca.tabs.myservices.during.model;

import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;

public class DuringServiceOrder extends ServiceOrder {
    public String distanceToCustomer;
    public String street;
    public String number;
    public String postalCode;
    public String city;
    public String country;
    public String name;
    public String lastname;

    public String getAddress() {
        String address = street;
        if (number != null) {
            address += " " + number;
        }
        address += ", " + postalCode + " " + city;
        return address;
    }
}
