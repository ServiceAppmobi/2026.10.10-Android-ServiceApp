package pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model;

import java.util.Date;

public class CompleteOrderDetailsApiModel {
    public String id;
    public String serviceName;
    public int rating;
    public String opinion;
    public double lat;
    public double lng;
    public Date closedDateTime;
}