package pl.mobilemanagement.izarzadca.start_screen.register.pages;

import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.LayoutRes;
import androidx.annotation.StringRes;
import pl.mobilemanagement.izarzadca.start_screen.register.RegisterBuilder;
import pl.mobilemanagement.izarzadca.tools.pages.PageView;

public abstract class PageRegisterView extends PageView<RegisterBuilder> {

    public PageRegisterView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public PageRegisterView(Context context) {
        super(context);
    }

    @StringRes
    protected abstract int titleResource();

    @LayoutRes
    protected abstract int layoutResource();

}
