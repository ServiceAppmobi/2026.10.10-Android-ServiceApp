package pl.mobilemanagement.izarzadca.common.map;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

public class MapData {
    public final GoogleMap googleMap;
    public final List<MarkerOptions> markerOptionList;

    public MapData(List<MarkerOptions> markerOptionList, GoogleMap googleMap) {
        this.markerOptionList = markerOptionList;
        this.googleMap = googleMap;
    }
}
