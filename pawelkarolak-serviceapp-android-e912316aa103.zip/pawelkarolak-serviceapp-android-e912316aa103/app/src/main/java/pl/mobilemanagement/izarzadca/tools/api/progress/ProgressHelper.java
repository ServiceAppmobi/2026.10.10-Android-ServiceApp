package pl.mobilemanagement.izarzadca.tools.api.progress;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;
import com.afollestad.materialdialogs.MaterialDialog;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;

public class ProgressHelper {
    public static MaterialDialog show(Context context) {
        return new MaterialDialog.Builder(context)
                .title(R.string.progress_dialog)
                .content(R.string.please_wait)
                .progress(true, 0)
                .cancelable(false)
                .show();
    }

    public static void safeDismiss(@Nullable MaterialDialog dialog) {
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    public static EarthlyLoadingDialog showEarthly(FragmentManager manager) {
        EarthlyLoadingDialog progressDialog = new EarthlyLoadingDialog();
        progressDialog.show(manager, "earthly dialog");
        return progressDialog;
    }
    public static void safeDismiss(@Nullable EarthlyLoadingDialog dialog) {
        if (dialog != null) {
            dialog.dismiss();
        }
    }

}
