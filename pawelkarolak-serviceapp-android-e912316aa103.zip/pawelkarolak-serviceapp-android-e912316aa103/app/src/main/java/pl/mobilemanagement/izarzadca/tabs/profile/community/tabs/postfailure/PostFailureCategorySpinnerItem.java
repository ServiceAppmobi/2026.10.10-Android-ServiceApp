package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.postfailure;

import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetFailureSubjects;
import pl.mobilemanagement.izarzadca.tools.spinner.SpinnerItem;

public class PostFailureCategorySpinnerItem implements SpinnerItem {

    private final GetFailureSubjects serviceModel;

    public PostFailureCategorySpinnerItem(GetFailureSubjects serviceModel) {
        this.serviceModel = serviceModel;
    }

    public GetFailureSubjects getServiceModel() {
        return serviceModel;
    }

    @Override
    public String toString() {
        return serviceModel.title;
    }
}