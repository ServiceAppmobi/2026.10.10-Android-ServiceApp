package pl.mobilemanagement.izarzadca.common.adapter.orders;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public abstract class OrderRowViewHolder extends RecyclerView.ViewHolder {

    public OrderRowViewHolder(View itemView) {
        super(itemView);
    }


}
