package pl.mobilemanagement.izarzadca.common.notification.api;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import com.google.firebase.messaging.FirebaseMessaging;

import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.schedulers.Schedulers;
import timber.log.Timber;

public class NotificationRegisterService {
    private final NotificationApi notificationApi;
    private final Context context;

    public NotificationRegisterService(NotificationApi notificationApi, Context context) {
        this.notificationApi = notificationApi;
        this.context = context;
    }

    public void registerUserDeviceToPushNotification(boolean isActive, Action0 func) {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                String uuid = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
                Device device = new Device(task.getResult(), uuid, isActive);
                notificationApi.registerOrUpdateDevice(device)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(aVoid -> {
                            if (func != null)
                                func.call();
                        }, throwable -> Timber.e(throwable, "Device registration failed"));
            } else if (task.getException() != null)
                task.getException().printStackTrace();
        });
    }


    public void register(boolean isActive, Action0 action) {
        registerUserDeviceToPushNotification(isActive, action);
    }

    public void communityMemberCheck() {
        notificationApi.checkIfCommunityMember() .subscribeOn(Schedulers.io())
                .subscribe(res -> {
                    if(res){
                        Handler txtsettext = new Handler(Looper.getMainLooper());
                        txtsettext.post(() -> MainActivity.instance.showCommunity());
                    }
                }, throwable -> {
                });
    }

}
