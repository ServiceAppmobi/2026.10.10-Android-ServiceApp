package pl.mobilemanagement.izarzadca.common.model.entity;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Country implements Serializable {
    public final String id;
    public final String name;
    public String areaCode;

    public Country(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public Country(String id, String name, String areaCode) {
        this.id = id;
        this.name = name;
        this.areaCode = areaCode;
    }

    @NonNull
    @Override
    public String toString() {
        return name;
    }
}
