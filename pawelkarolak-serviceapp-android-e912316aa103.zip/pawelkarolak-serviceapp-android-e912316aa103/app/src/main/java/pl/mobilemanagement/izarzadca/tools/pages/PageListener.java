package pl.mobilemanagement.izarzadca.tools.pages;

public interface PageListener<T> {
    void showNextPage();

    void finishPaging();

    T getCurrentBuilder();
}
