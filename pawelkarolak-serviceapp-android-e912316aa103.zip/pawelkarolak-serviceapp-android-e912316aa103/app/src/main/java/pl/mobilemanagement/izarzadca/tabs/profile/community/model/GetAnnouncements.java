package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Date;

public class GetAnnouncements implements Serializable {

    @SerializedName("number")
    public String number;

    @SerializedName("name")
    public String name;

    @SerializedName("createDate")
    public Date createDate;

    @SerializedName("validUntil")
    public Date validUntil;

    @SerializedName("community")
    public String community;

    @SerializedName("messageBody")
    public String messageBody;

    @SerializedName("isActive")
    public boolean isActive;

}
