package pl.mobilemanagement.izarzadca.tabs.profile.community.common;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetFailureReports;

/**
 * Created by katak on 27.02.2017.
 */

public class listview_popup extends ArrayAdapter<listview_item> {

    Context context;
    int layoutResourceId;
    listview_item[] data;

    public int title1;
    public int title2;
    public int title3;
    public int title4;

    @StringRes public int btnTextRes = R.string.description;

    public boolean switchBackgroundWhenActive = false;
    public boolean switchStatusTextColor = false;

    public listview_popup(Context context, int layoutResourceId, listview_item[] data, @StringRes int title1, @StringRes int title2, @StringRes int title3, @StringRes int title4) {
        super(context, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
        this.title1 = title1;
        this.title2 = title2;
        this.title3 = title3;
        this.title4 = title4;
    }

    public listview_popup(Context context, int layoutResourceId, listview_item[] data, @StringRes int title1, @StringRes int title2, @StringRes int title3, @StringRes int title4, @StringRes int btnTextRes) {
        this(context, layoutResourceId, data, title1, title2, title3, title4);
        this.btnTextRes = btnTextRes;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        Listview_itemHolder holder;

        listview_item weather = data[position];

        if (row == null) {
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);

            holder = new Listview_itemHolder();
            holder.cardView = row.findViewById(R.id.cardView);
            holder.imgIcon = row.findViewById(R.id.title);
            holder.title1 = row.findViewById(R.id.createdOn);
            holder.textItem1 = row.findViewById(R.id.createdOnValue);
            holder.title2 = row.findViewById(R.id.status);
            holder.textItem2 = row.findViewById(R.id.statusValue);
            holder.title3 = row.findViewById(R.id.priority);
            holder.textItem3 = row.findViewById(R.id.priorityValue);
            holder.title4 = row.findViewById(R.id.number);
            holder.textItem4 = row.findViewById(R.id.numberValue);
            holder.pupupItem = row.findViewById(R.id.description);

            holder.pupupItem.setText(btnTextRes);

            row.setTag(holder);
        } else {
            holder = (Listview_itemHolder) row.getTag();
        }

        if (switchBackgroundWhenActive) {
            int bgColorRes = weather.isActive ? R.color.main : R.color.white;
            int bgColor = ContextCompat.getColor(row.getContext(), bgColorRes);

            int textColorRes = weather.isActive ? R.color.white : R.color.text1;
            int textColor = ContextCompat.getColor(row.getContext(), textColorRes);

            int btnTextColorRes = weather.isActive ? R.color.white : R.color.main;
            int btnTextColor = ContextCompat.getColor(row.getContext(), btnTextColorRes);

            holder.cardView.setCardBackgroundColor(bgColor);
            holder.imgIcon.setTextColor(textColor);
            holder.title1.setTextColor(textColor);
            holder.title2.setTextColor(textColor);
            holder.title3.setTextColor(textColor);
            holder.title4.setTextColor(textColor);
            holder.textItem1.setTextColor(textColor);
            holder.textItem2.setTextColor(textColor);
            holder.textItem3.setTextColor(textColor);
            holder.textItem4.setTextColor(textColor);
            holder.pupupItem.setTextColor(btnTextColor);
        }

        if (switchStatusTextColor) {
            switch (weather.statusId) {
                case GetFailureReports.IN_PROGRESS:
                    holder.textItem2.setTextColor(ContextCompat.getColor(row.getContext(), R.color.in_progress));
                    break;
                case GetFailureReports.OPEN:
                    holder.textItem2.setTextColor(ContextCompat.getColor(row.getContext(), R.color.open));
                    break;
                case GetFailureReports.HOLD:
                    holder.textItem2.setTextColor(ContextCompat.getColor(row.getContext(), R.color.red));
                    break;
                case GetFailureReports.WAITING_FOR_DETAILS:
                    holder.textItem2.setTextColor(ContextCompat.getColor(row.getContext(), R.color.waiting_for_details));
                    break;
                case GetFailureReports.RESEARCHING:
                    holder.textItem2.setTextColor(ContextCompat.getColor(row.getContext(), R.color.researching));
                    break;
                default:
                    holder.textItem2.setTextColor(ContextCompat.getColor(row.getContext(), R.color.text1));
                    break;
            }
        }

        holder.title1.setText(title1);
        holder.title2.setText(title2);
        holder.title3.setText(title3);
        if (title4 != 0) {
            holder.title4.setText(title4);
        }

        if (weather.textItem4.isEmpty()) {
            holder.title4.setVisibility(View.GONE);
            holder.textItem4.setVisibility(View.GONE);
        } else {
            holder.title4.setVisibility(View.VISIBLE);
            holder.textItem4.setVisibility(View.VISIBLE);
        }

        holder.textItem1.setText(weather.textItem1);
        holder.textItem2.setText(weather.textItem2);
        if (weather.textItem3 != "FALSE") holder.textItem3.setText(weather.textItem3);
        else holder.textItem3.setVisibility(View.INVISIBLE);
        if (weather.textItem4 != "FALSE" && weather.message != "MAGIA")
            holder.textItem4.setText(weather.textItem4);
        else holder.textItem4.setVisibility(View.INVISIBLE);

        if (weather.message != "FALSE" && weather.message != "MAGIA") {
            holder.pupupItem.setOnClickListener(v -> {

                AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create(); //Read Update
                alertDialog.setTitle(weather.title);
                //alertDialog.setMessage(weather.message);
                WebView wv = new WebView(getContext());
                String webData =  "<!DOCTYPE html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">"+
                        "<title></title></head><body>"+
                        weather.message+"</body></html>";

                wv.loadData(webData, "text/html; charset=utf-8", "UTF-8");
                wv.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        view.loadUrl(url);

                        return true;
                    }
                });

                alertDialog.setView(wv);

                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getContext().getResources().getString(R.string.tab_close), (dialog, which) -> {
                    dialog.dismiss();
                });

                alertDialog.show();  //<-- See This!

            });
        } else if (weather.message == "MAGIA") {
            holder.pupupItem.setOnClickListener(v -> {

                AlertDialog alertDialog = new AlertDialog.Builder(getContext(), R.style.AlertDialog).create(); //Read Update
                alertDialog.setTitle(weather.title);
                alertDialog.setMessage(weather.textItem4);

                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getContext().getResources().getString(R.string.tab_call), (dialog, which) -> {
                    String[] exploded = weather.textItem2.split(":");
                    Intent callIntent = new Intent(Intent.ACTION_VIEW);
                    callIntent.setData(Uri.parse("tel:" + exploded[1]));
                    getContext().startActivity(callIntent);
                });
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getContext().getResources().getString(R.string.tab_email), (dialog, which) -> {
                    String[] exploded = weather.textItem2.split(":");

                    Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                            "mailto",exploded[1], null));
                    emailIntent.putExtra(Intent.EXTRA_SUBJECT, "iZarzadca");
                    emailIntent.putExtra(Intent.EXTRA_TEXT, "Your message");
                    getContext().startActivity(Intent.createChooser(emailIntent, "Send email..."));
                });

                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getContext().getResources().getString(R.string.tab_close), (dialog, which) -> {
                    dialog.dismiss();
                });

                alertDialog.show();  //<-- See This!

            });
        } else{
            holder.pupupItem.setVisibility(View.INVISIBLE);
        }


        holder.imgIcon.setText(weather.title);

        return row;
    }

    static class Listview_itemHolder
    {
        CardView cardView;
        TextView imgIcon;
        TextView title1;
        TextView textItem1;
        TextView title2;
        TextView textItem2;
        TextView title3;
        TextView textItem3;
        TextView title4;
        TextView textItem4;
        TextView pupupItem;
    }
}