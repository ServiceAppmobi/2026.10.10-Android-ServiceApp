package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service;

import android.content.Context;

import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.databinding.OrderServiceTypeBinding;
import pl.mobilemanagement.izarzadca.tabs.orderservice.api.OrderServiceApi;
import pl.mobilemanagement.izarzadca.tabs.orderservice.di.DaggerOrderComponent;
import pl.mobilemanagement.izarzadca.tabs.orderservice.model.ServiceGroupId;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.BaseView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceGroup;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.view.GroupSpinnerItem;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.view.ServiceTypeSpinnerItem;
import pl.mobilemanagement.izarzadca.tools.Pair;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import pl.mobilemanagement.izarzadca.tools.rx.spinner.RxSpinner;
import pl.mobilemanagement.izarzadca.tools.spinner.HintAdapter;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class ChoiceServiceView extends BaseView {
    public Subscription selectGroupWithTypeSubscription;

    public Subscription createPairSubscription;

    @Inject
    OrderServiceApi orderServiceApi;

    private final OrderServiceTypeBinding binding;

    private Subscription fetchGroupSubscription;

    private Pair<ServiceGroup, ServiceModel> selectedGroupWithType;

    public ChoiceServiceView(Context context) {
        super(context);
        DaggerOrderComponent.builder().applicationComponent(App.component).build().inject(this);
        binding = OrderServiceTypeBinding.bind(getChildAt(0));
        initSpinnerAdapter();
    }

    private void initSpinnerAdapter() {
        HintAdapter.initEmpty(binding.orderServiceTypeGroup);
        HintAdapter.initEmpty(binding.orderServiceTypeWhat);
        final Observable<ServiceGroup> group = RxSpinner.<GroupSpinnerItem>itemClickChanges(binding.orderServiceTypeGroup)
                .map(GroupSpinnerItem::getServiceGroup)
                .share();
        final Observable<ServiceModel> types = RxSpinner.<ServiceTypeSpinnerItem>itemClickChanges(binding.orderServiceTypeWhat)
                .map(ServiceTypeSpinnerItem::getServiceModel);

        selectGroupWithTypeSubscription = group.distinctUntilChanged()
                .doOnNext(groupSpinnerItem -> clearServiceTypeAndSelect())
                .switchMap(this::fetchType)
                .observeOn(AndroidSchedulers.mainThread())
                .doOnError(throwable -> ApiErrorDialogHelper.show(getContext(), throwable))
                .retry()
                .subscribe(serviceTypeSpinnerItems -> HintAdapter.setHintData(binding.orderServiceTypeWhat, serviceTypeSpinnerItems));

        createPairSubscription = types.withLatestFrom(group, (serviceType, groupItem) -> new Pair<>(groupItem, serviceType)).subscribe(serviceGroupServiceModelPair -> {
            selectedGroupWithType = serviceGroupServiceModelPair;
        });
    }

    private void clearServiceTypeAndSelect() {
        binding.orderServiceTypeWhat.setText("");
        HintAdapter.initEmpty(binding.orderServiceTypeWhat);
        selectedGroupWithType = null;
    }

    @Override
    protected void onAttached() {
        fetchGroupSubscription = fetchServicesGroup();
    }

    @Override
    protected void onDetached() {
        binding.orderServiceTypeGroup.dismissDropDown();
        binding.orderServiceTypeWhat.dismissDropDown();
        Rx.safeUnsubscribe(fetchGroupSubscription, selectGroupWithTypeSubscription, createPairSubscription);
    }

    private Subscription fetchServicesGroup() {
        return orderServiceApi.getServicesGroups()
                .flatMapIterable(serviceGroupResponse -> serviceGroupResponse)
                .sorted((serviceGroup, serviceGroup2) -> serviceGroup.name.compareToIgnoreCase(serviceGroup2.name))
                .map(GroupSpinnerItem::new)
                .toList()
                .compose(Rx.applySchedulers())
                .retry(3)
                .subscribe(serviceGroupSpinner -> {
                            HintAdapter.setHintData(binding.orderServiceTypeGroup, serviceGroupSpinner);
                        }, this::showError
                );
    }

    //TODO Remove after investigation issues/582021060aeb16625b92453e
    private void showError(Throwable throwable) {
        try {
            ApiErrorDialogHelper.show(getContext(), throwable);
        } catch (Exception e) {
            FirebaseCrashlytics.getInstance().recordException(e);
        }
    }

    private Observable<List<ServiceTypeSpinnerItem>> fetchType(ServiceGroup serviceGroup) {
        return orderServiceApi.getServicesByGroupId(new ServiceGroupId(serviceGroup.serviceGroupId))
                .flatMapIterable(serviceTypeResponse -> serviceTypeResponse)
                .sorted((serviceType, serviceType2) -> serviceType.name.compareToIgnoreCase(serviceType2.name))
                .map(ServiceTypeSpinnerItem::new)
                .toList()
                .subscribeOn(Schedulers.io())
                .retry(3);
    }

    @Override
    public void onNext() {
        super.onNext();
        Validator validator = validateInput();
        if (validator.isValid()) {
            pageViewListener.getOrderBuilder().setServiceGroupWithType(selectedGroupWithType.first, selectedGroupWithType.second);
            pageViewListener.showNextPage();
        } else {
            ValidationErrorDialogHelper.show(getContext(), validator);
        }
    }

    private Validator validateInput() {
        Validator validator = new Validator();
        if (selectedGroupWithType == null) {
            validator.addError(getString(R.string.choice_service_no_type));
        }
        return validator;
    }

    @Override
    protected int titleResource() {
        return R.string.order_service_select_date;
    }

    @Override
    protected int layoutResource() {
        return R.layout.order_service_type;
    }
}
