package pl.mobilemanagement.izarzadca.tabs.myservices.ended.model;

import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;

public class CompletedOrderService extends ServiceOrder {
    public int rating;
    public String opinion;
}
