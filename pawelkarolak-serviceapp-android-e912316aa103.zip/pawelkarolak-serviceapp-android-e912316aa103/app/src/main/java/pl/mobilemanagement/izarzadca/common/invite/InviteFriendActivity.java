package pl.mobilemanagement.izarzadca.common.invite;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.common.invite.api.InviteFriendApi;
import pl.mobilemanagement.izarzadca.common.invite.contact.Contact;
import pl.mobilemanagement.izarzadca.common.invite.contact.InviteType;
import pl.mobilemanagement.izarzadca.common.invite.contact.RxContacts;
import pl.mobilemanagement.izarzadca.common.invite.contact.view.ContactAdapter;
import pl.mobilemanagement.izarzadca.common.model.api.ContactApiModel;
import pl.mobilemanagement.izarzadca.common.model.api.RecommendContact;
import pl.mobilemanagement.izarzadca.databinding.ActivityInviteFriendBinding;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.TabToMove;
import pl.mobilemanagement.izarzadca.tools.Recycler;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

public class InviteFriendActivity extends AppCompatActivity {
    public static final int EMAIL_API_TYPE = 2;
    public static final int SMS_API_TYPE = 1;
    private static final String INVITE_TYPE = "USER_NAME_KEY";
    private static final String BACK_PRESS = "BACK_PRESS_KEY";
    public ContactAdapter contactAdapter;
    public InviteType type;

    public boolean openMainOnBackPress = false;

    @Inject
    InviteFriendApi inviteFriendApi;

    Toolbar toolbar;
    RecyclerView recyclerViewContacts;

    private Subscription contactSubscription;
    private Subscription inviteFriendRequestSubscription;

    public static void start(Context context, InviteType inviteType) {
        final Intent intent = getIntent(context, inviteType, false);
        context.startActivity(intent);
    }

    private static Intent getIntent(Context context, InviteType inviteType, boolean openMainOnBackPress) {
        final Intent intent = new Intent(context, InviteFriendActivity.class);
        intent.putExtra(INVITE_TYPE, inviteType);
        intent.putExtra(BACK_PRESS, openMainOnBackPress);
        return intent;
    }

    public static void startForResult(Activity activity, InviteType inviteType, int askForFriend, boolean openMainOnBackPress) {
        final Intent intent = getIntent(activity, inviteType, openMainOnBackPress);
        activity.startActivityForResult(intent, askForFriend);
    }

    private final ActivityResultLauncher<String> contactsPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            result -> {
                if (result) {
                    fetchContacts();
                }
            }
    );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("InviteFriendActivity","onCreate");

        ActivityInviteFriendBinding binding = ActivityInviteFriendBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        toolbar = binding.toolbar.toolbarWhiteArrow;
        recyclerViewContacts = binding.recyclerViewContacts;
        binding.sendInformationToFriends.setOnClickListener(v -> onClick());

        App.component.inject(this);
        initAdapter();
        setSupportActionBar(toolbar);
        type = (InviteType) getIntent().getSerializableExtra(INVITE_TYPE);
        openMainOnBackPress = getIntent().getBooleanExtra(BACK_PRESS, false);

        contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS);
    }

    private void fetchContacts() {
        contactSubscription = RxContacts.fetch(this)
                .filter(contact -> {

                    Log.i("InviteFriendActivity", String.valueOf(contact.phoneNumbers));

                    if (type == InviteType.EMAIL)
                        return !contact.emails.isEmpty();
                    else {
                        return !contact.phoneNumbers.isEmpty();
                    }
                })
                .toList()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(contacts ->
                        contactAdapter.setContacts(contacts), throwable -> {
                });
    }

    @Override
    public void onBackPressed() {
        if(openMainOnBackPress)
            MainActivity.startActivity(this, TabToMove.PROFILE);
        else
            super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Rx.safeUnsubscribe(inviteFriendRequestSubscription);
    }

    private void initAdapter() {
        contactAdapter = new ContactAdapter();
        Recycler.initVerticalRecyclerView(recyclerViewContacts);
        recyclerViewContacts.setAdapter(contactAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            setResult(Activity.RESULT_CANCELED);
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClick() {
        final List<Contact> selectedContacts = contactAdapter.getSelectedContacts();
        if (selectedContacts.isEmpty())
            return;
        final List<ContactApiModel> contactApiModels = contactToApiModel(selectedContacts, type);
        inviteFriendRequestSubscription = inviteFriendApi.sendInformatioToFriends(new RecommendContact(contactApiModels))
                .compose(Rx.applySchedulers())
                .compose(ProgressDialog.create(this))
                .subscribe(aVoid -> {
                    setResult(Activity.RESULT_OK);
                    finish();
                }, throwable -> ApiErrorDialogHelper.show(this, throwable));
    }

    private List<ContactApiModel> contactToApiModel(List<Contact> selectedContacts, InviteType type) {
        final ArrayList<ContactApiModel> contactApiModelList = new ArrayList<>(selectedContacts.size());
        for (Contact selectedContact : selectedContacts) {
            int contactType = type == InviteType.EMAIL ? EMAIL_API_TYPE : SMS_API_TYPE;
            final ContactApiModel contactApiModel = new ContactApiModel(
                    selectedContact.getFirstNameOrDisplayName(),
                    selectedContact.familyName,
                    selectedContact.getFirstPhoneNumberOrNull(),
                    selectedContact.getFirstEmailOrNull(), contactType);
            contactApiModelList.add(contactApiModel);
        }
        return contactApiModelList;
    }
}
