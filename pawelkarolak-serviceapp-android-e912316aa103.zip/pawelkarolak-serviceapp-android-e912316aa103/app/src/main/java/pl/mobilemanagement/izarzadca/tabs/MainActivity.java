package pl.mobilemanagement.izarzadca.tabs;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import io.intercom.android.sdk.Intercom;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.MyFirebaseMessagingService;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.BackHandlerInterface;
import pl.mobilemanagement.izarzadca.common.di.DaggerViewModelFactory;
import pl.mobilemanagement.izarzadca.common.notification.api.NotificationRegisterService;
import pl.mobilemanagement.izarzadca.common.user.LogoutService;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.databinding.ActivityMainBinding;
import pl.mobilemanagement.izarzadca.start_screen.LoginOrRegisterActivity;
import pl.mobilemanagement.izarzadca.tabs.file_manager.FileManagerFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.MyOrdersTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.MyServicesTabFragment;
import pl.mobilemanagement.izarzadca.tabs.orderservice.OrderServiceTabFragment;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.DifferentAddressActivity;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.AddressPlace;
import pl.mobilemanagement.izarzadca.tabs.profile.ProfileTabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.community.Bills;
import pl.mobilemanagement.izarzadca.tabs.profile.community.FailureReport;
import pl.mobilemanagement.izarzadca.tabs.profile.community.Messages;
import pl.mobilemanagement.izarzadca.tabs.profile.community.ProfileCommunity;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.CommunityManagement;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.DocumentsAnnouncements;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.DocumentsApplications;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.HomeTabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models.Apartment;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.functions.Action0;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int REQ_SET_DIFFERENT_ADDRESS = 1;
    public static final int TAB_TO_SELECT = 333;

    public static final String EXTRA_TAB_TO_OPEN = "TAB_TO_OPEN";

    private static final String SAVED_CURRENT_TAB_POSITION = "saved_current_tab";

    public static MainActivity instance;

    public int selectedTabId = 0;

    View divider;
    NavigationView navigationView;
    BottomNavigationView bottom;
    VideoView adsView;
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    TextView btnLogout;

    @Inject
    NotificationRegisterService notificationRegisterService;

    @Inject
    LogoutService logoutService;

    @Inject
    TokenDataSource tokenDataSource;

    @Inject
    AccountTypeDataSource accountTypeDataSource;

    @Inject
    DaggerViewModelFactory viewModelFactory;

    public MainActivityViewModel viewModel;

    private Fragment selectedTab;

    private MediaPlayer adsViewMediaPlayer;

    private EarthlyLoadingDialog earthlyDialog;

    public static void startActivity(Context context, TabToMove tabToMove) {
        Intent startIntent = new Intent(context, MainActivity.class);
        startIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startIntent.putExtra(EXTRA_TAB_TO_OPEN, tabToMove);
        context.startActivity(startIntent);
    }

/*    public Observable<CheckIfCommunityMember> getCommunityInformation() {
        return communityApi.checkIfCommunityMember()
                .doOnNext(this::IfCommunity)
                .doOnError(this::showConnectionError)
                .onErrorResumeNext(throwable -> Observable.empty())
                .subscribeOn(Schedulers.io());
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        divider = binding.divider.getRoot();
        navigationView = binding.navigationView;
        bottom = binding.bottom;
        adsView = binding.bottomAds;
        drawerLayout = binding.drawerLayout;
        toolbar = binding.toolbar;
        btnLogout = binding.logout;
        binding.bottomAds.setOnTouchListener((v, event) -> onAdsClick());

        App.component.inject(this);

        viewModel = ViewModelProviders.of(this, viewModelFactory).get(MainActivityViewModel.class);

        initViews();
        if (accountIsInvalid() || isNeedToLogout()) {
            return;
        }
        notificationRegisterService.register(true, null);
        addNavigationItemClickLister();
        instance = this;

        getSupportFragmentManager().addFragmentOnAttachListener((fragmentManager, fragment) -> {
            if (fragment instanceof CommunityManagement)
                setTitle(R.string.tab_my_community);
            else if (fragment instanceof TabFragment)
                setTitle(((TabFragment) fragment).getTitleResource());
            else if (fragment instanceof TitledTabFragment)
                setTitle(((TitledTabFragment) fragment).getTitleResource());

            if(fragment instanceof HomeTabFragment)
                bottom.setSelectedItemId(R.id.home);
            else if(fragment instanceof OrderServiceTabFragment)
                bottom.setSelectedItemId(R.id.request);
            else if(fragment instanceof MyOrdersTabFragment)
                bottom.setSelectedItemId(R.id.orders);
            else if(fragment instanceof MyServicesTabFragment)
                bottom.setSelectedItemId(R.id.my_services);
        });

        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setHomeAsUpIndicator(R.drawable.arror_blue);
        }

        observe(savedInstanceState);

        viewModel.loginIntercom();
        Intercom.client().setLauncherVisibility(Intercom.Visibility.GONE);

        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerOpened(@NonNull View drawerView) {
                Intercom.client().setLauncherVisibility(Intercom.Visibility.VISIBLE);
            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {
                Intercom.client().setLauncherVisibility(Intercom.Visibility.GONE);
            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }

            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.logout) {
            unregisterAndLogout();
        }
    }

    private boolean accountIsInvalid() {
        if (!accountTypeDataSource.isValidType()) {
            logout();
            return true;
        }
        return false;
    }

    private boolean isNeedToLogout() {
        if (accountTypeDataSource.isNeedToLogout()) {
            logout();
            return true;
        }
        return false;
    }

    private void logout() {
        Intercom.client().logout();
        logoutService.clearPersonalData();
        LoginOrRegisterActivity.startOnTop(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        initAdsBanner();
        if(
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.POST_NOTIFICATIONS }, 1);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseAdsView();
    }

    private void releaseAdsView() {
        if (adsViewMediaPlayer != null) {
            adsViewMediaPlayer.reset();
            adsViewMediaPlayer = null;
        }
    }

    private void initTabs(Bundle savedInstanceState, MainActivityViewModel.UserType userType) {
        final List<TabFragment> customerTabs = createTabs();
        selectedTabId = restoreSelectedTabAndReturnPos(savedInstanceState);
        addTabSelectedListener(customerTabs);
        setupTabLayout(selectedTabId, userType);
    }

    private List<TabFragment> createTabs() {
        return Arrays.asList(
            new HomeTabFragment(),
            new OrderServiceTabFragment(),
            new MyOrdersTabFragment(),
            new MyServicesTabFragment()
        );
    }

    private void initViews() {
        setSupportActionBar(toolbar);
        initAdsBanner();
        btnLogout.setOnClickListener(this);
    }

    private void observe(Bundle savedInstanceState) {
        viewModel.getUserType().observe(this, userType -> {
            initTabs(savedInstanceState, userType);
        });
        viewModel.getLoading().observe(this, loading -> {
            if(loading)
                earthlyDialog = ProgressHelper.showEarthly(getSupportFragmentManager());
            else
                ProgressHelper.safeDismiss(earthlyDialog);
        });
        viewModel.isProfessional().observe(this, isProfessional -> {
            navigationView.getMenu().findItem(R.id.files).setVisible(isProfessional);
        });
    }

    private void initAdsBanner() {

        String path = "android.resource://" + getPackageName() + "/" + R.raw.ads_banner;
        Uri uri = Uri.parse(path);
        adsView.setVideoURI(uri);
        adsView.setOnPreparedListener(this::initMediaPlayer);
    }

    private void initMediaPlayer(MediaPlayer mp) {
        this.adsViewMediaPlayer = mp;
        mp.setLooping(true);
        mp.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    private int restoreSelectedTabAndReturnPos(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            selectedTab = getCurrentFragment();
            return savedInstanceState.getInt(SAVED_CURRENT_TAB_POSITION);
        } else {
            return 0;
        }
    }

    public void startFix() {
        Fragment frx = new FailureReport();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.main_frame, frx);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private void addNavigationItemClickLister() {
        notificationRegisterService.communityMemberCheck();
        navigationView.setNavigationItemSelectedListener(item -> {
            openItemInDrawer(item.getAlphabeticShortcut(), false);
            return true;
        });
    }

    private void unregisterAndLogout() {
        notificationRegisterService.register(false, new Action0() {
            @Override
            public void call() {
                logoutService.logoutRemovePushKey()
                        .compose(Rx.applySchedulersCompletable())
                        .subscribe(() -> {
                            Intercom.client().logout();
                            LoginOrRegisterActivity.startOnTop(MainActivity.this);
                            finish();
                        }, throwable -> ApiErrorDialogHelper.show(MainActivity.this, throwable));
            }
        });
    }

    public void openItemInDrawer(char alphabeticShortcut, boolean addToBackStack) {
        Fragment fragment = null;
        switch (alphabeticShortcut) {
            case 'b':
                drawerLayout.closeDrawer(GravityCompat.END);
                setTitle(R.string.tab_my_bills);

                fragment = new Bills();
                break;
            case 'c':
                drawerLayout.closeDrawer(GravityCompat.END);
                setTitle(R.string.tab_my_community);
                fragment = new ProfileCommunity();
                break;
            case 'f':
                //FAULTS
                drawerLayout.closeDrawer(GravityCompat.END);
                setTitle(R.string.tab_DocumentsApplications);
                fragment = new DocumentsApplications();
                break;
            case 'a':
                //Announcements
                drawerLayout.closeDrawer(GravityCompat.END);
                setTitle(R.string.tab_DocumentsAnnouncements);
                fragment = new DocumentsAnnouncements();
                break;
            case 'p':
                //PROFILE
                drawerLayout.closeDrawer(GravityCompat.END);
                setTitle(R.string.profile_name);
                fragment = new ProfileTabFragment();
                break;
            case 'o':
                drawerLayout.closeDrawer(GravityCompat.END);
                setTitle(R.string.tab_my_community);
                fragment = new OrderServiceTabFragment();
                break;
            case 'k':
                drawerLayout.closeDrawer(GravityCompat.END);
                setTitle(R.string.menu_messages_emails);
                fragment = new Messages();
                break;
            case 'm':
                drawerLayout.closeDrawer(GravityCompat.END);
                setTitle(R.string.file_manager);
                fragment = new FileManagerFragment();
                break;
            case 'x':
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://serviceapp.mobi/privacy"));
                startActivity(browserIntent);
                break;
        }

        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.main_frame, fragment);
            if (addToBackStack)
                transaction.addToBackStack(null);
            transaction.commit();
        }

        Log.i("Navigation", String.valueOf(alphabeticShortcut));
    }

    public void showCommunity() {
        //navigationView.getMenu().findItem(R.id.documents_bills).setVisible(true);
        navigationView.getMenu().findItem(R.id.documents_community).setVisible(true);
        navigationView.getMenu().findItem(R.id.faults).setVisible(true);
        navigationView.getMenu().findItem(R.id.announcments).setVisible(true);
        navigationView.getMenu().findItem(R.id.messages_emails).setVisible(true);
        navigationView.getMenu().findItem(R.id.files).setVisible(true);
    }

    private void setFragment(List<TabFragment> customerTabs, int position) {
        if(getCurrentFragment() != customerTabs.get(position)) {
            selectedTab = customerTabs.get(position);
            replaceFragment(customerTabs.get(position));
        }
    }

    private void addTabSelectedListener(final List<TabFragment> customerTabs) {
        bottom.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.home:
                    setFragment(customerTabs, 0);
                    break;
                case R.id.request:
                    setFragment(customerTabs, 1);
                    break;
                case R.id.orders:
                    setFragment(customerTabs, 2);
                    break;
                case R.id.my_services:
                    setFragment(customerTabs, 3);
                    break;
            }
            return true;
        });
    }

    private boolean isTheSameType(TabFragment tabFragment) {
        return selectedTab != null && (selectedTab == tabFragment || selectedTab.getClass().equals(tabFragment.getClass()));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.drawer_button) {
            drawerLayout.openDrawer(GravityCompat.END);
        }
        return super.onOptionsItemSelected(item);
    }

    public void openDrawer() {
        drawerLayout.openDrawer(GravityCompat.END);
    }

    private void setupTabLayout(int selectedTabId, MainActivityViewModel.UserType userType) {
        if(selectedTabId != 0) {
            bottom.setSelectedItemId(selectedTabId);
        }
        switch (userType) {
            case APP_USER:
                bottom.getMenu().getItem(0).setVisible(false);
                bottom.getMenu().getItem(1).setVisible(true);
                bottom.getMenu().getItem(1).setVisible(true);
                bottom.getMenu().getItem(2).setVisible(true);
                bottom.getMenu().getItem(3).setVisible(false);
                if(selectedTabId == 0)
                    bottom.setSelectedItemId(R.id.request);
                break;
            case APP_USER_WITH_PROPERTY:
                bottom.getMenu().getItem(0).setVisible(true);
                bottom.getMenu().getItem(1).setVisible(true);
                bottom.getMenu().getItem(2).setVisible(true);
                bottom.getMenu().getItem(3).setVisible(false);
                if(selectedTabId == 0)
                    bottom.setSelectedItemId(R.id.home);
                break;
            case SERVICE_PROVIDER:
                bottom.getMenu().getItem(0).setVisible(false);
                bottom.getMenu().getItem(1).setVisible(true);
                bottom.getMenu().getItem(2).setVisible(true);
                bottom.getMenu().getItem(3).setVisible(true);
                if(selectedTabId == 0)
                    bottom.setSelectedItemId(R.id.my_services);
                break;
            case SERVICE_PROVIDER_WITH_PROPERTY:
                bottom.getMenu().getItem(0).setVisible(true);
                bottom.getMenu().getItem(1).setVisible(true);
                bottom.getMenu().getItem(2).setVisible(true);
                bottom.getMenu().getItem(3).setVisible(true);
                if(selectedTabId == 0)
                    bottom.setSelectedItemId(R.id.home);
                break;
        }
        if (Objects.equals(getIntent().getStringExtra(MyFirebaseMessagingService.ALERT), "6")) {
            openItemInDrawer('a', false);
        }
    }

    public void setToolbarVisibility(boolean visibility) {
        if(visibility) {
            divider.setVisibility(View.VISIBLE);
            if(getSupportActionBar() != null)
                getSupportActionBar().show();
        } else {
            divider.setVisibility(View.GONE);
            if(getSupportActionBar() != null)
                getSupportActionBar().hide();
        }
    }

    private void replaceFragment(Fragment fragment) {
/*        try {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.main_frame, fragment);
        transaction.commit();
        } catch (Exception e) {
            Log.e("Problem","Za szybko klikasz");
        }*/

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        if (fragment instanceof HomeTabFragment)
            transaction.replace(R.id.main_frame, fragment);
        else
            transaction.replace(R.id.main_frame, fragment, "home");
        transaction.addToBackStack(null);
        try {
            transaction.commit();
        } catch (IllegalStateException e) {
            transaction.commitAllowingStateLoss();
        }
    }

    public boolean hasHomeScreen() {
        List<Apartment> apartments = viewModel.getApartments().getValue();
        return apartments != null && !apartments.isEmpty();
    }

    private Fragment getCurrentFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        return fragmentManager.findFragmentById(R.id.main_frame);
    }

    boolean onAdsClick() {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(accountTypeDataSource.getBannerUrl()));
        startActivity(browserIntent);
        return true;
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(SAVED_CURRENT_TAB_POSITION, bottom.getSelectedItemId());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == REQ_SET_DIFFERENT_ADDRESS) {
            Fragment fragment = getCurrentFragment();
            if (fragment instanceof OrderServiceTabFragment) {
                AddressPlace address = DifferentAddressActivity.getAddressFromIntent(data);
                ((OrderServiceTabFragment) fragment).setAddress(address);
            }
        } else if (resultCode == RESULT_OK && requestCode == TAB_TO_SELECT) {
            TabToMove tabToMove = (TabToMove) data.getSerializableExtra(EXTRA_TAB_TO_OPEN);
            if (tabToMove == TabToMove.ORDER_SERVICE)
                bottom.setSelectedItemId(R.id.request);
            else if (tabToMove == TabToMove.MY_ORDERS)
                bottom.setSelectedItemId(R.id.orders);
        }
    }

    @Override
    public void onBackPressed() {
        final boolean isHandled = onBackPressedByTabFragment();
        if (!isHandled) {
            //hotfix: onBackPressed remove last fragment on stack so user see blank screen,
            //fragment stack should be rewritten by navigation jetpack component
            if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
                super.onBackPressed();
            } else {
                finish();
            }
        }
    }

    private boolean onBackPressedByTabFragment() {
        if (selectedTab != null) {
            if (selectedTab instanceof BackHandlerInterface) {
                final BackHandlerInterface backableTabFragment = (BackHandlerInterface) selectedTab;
                return backableTabFragment.onBackPressed();
            }
        }
        return false;
    }
}
