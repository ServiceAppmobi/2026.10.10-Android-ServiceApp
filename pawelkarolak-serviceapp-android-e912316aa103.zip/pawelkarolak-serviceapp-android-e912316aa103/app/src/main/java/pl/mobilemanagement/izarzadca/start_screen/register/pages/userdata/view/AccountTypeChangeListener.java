package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view;

import pl.mobilemanagement.izarzadca.common.model.entity.AccountTypeName;

public interface AccountTypeChangeListener {
    void onTypeChanged(AccountTypeName accountTypeName);
}
