package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models

data class Payment(
    val date: String,
    val amount: String
)