package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.AddressPlace;

class AddressServiceProviderRequest extends ServiceProviderRequest {

    AddressServiceProviderRequest(String serviceId, AddressPlace place) {
        super(serviceId, place);
        city = place.city;
        countryId = place.countryId;
        street = place.street;
        number = place.number;
        postalCode = place.postalCode;
    }
}
