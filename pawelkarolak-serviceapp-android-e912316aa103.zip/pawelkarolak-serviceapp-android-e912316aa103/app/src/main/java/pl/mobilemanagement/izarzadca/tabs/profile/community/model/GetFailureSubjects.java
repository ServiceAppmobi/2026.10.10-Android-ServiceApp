package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Date;

public class GetFailureSubjects implements Serializable {

    @SerializedName("id")
    public String id;

    @SerializedName("title")
    public String title;


}
