package pl.mobilemanagement.izarzadca.common.di;

import android.app.Application;
import android.content.Context;
import androidx.annotation.NonNull;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSerializer;
import dagger.Module;
import dagger.Provides;
import javax.inject.Singleton;
import pl.mobilemanagement.izarzadca.common.notification.api.NotificationApi;
import pl.mobilemanagement.izarzadca.common.notification.api.NotificationRegisterService;
import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;
import pl.mobilemanagement.izarzadca.common.user.LogoutService;
import pl.mobilemanagement.izarzadca.common.user.profile.UserProfileDataSource;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.order.OrderRequest;

@Module
public class ApplicationModule {

    @NonNull
    private final Application application;

    public ApplicationModule(@NonNull Application application) {
        this.application = application;
    }

    @Provides
    @NonNull
    @Singleton
    Application provideIZarzadcaApplication() {
        return application;
    }


    @Provides
    @NonNull
    @Singleton
    Gson provideGson() {
        return new GsonBuilder()
                .registerTypeAdapter(OrderRequest.class, (JsonSerializer<OrderRequest>) (src, typeOfSrc, context) -> context.serialize(src, src.getClass()))
                .setDateFormat("dd-MM-yyyy' 'HH:mm:ss")
                .create();
    }

    @Provides
    @NonNull
    LogoutService provideLogoutService(TokenDataSource tokenDataSource, UserProfileDataSource userDataSource) {
        return new LogoutService(tokenDataSource, userDataSource);
    }

    @Provides
    @NonNull
    Context provideApplicationContext(Application application) {
        return application;
    }

    @Provides
    @NonNull
    @Singleton
    DataSourceRepository provideDataSourceRepository(Gson gson, Context context) {
        return new DataSourceRepository(context, gson);
    }

    @Provides
    @NonNull
    NotificationRegisterService provideNotificationRegisterService(Context context, NotificationApi api) {
        return new NotificationRegisterService(api, context);
    }

}
