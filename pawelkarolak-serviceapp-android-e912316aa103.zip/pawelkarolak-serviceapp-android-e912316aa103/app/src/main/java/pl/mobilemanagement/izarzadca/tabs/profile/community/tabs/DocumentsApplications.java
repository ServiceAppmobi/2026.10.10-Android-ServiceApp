package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.databinding.ListAnnoucementBinding;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.CloseOrderClickListener;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.common.listview_item;
import pl.mobilemanagement.izarzadca.tabs.profile.community.common.listview_popup;
import pl.mobilemanagement.izarzadca.tabs.profile.community.di.DaggerMyCommunityComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetFailureReports;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by katak on 10.01.2017.
 */

public class DocumentsApplications extends TitledTabFragment implements CloseOrderClickListener {
/*AWARIE*/
    @Inject
    CommunityApi communityApi;

    private ListAnnoucementBinding binding;

    private Subscription fetchSubscription;

    @Override
    public int getTitleResource() {
        return R.string.faults;
    }

    @Override
    public void onCloseOrderClick(Order order) {

    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DaggerMyCommunityComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }
    @Override
    public void onResume() {
        Log.i("INFO", "onResume");
        super.onResume();
        fetchSubscription = getFailureReports().subscribe();
    }
    public Observable<List<GetFailureReports>> getFailureReports() {
        return communityApi.getFailureReports()
                .doOnNext(this::setData)
                .doOnError(this::showConnectionError)
                .onErrorResumeNext(throwable -> Observable.empty())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .compose(ProgressDialog.create(getContext()));
    }



    private void setData(List<GetFailureReports> getFailureReports) {
        Log.i("CommunityInfo", "setData");

        Handler txtsettext = new Handler(Looper.getMainLooper());
        txtsettext.post(() -> {
            listview_item[] listData = new listview_item[getFailureReports.size()];

            int i = 0;
            for (GetFailureReports aaaa : getFailureReports) {
                Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String createDate = "-";

                if(aaaa.createDate != null){
                    createDate = formatter.format(aaaa.createDate);
                }

                Context context = getContext();

                if (context == null) return;

                listData[i++] = new listview_item(
                    aaaa.title,
                    createDate,
                    aaaa.statusCode,
                    aaaa.priority,
                    aaaa.ticket,
                    aaaa.description,
                    aaaa.statusId
                );
            }

            listview_popup adapter = new listview_popup(
                getContext(), R.layout.list_annoucement_item, listData,
                R.string.created_on,
                R.string.tab_DocumentsApplicationsStatus,
                R.string.tab_DocumentsApplicationsPriority,
                R.string.tab_DocumentsApplicationsNumber
            );
            adapter.switchStatusTextColor = true;

            binding.listViewAnn.setAdapter(adapter);
        });
    }

    public void showConnectionError(Throwable message) {
        Log.e("CommunityInfo", "showConnectionError");
        Log.e("CommunityInfo", String.valueOf(message));
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.i("INFO", "onViewCreated");
        super.onViewCreated(view,savedInstanceState);
        binding = ListAnnoucementBinding.bind(view);

        binding.postFailure.setVisibility(View.VISIBLE);
        binding.postFailure.setOnClickListener(v -> MainActivity.instance.startFix());

        int padding1 = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 14, getResources().getDisplayMetrics());
        int paddingBottom = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 80, getResources().getDisplayMetrics());
        binding.listViewAnn.setPadding(padding1, padding1, padding1, paddingBottom);
    }

    @Override
    protected int getLayout() {
        return R.layout.list_annoucement;
    }
}
