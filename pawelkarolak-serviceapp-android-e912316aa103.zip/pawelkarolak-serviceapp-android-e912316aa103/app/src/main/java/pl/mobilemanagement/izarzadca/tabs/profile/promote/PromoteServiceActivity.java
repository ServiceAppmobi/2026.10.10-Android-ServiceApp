package pl.mobilemanagement.izarzadca.tabs.profile.promote;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
//import com.stripe.android.paymentsheet.PaymentSheet;
//import com.stripe.android.paymentsheet.PaymentSheetResult;
//import com.stripe.okhttp3.ResponseBody;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.common.user.profile.UserService;
import pl.mobilemanagement.izarzadca.databinding.ActivityPromoteServiceBinding;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.ProviderOrdersApi;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;

public class PromoteServiceActivity extends AppCompatActivity {

    @Inject
    UserService userService;

    @Inject
    ProviderOrdersApi providerOrdersApi;

    Toolbar toolbar;
    TextView payNowButton;


    public Subscription subscription;

    public Subscription updateSubscription;

    public Subscription loadStripeInformationSubscriber;

    //private PaymentSheet paymentSheet;

    private String paymentIntentClientSecret;

    private String customerId;

    private String ephemeralKeySecret;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        App.component.inject(this);

        ActivityPromoteServiceBinding binding = ActivityPromoteServiceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        toolbar = binding.toolbar.toolbarWhiteArrow;
        payNowButton = binding.payNowButton;

        setSupportActionBar(toolbar);

        payNowButton.setEnabled(false);
        payNowButton.setOnClickListener(v -> presentPaymentSheet());

        //paymentSheet = new PaymentSheet(this, this::onPaymentSheetResult);

        fetchInitData();
        subscription = userService.getProfilePreferOnlyCache()
                .compose(Rx.applySchedulers())
                .subscribe();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Rx.safeUnsubscribe(subscription, updateSubscription);
    }

    public static void start(Context context) {
        context.startActivity(new Intent(context, PromoteServiceActivity.class));
    }

    private void fetchInitData() {
//        loadStripeInformationSubscriber = providerOrdersApi.getStripePaymentInformation(new OrderId(orderId))
//                .compose(Rx.applySchedulers())
//                .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager()))
//                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
//                .subscribe(this::presentPaymentSheet, throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    private void presentPaymentSheet() {
        /*paymentSheet.presentWithPaymentIntent(
                paymentIntentClientSecret,
                new PaymentSheet.Configuration(
                        "Example, Inc.",
                        new PaymentSheet.CustomerConfiguration(
                                customerId,
                                ephemeralKeySecret
                        )
                )
        );*/
    }

    /*private void onPaymentSheetResult(
            final PaymentSheetResult paymentSheetResult
    ) {
        if (paymentSheetResult instanceof PaymentSheetResult.Canceled) {
            Toast.makeText(
                    this,
                    "Payment Canceled",
                    Toast.LENGTH_LONG
            ).show();
        } else if (paymentSheetResult instanceof PaymentSheetResult.Failed) {
            Toast.makeText(
                    this,
                    "Payment Failed. See logcat for details.",
                    Toast.LENGTH_LONG
            ).show();

            Timber.e(((PaymentSheetResult.Failed) paymentSheetResult).getError(), "Got error: ");
        } else if (paymentSheetResult instanceof PaymentSheetResult.Completed) {
            Toast.makeText(
                    this,
                    "Payment Complete",
                    Toast.LENGTH_LONG
            ).show();
        }
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}
