package pl.mobilemanagement.izarzadca.tools;

import java.util.List;

public interface LCE<T> {

    void showProgressBar();

    void hideProgressBar();

    void hideError();

    void showEmptyListError();

    void showConnectionError();

    void setData(List<T> data);

}
