package pl.mobilemanagement.izarzadca.tabs.myservices.pending.model;

public class StripePaymentInformationModel {
    public String amount;
    public String currency;
    public String last4;
    public String brand;
}
