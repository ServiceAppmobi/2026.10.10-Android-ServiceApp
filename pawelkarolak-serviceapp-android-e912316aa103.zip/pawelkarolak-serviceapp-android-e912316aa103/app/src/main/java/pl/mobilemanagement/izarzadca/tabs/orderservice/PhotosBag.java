package pl.mobilemanagement.izarzadca.tabs.orderservice;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PhotosBag implements Serializable {
    public String firstPhoto;
    public String secondPhoto;
    public String thirdPhoto;

    public void setPhoto(int photoPos, String uriPath) {
        if (photoPos == 1)
            firstPhoto = uriPath;
        else if (photoPos == 2)
            secondPhoto = uriPath;
        else {
            thirdPhoto = uriPath;
        }
    }

    public void removePhotoByPos(int photoPos) {
        if (photoPos == 1)
            firstPhoto = null;
        else if (photoPos == 2)
            secondPhoto = null;
        else {
            thirdPhoto = null;
        }
    }

    public List<File> getFileList() {
        List<File> fileList = new ArrayList<>();
        if (firstPhoto != null)
            fileList.add(new File(firstPhoto));
        if (secondPhoto != null)
            fileList.add(new File(secondPhoto));
        if (thirdPhoto != null)
            fileList.add(new File(thirdPhoto));
        return fileList;
    }

    public List<String> getUriList() {
        List<String> fileList = new ArrayList<>(3);
        fileList.add(firstPhoto);
        fileList.add(secondPhoto);
        fileList.add(thirdPhoto);
        return fileList;
    }
}
