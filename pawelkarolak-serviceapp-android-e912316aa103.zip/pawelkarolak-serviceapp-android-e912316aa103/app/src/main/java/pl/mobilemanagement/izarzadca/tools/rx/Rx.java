package pl.mobilemanagement.izarzadca.tools.rx;

import android.util.Log;

import java.util.List;

import pl.mobilemanagement.izarzadca.tools.LCE;
import rx.Completable;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public final class Rx {
    private final static Observable.Transformer<Observable, Observable> schedulersTransformer =
            observable -> observable.subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread());

    @SuppressWarnings("unchecked")
    public static <T> Observable.Transformer<T, T> applySchedulers() {
        return (Observable.Transformer<T, T>) schedulersTransformer;
    }

    public static Completable.Transformer applySchedulersCompletable() {
        return completable -> completable.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public static void safeUnsubscribe(Subscription loadListSubsciber) {
        if (loadListSubsciber != null && !loadListSubsciber.isUnsubscribed()) {
            loadListSubsciber.unsubscribe();
        }
    }

    public static void safeUnsubscribe(Subscription subscription, Subscription... subscriptions) {
        safeUnsubscribe(subscription);
        for (Subscription sub : subscriptions) {
            safeUnsubscribe(sub);
        }
    }


    public static <T> Observable.Transformer<List<T>, List<T>> applyLCE(LCE lce) {
        return observable -> observable.doOnSubscribe(() -> {
            lce.hideError();
            lce.showProgressBar();
        }).doOnUnsubscribe(lce::hideProgressBar)
                .doOnNext(ts -> {
                    if (ts.isEmpty()) lce.showEmptyListError();
                    else lce.hideError();
                });
    }


    public static <T> Observable.Transformer<List<T>, List<T>> applyDataLoader(LCE<T> lce) {
        return observable -> observable.doOnNext(lce::setData)
                .doOnError(throwable -> {
                    throwable.printStackTrace();
                    lce.showConnectionError();
                })
                .onErrorResumeNext(throwable -> Observable.empty());
    }
    public static <T> Observable.Transformer<List<T>, List<T>> applyDataLoaderWithError(LCE<T> lce) {
        return observable -> observable.doOnNext(lce::setData)
                .doOnError(throwable -> Log.i("CommunityInfo", String.valueOf(throwable)))
                .onErrorResumeNext(throwable -> Observable.empty());
    }


}
