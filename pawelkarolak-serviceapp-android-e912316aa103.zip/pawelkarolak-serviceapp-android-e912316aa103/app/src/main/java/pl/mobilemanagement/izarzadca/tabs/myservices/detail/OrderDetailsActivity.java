package pl.mobilemanagement.izarzadca.tabs.myservices.detail;

import static android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME;
import static android.provider.CalendarContract.EXTRA_EVENT_END_TIME;
import static android.provider.CalendarContract.Events;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.common.model.api.OrderId;
import pl.mobilemanagement.izarzadca.databinding.OrderDetailsActivityBinding;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.ProviderOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model.CompleteOrderDetailsApiModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model.DuringOrderDetailsApiModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model.PendingOrderDetailsApiModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.di.DaggerMyServicesComponent;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;

public class OrderDetailsActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String ORDER_ID_KEY = "ORDER_ID";

    private static final String ORDER_TYPE = "ORDER_TYPE";

    private final Action1<Throwable> onErrorAction = throwable -> ApiErrorDialogHelper.show(this, throwable);

    @Inject
    ProviderOrdersApi providerOrdersApi;

    private OrderDetailsActivityBinding binding;

    private Subscription subscription;

    public static void start(Context context, String orderId, OrderServiceType orderType) {
        final Intent startIntent = getIntent(context, orderId, orderType);
        context.startActivity(startIntent);
    }

    public static Intent getIntent(Context context, String orderId, OrderServiceType orderType) {
        final Intent startIntent = new Intent(context, OrderDetailsActivity.class);
        startIntent.putExtra(ORDER_ID_KEY, orderId);
        startIntent.putExtra(ORDER_TYPE, orderType);
        return startIntent;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerMyServicesComponent.builder().applicationComponent(App.component).build().inject(this);
        binding = OrderDetailsActivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.backArrow.setOnClickListener(this);
        requestForDetails();
    }

    private void requestForDetails() {
        final OrderServiceType orderType = (OrderServiceType) getIntent().getSerializableExtra(ORDER_TYPE);
        final String orderId = getIntent().getStringExtra(ORDER_ID_KEY);
        final OrderId orderIdApiModel = new OrderId(orderId);
        subscribeOnOrderDetail(orderType, orderIdApiModel);
    }

    private void subscribeOnOrderDetail(OrderServiceType orderType, OrderId orderIdApiModel) {
        if (orderType == OrderServiceType.PENDING) {
            subscription = providerOrdersApi.getPendingOrderDetails(orderIdApiModel)
                    .compose(applyLoaderWithSchedulers())
                    .subscribe(this::updatePendingOrderDetails, onErrorAction);
        } else if (orderType == OrderServiceType.DURING) {
            subscription = providerOrdersApi.getDuringOrderDetails(orderIdApiModel)
                    .compose(applyLoaderWithSchedulers())
                    .subscribe(this::updateDuringOrderDetails, onErrorAction);
        } else {
            subscription = providerOrdersApi.getCompletedOrderDetails(orderIdApiModel)
                    .compose(applyLoaderWithSchedulers())
                    .subscribe(this::updateCompleteOrderDetails, onErrorAction);
        }
    }

    private void updatePendingOrderDetails(PendingOrderDetailsApiModel order) {
        setButtonsVisibility(View.GONE);
        setCustomerVisibility(View.GONE);
        updateData(
            order.startDateTime, order.endDateTime,
            order.serviceName, null, null
        );
    }

    private void updateCompleteOrderDetails(CompleteOrderDetailsApiModel order) {
        setButtonsVisibility(View.GONE);
        setCustomerVisibility(View.GONE);
        updateData(order.closedDateTime, order.closedDateTime, order.serviceName, null, null);
    }

    private void updateDuringOrderDetails(DuringOrderDetailsApiModel order) {
        setButtonsVisibility(View.VISIBLE);
        setCustomerVisibility(View.VISIBLE);
        updateData(order.startDateTime, order.endDateTime, order.serviceName, order.getFullName(), order.phone);
        binding.btnCallToCustomer.setOnClickListener(v -> callToCustomer(order.phone));
        binding.btnSaveInCalendar.setOnClickListener(v -> {
            String title = order.serviceName + " " + order.name + " " + order.lastname;
            saveInCalendar(title, order.issueDescription, order.getAddress(), order.startDateTime, order.endDateTime);
        });
    }

    private final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yy hh:mm a", Locale.getDefault());

    private void updateData(
            Date startDate, Date endDate,
            String serviceName,
            String name,
            String phone
    ) {
        binding.category.setText(serviceName);

        String startDateText = simpleDateFormat.format(startDate);
        binding.etFromDate.setText(startDateText);
        String endDateText = simpleDateFormat.format(endDate);
        binding.etToDate.setText(endDateText);

        binding.tvCustomerName.setText(name);
        binding.tvCustomerPhone.setText(phone);
    }

    private void setCustomerVisibility(int visibility) {
        binding.customerGroup.setVisibility(visibility);
    }

    private void setButtonsVisibility(int visibility) {
        binding.btnSaveInCalendar.setVisibility(visibility);
        binding.btnCallToCustomer.setVisibility(visibility);
    }

    public <T> Observable.Transformer<T, T> applyLoaderWithSchedulers() {
        return observable -> observable.compose(Rx.applySchedulers())
                .doOnSubscribe(this::showLoaderView)
                .doOnCompleted(this::hideLoaderView);
    }

    private void hideLoaderView() {
        binding.progressBar.setVisibility(View.GONE);
        binding.group.setVisibility(View.VISIBLE);
    }

    private void showLoaderView() {
        binding.progressBar.setVisibility(View.VISIBLE);
        binding.group.setVisibility(View.GONE);
    }

    private void saveInCalendar(String title, String description, String location, Date startTime, Date endTime) {
        long start = ((startTime == null) ? new Date() : startTime).getTime();
        long end = ((endTime == null) ? new Date() : endTime).getTime();
        Intent intent = new Intent(Intent.ACTION_INSERT)
                .setData(Events.CONTENT_URI)
                .putExtra(EXTRA_EVENT_BEGIN_TIME, start)
                .putExtra(EXTRA_EVENT_END_TIME, end)
                .putExtra(Events.TITLE, title)
                .putExtra(Events.DESCRIPTION, description)
                .putExtra(Events.EVENT_LOCATION, location)
                .putExtra(Events.AVAILABILITY, Events.AVAILABILITY_BUSY);
        startActivityForResult(intent, 124);
    }

    private void callToCustomer(String phoneNumber) {
        Intent callIntent = new Intent(Intent.ACTION_VIEW);
        callIntent.setData(Uri.parse("tel:" + phoneNumber));
        startActivity(callIntent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        finish();
        return true;
    }

    @Override
    public void onClick(View v) {
        if (v == binding.backArrow)
            finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Rx.safeUnsubscribe(subscription);
    }
}
