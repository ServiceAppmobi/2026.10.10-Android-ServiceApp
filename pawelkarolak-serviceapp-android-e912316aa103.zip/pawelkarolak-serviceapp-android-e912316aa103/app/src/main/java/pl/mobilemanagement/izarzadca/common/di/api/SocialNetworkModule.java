package pl.mobilemanagement.izarzadca.common.di.api;

import android.app.Application;

import androidx.annotation.NonNull;

import com.facebook.CallbackManager;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import pl.mobilemanagement.izarzadca.R;

@Module
public class SocialNetworkModule {
    @Provides
    @Singleton
    @NonNull
    LoginManager provideLoginManager() {
        return LoginManager.getInstance();
    }

    @Provides
    @Singleton
    @NonNull
    GoogleSignInOptions provideGoogleSignInOptions(Application app) {
        return new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(app.getString(R.string.server_client_id))
                .requestEmail()
                .build();
    }

    @Provides
    @Singleton
    @NonNull
    GoogleSignInClient provideGoogleSignInClient(Application app, GoogleSignInOptions gso) {
        return GoogleSignIn.getClient(app, gso);
    }

    @Provides
    @Singleton
    @NonNull
    CallbackManager provideCallbackManager() {
        return CallbackManager.Factory.create();
    }
}
