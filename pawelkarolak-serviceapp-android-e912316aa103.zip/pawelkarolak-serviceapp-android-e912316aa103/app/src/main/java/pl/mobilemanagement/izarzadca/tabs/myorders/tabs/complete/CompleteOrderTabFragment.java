package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete;

import static pl.mobilemanagement.izarzadca.tools.rx.Rx.applyDataLoader;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.applyLCE;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.safeUnsubscribe;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jakewharton.rxbinding.support.v4.widget.RxSwipeRefreshLayout;

import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.databinding.RecyclerPullViewFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.myorders.api.ClientOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myorders.di.DaggerMyOrdersComponent;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete.model.CompleteOrder;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete.view.CompletedAdapter;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.rate_order.OrderRateActivity;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.ItemClickListener;
import pl.mobilemanagement.izarzadca.tools.LCE;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class CompleteOrderTabFragment extends TitledTabFragment implements ItemClickListener, LCE<CompleteOrder>, View.OnClickListener {
    public Subscription refreshSubscription;

    @Inject
    ClientOrdersApi clientOrdersApi;

    private RecyclerPullViewFrameBinding binding;

    private final CompletedAdapter completedOrdersAdapter = new CompletedAdapter(this);

    private Subscription fetchSubscription;

    private EarthlyLoadingDialog earthlyDialog;

    @Override
    public int getTitleResource() {
        return R.string.my_order_tab_completed;
    }

    @Override
    protected int getLayout() {
        return R.layout.recycler_pull_view_frame;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerMyOrdersComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding = RecyclerPullViewFrameBinding.bind(view);
        initRecyclerView();
        fetchSubscription = fetchCompleteOrders().subscribe();
        refreshSubscription = RxSwipeRefreshLayout.refreshes(binding.refreshLayout)
                .flatMap(aVoid -> fetchCompleteOrders())
                .subscribe();
        binding.noItems.noItemsMessage.setText(getString(R.string.no_orders));
        binding.noItems.btnRefresh.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnRefresh) {
            fetchSubscription = fetchCompleteOrders().subscribe();
        }
    }

    private Observable<List<CompleteOrder>> fetchCompleteOrders() {
        Rx.safeUnsubscribe(fetchSubscription);
        return clientOrdersApi.getCompletedOrders()
                .compose(applySchedulers())
                .compose(applyLCE(this))
                .compose(applyDataLoader(this));
    }

    private void initRecyclerView() {
        binding.listRecyclerView.setAdapter(completedOrdersAdapter);

        applySchedulers(
                clientOrdersApi.getCompletedOrders().flatMap(completeOrders -> Observable.empty())
        ).subscribe();
    }

    private Observable<String> applySchedulers(Observable<List<CompleteOrder>> completedOrders) {
        return Observable.empty();
    }

    <T> Observable.Transformer<T, T> applySchedulers() {
        return observable -> observable.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    @Override
    public void setData(List<CompleteOrder> data) {
        completedOrdersAdapter.setDataList(data);
        binding.noItems.getRoot().setVisibility(data.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        safeUnsubscribe(fetchSubscription);
        safeUnsubscribe(refreshSubscription);
    }

    @Override
    public void onItemClick(int adapterPosition) {
        final String orderId = completedOrdersAdapter.getItem(adapterPosition).id;
        OrderRateActivity.start(getActivity(), orderId);
    }

    @Override
    public void showProgressBar() {
        earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager());
        //        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgressBar() {
        //        progressBar.setVisibility(View.GONE);
        ProgressHelper.safeDismiss(earthlyDialog);
        binding.refreshLayout.setRefreshing(false);
    }

    @Override
    public void hideError() {
        binding.listError.setVisibility(View.GONE);
        binding.noItems.getRoot().setVisibility(View.GONE);
    }

    @Override
    public void showEmptyListError() {
        binding.noItems.getRoot().setVisibility(View.VISIBLE);
    }

    @Override
    public void showConnectionError() {
        binding.noItems.getRoot().setVisibility(View.GONE);
        binding.listError.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.list_view_connection_error);
    }

  /*@Override
  public void onTargetNotification(Observable<Message> oMessage) {
    oMessage.subscribe(message -> fetchCompleteOrders());
  }

  @Override
  public void onMismatchTargetNotification(Observable<Message> oMessage) {

  }

  @Override
  public boolean matchesTarget(String key) {
    return PushType.parseOf(key) == PushType.PROVIDER_NEW_PENDING;
  }*/
}
