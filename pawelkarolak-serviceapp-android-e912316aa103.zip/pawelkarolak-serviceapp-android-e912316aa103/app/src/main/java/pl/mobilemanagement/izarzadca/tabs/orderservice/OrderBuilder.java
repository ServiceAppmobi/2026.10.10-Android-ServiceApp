package pl.mobilemanagement.izarzadca.tabs.orderservice;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pl.mobilemanagement.izarzadca.tabs.orderservice.model.OrderSummary;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.order.OrderRequest;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider.ServiceProvider;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider.ServiceProviderRequest;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.Place;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceGroup;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import pl.mobilemanagement.izarzadca.tools.Base64Helper;

public class OrderBuilder implements Serializable {
    private final PhotosBag photosBag = new PhotosBag();
    private ServiceGroup serviceGroup;
    private ServiceModel serviceType;
    private Date startDateTime;
    private Date endDateTime;
    private String issueDescription;
    private List<ServiceProvider> serviceProviders;
    private Place place;

    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }

    public void setProviders(List<ServiceProvider> selectedProviders) {
        this.serviceProviders = selectedProviders;
    }

    public OrderRequest buildOrderRequest() {
        OrderRequest orderRequest = OrderRequest.createOrderSpecificByData(place);
        orderRequest.setServiceType(serviceType);
        orderRequest.startDateTime = startDateTime;
        orderRequest.endDateTime = endDateTime;
        orderRequest.issueDescription = issueDescription;
        orderRequest.setServiceProviders(serviceProviders);
        orderRequest.photos = Base64Helper.filesToBase64(photosBag.getFileList());
        return orderRequest;
    }

    public ServiceProviderRequest buildProviderRequest() {
        return ServiceProviderRequest.createProviderRequest(serviceType.serviceId, place);
    }

    public void setPlace(Place place) {
        this.place = place;
    }

    public OrderSummary buildSummary() {
        return new OrderSummary(startDateTime, endDateTime, issueDescription, serviceGroup.name,
                serviceType.name, getProvidersName(), photosBag.getFileList());
    }

    private List<String> getProvidersName() {
        final List<String> providersName = new ArrayList<>();
        for (ServiceProvider serviceProvider : serviceProviders) {
            providersName.add(serviceProvider.name);
        }
        return providersName;
    }

    public void setServiceGroupWithType(ServiceGroup serviceGroup, ServiceModel serviceType) {
        this.serviceGroup = serviceGroup;
        this.serviceType = serviceType;
    }

    public void setProposeOrderDate(Date normalizeStartDate, Date normalizeEndDate) {
        startDateTime = normalizeStartDate;
        endDateTime = normalizeEndDate;
    }

    public PhotosBag getPhotos() {
        return photosBag;
    }
}
