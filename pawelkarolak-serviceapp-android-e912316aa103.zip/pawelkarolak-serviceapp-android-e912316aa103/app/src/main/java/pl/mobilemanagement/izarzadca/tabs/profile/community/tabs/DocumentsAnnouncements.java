package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.CloseOrderClickListener;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.common.listview_item;
import pl.mobilemanagement.izarzadca.tabs.profile.community.common.listview_popup;
import pl.mobilemanagement.izarzadca.tabs.profile.community.di.DaggerMyCommunityComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetAnnouncements;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class DocumentsAnnouncements extends TitledTabFragment implements CloseOrderClickListener {

    @Inject
    CommunityApi communityApi;

    private Subscription fetchSubscription;
    private ListView listView1;

    @Override
    public int getTitleResource() {
        return R.string.tab_DocumentsAnnouncements;
    }

    @Override
    public void onCloseOrderClick(Order order) {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DaggerMyCommunityComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchSubscription = communityApi.getAnnouncements()
                .onErrorResumeNext(throwable -> Observable.empty())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .compose(ProgressDialog.create(getContext()))
                .subscribe(this::setData, e -> {
                    e.printStackTrace();
                    ApiErrorDialogHelper.show(getContext(), e);
                });
    }

    @Override
    public void onPause() {
        super.onPause();
        Rx.safeUnsubscribe(fetchSubscription);
    }

    private void setData(List<GetAnnouncements> getAnnouncementses) {

        listview_item[] listData = new listview_item[getAnnouncementses.size()];

        int i = 0;
        for (GetAnnouncements aaaa : getAnnouncementses) {
            Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String validUntil = "-";
            String createDate = "-";
            if (aaaa.validUntil != null) {
                validUntil = formatter.format(aaaa.validUntil);
            }

            if (aaaa.createDate != null) {
                createDate = formatter.format(aaaa.createDate);
            }
            Log.e("CommunityInfo", formatter.format(aaaa.createDate));
            Log.e("CommunityInfo2", validUntil);
            listData[i++] = new listview_item(
                aaaa.name,
                createDate,
                validUntil,
                aaaa.community,
                "",
                aaaa.messageBody,
                aaaa.isActive
            );
        }

        listview_popup adapter = new listview_popup(
            getContext(), R.layout.list_annoucement_item, listData,
            R.string.created_on,
            R.string.tab_DocumentsAnnouncementsValidUntil,
            R.string.tab_DocumentsAnnouncementsCommunity,
            0
        );
        adapter.switchBackgroundWhenActive = true;

        listView1.setAdapter(adapter);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        listView1 = view.findViewById(R.id.listViewAnn);
    }


    @Override
    protected int getLayout() {
        return R.layout.list_annoucement;
    }
}
