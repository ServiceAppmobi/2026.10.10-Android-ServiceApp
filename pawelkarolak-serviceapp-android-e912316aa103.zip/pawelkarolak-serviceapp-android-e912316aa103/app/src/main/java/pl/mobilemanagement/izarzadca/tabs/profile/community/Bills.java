package pl.mobilemanagement.izarzadca.tabs.profile.community;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.badge.MyOrderBadge;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabsFragmentAdapter;
import pl.mobilemanagement.izarzadca.databinding.TabMyBillsBinding;
import pl.mobilemanagement.izarzadca.tabs.TabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.BillsHistory;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.BillsSummary;
import rx.android.schedulers.AndroidSchedulers;

/*
 * Wspolnota
 * Informacje
 * Finanse
 * Czlonkowie
 * */
public class Bills extends TabFragment {
    @Inject
    MyOrderBadge myOrderBadgeListener;

    public Bills() {
        App.component.inject(this);
    }

    @Override
    public int getIconResource() {
        return R.drawable.ico_tab_my_orders;
    }

    @Override
    public int getTitleResource() {
        return R.string.tab_my_bills;
    }

    @Override
    protected int getLayout() {
        return R.layout.tab_my_bills;
    }

    @Override
    public void onViewCreated(@NotNull View view, @Nullable Bundle savedInstanceState) {
        TabMyBillsBinding binding = TabMyBillsBinding.bind(view);

        TitledTabsFragmentAdapter<TitledTabFragment> tabsFragmentAdapter = new TitledTabsFragmentAdapter<>(
            getContext(),
            getChildFragmentManager(),
            Arrays.asList(
                new BillsSummary(),
                new BillsHistory()
            )
        );

        binding.BillsViewPager.setAdapter(tabsFragmentAdapter);
        binding.BillsTabLayout.setupWithViewPager(binding.BillsViewPager);
    }

    @Override
    protected void bindTabView(View indicator) {
        myOrderBadgeListener.getBadgeIsAvailable()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(hasUnreaded -> {
                    indicator.setVisibility(hasUnreaded ? View.VISIBLE : View.GONE);
                });
    }

    @Override
    public void onResume() {
        super.onResume();
        myOrderBadgeListener.informBadgeWatched();
    }
}
