package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view;

public interface SelectedCompanyProviderChangedListener {
    void onSelectedProvidersChange(boolean isNotSelectedCompany);
}
