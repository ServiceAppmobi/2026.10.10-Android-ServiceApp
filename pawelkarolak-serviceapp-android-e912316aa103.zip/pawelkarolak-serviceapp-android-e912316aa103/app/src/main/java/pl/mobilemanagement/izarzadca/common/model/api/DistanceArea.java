package pl.mobilemanagement.izarzadca.common.model.api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DistanceArea {
    @Expose
    @SerializedName("id")
    public final long id;
    @Expose
    @SerializedName("value")
    public final String value;

    public DistanceArea(long id, String value) {
        this.id = id;
        this.value = value;
    }
}
