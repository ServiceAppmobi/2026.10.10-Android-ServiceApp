package pl.mobilemanagement.izarzadca.tabs.profile.community;

import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.applySchedulers;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.safeUnsubscribe;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.internal.CheckableImageButton;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.badge.MyOrderBadge;
import pl.mobilemanagement.izarzadca.databinding.FragmentFailureReportBinding;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.TabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.di.DaggerMyCommunityComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetFailureSubjects;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.RegisterFailureReport;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.HomeTabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.postfailure.PostFailureCategorySpinnerItem;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.spinner.HintAdapter;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by katak on 10.01.2017.
 */
/*
* Wspolnota
* Informacje
* Finanse
* Czlonkowie
* */
public class FailureReport extends TabFragment implements AdapterView.OnItemClickListener, View.OnClickListener {

    private FragmentFailureReportBinding binding;

    @Inject
    MyOrderBadge myOrderBadgeListener;

    @Inject
    CommunityApi communityApi;

    private GetFailureSubjects selectedCategory;

    private Subscription failureSubjectsSubscription;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerMyCommunityComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }

    @Override
    public int getIconResource() {
        return R.drawable.ico_tab_my_orders;
    }

    @Override
    public int getTitleResource() {
        return R.string.tab_FailureReport;
    }

    @Override
    protected int getLayout() {
        return R.layout.fragment_failure_report;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = FragmentFailureReportBinding.bind(view);
        failureSubjectsSubscription = communityApi.getFailureSubjects()
                .compose(applySchedulers())
                .doOnNext(this::setData)
                .doOnError(throwable -> ApiErrorDialogHelper.show(getContext(), throwable))
                .subscribe();

        CheckableImageButton startIcon =
                binding.description.findViewById(com.google.android.material.R.id.text_input_start_icon);

        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) startIcon.getLayoutParams();
        layoutParams.gravity = Gravity.TOP | Gravity.START;

        binding.etCategory.setOnItemClickListener(this);
        binding.postFailure.setOnClickListener(this);
    }

    private Validator validateInput() {
        Validator validator = new Validator();
        if (getTrimmedText(binding.etSubject).isEmpty()) {
            validator.addError(getString(R.string.post_failure_title_empty));
        }
        if (selectedCategory == null) {
            validator.addError(getString(R.string.post_failure_category_empty));
        }
        if (getTrimmedText(binding.etDescription).isEmpty()) {
            validator.addError(getString(R.string.post_failure_description_empty));
        }
        return validator;
    }

    @Override
    public void onClick(View v) {
        if (v == binding.postFailure) {
            Validator validator = validateInput();
            if (!validator.isValid()) {
                ValidationErrorDialogHelper.show(getContext(), validator);
                return;
            }
            RegisterFailureReport req = new RegisterFailureReport();
            req.description = getTrimmedText(binding.etDescription);
            req.title = getTrimmedText(binding.etSubject);
            req.subjectId = selectedCategory.id;
            sendReportAboutFailure(req);
        }
    }

    private void close(boolean result) {
        View view = requireActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

        if(result) {
            if(((MainActivity)requireActivity()).hasHomeScreen()) {
                HomeTabFragment homeTabFragment = new HomeTabFragment();
                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.main_frame, homeTabFragment)
                        .commit();
            } else {
                Documents documents = new Documents();
                requireActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.main_frame, documents)
                        .commit();
            }
        } else {
            requireActivity().getSupportFragmentManager().popBackStack();
        }
    }

    private void sendReportAboutFailure(RegisterFailureReport req) {
        communityApi.registerFailureReport(req)
                .compose(applySchedulers())
                .compose(ProgressDialog.create(getContext()))
                .toCompletable()
                .subscribe(() -> close(true), throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        final PostFailureCategorySpinnerItem item = (PostFailureCategorySpinnerItem) parent.getAdapter().getItem(position);
        this.selectedCategory = item.getServiceModel();
    }

    private void setData(List<GetFailureSubjects> failureSubjects) {
        List<PostFailureCategorySpinnerItem> spinnerItems = new ArrayList<>(failureSubjects.size());
        for (GetFailureSubjects failureSubject : failureSubjects) {
            spinnerItems.add(new PostFailureCategorySpinnerItem(failureSubject));
        }
        HintAdapter.setHintData(binding.etCategory, spinnerItems);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        safeUnsubscribe(failureSubjectsSubscription);
    }

    @Override
    protected void bindTabView(View indicator) {
        myOrderBadgeListener.getBadgeIsAvailable()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(hasUnread -> indicator.setVisibility(hasUnread ? View.VISIBLE : View.GONE));
    }

    @Override
    public void onResume() {
        super.onResume();
        myOrderBadgeListener.informBadgeWatched();
    }

    /*@Override
    public void onTargetNotification(Observable<Message> oMessage) {
        oMessage.subscribe(message -> {
            myOrderBadgeListener.informBadgeWatched();
        });
    }

    @Override
    public void onMismatchTargetNotification(Observable<Message> oMessage) {

    }

    @Override
    public boolean matchesTarget(String key) {
        return PushType.isMyOrderPush(key);
    }*/
}
