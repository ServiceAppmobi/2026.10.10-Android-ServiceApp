package pl.mobilemanagement.izarzadca.tabs.myservices.pending.model;

import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;

public class PendingServiceOrder extends ServiceOrder {
    public String distanceToCustomer;
    public String street;
    public String number;
    public String postalCode;
    public String city;
    public String country;
    public String name;
    public String lastname;
    public boolean isPaymentRequired;
}
