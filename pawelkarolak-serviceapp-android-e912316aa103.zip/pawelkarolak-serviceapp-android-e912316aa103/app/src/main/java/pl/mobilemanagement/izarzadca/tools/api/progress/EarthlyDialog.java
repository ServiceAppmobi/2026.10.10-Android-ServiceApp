package pl.mobilemanagement.izarzadca.tools.api.progress;

import androidx.fragment.app.FragmentManager;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import rx.Completable;
import rx.Observable;

public class EarthlyDialog {

  private EarthlyLoadingDialog dialog;

  public static <T> Observable.Transformer<T, T> create(FragmentManager manager) {
    return new EarthlyDialog().RxCompose(manager);
  }

  public static Completable.Transformer createCompletable(FragmentManager manager) {
    return new EarthlyDialog().RxCompletableCompose(manager);
  }

  private EarthlyDialog() {
  }

  public <T> Observable.Transformer<T, T> RxCompose(FragmentManager manager) {
    return observable -> observable.doOnSubscribe(() -> dialog = ProgressHelper.showEarthly(manager))
      .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(dialog));
  }

  public Completable.Transformer RxCompletableCompose(FragmentManager manager) {
    return completable -> completable.doOnSubscribe((aVoid) -> dialog = ProgressHelper.showEarthly(manager))
      .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(dialog));
  }
}
