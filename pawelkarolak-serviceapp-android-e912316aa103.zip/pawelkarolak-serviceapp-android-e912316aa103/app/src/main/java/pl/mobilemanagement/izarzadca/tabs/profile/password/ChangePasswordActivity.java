package pl.mobilemanagement.izarzadca.tabs.profile.password;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.textfield.TextInputEditText;
import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.databinding.ActivityChangePasswordBinding;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ChangePasswordApiModel;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tabs.profile.di.DaggerProfileComponent;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;

public class ChangePasswordActivity extends AppCompatActivity {

    @Inject
    ProfileApi profileApi;

    Toolbar toolbar;
    TextInputEditText inputPassword;
    TextInputEditText inputNewPassword;

    private Subscription subscription;

    public static void start(Context context) {
        context.startActivity(new Intent(context, ChangePasswordActivity.class));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerProfileComponent.builder().applicationComponent(App.component).build().inject(this);

        ActivityChangePasswordBinding binding = ActivityChangePasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        toolbar = binding.toolbar.toolbarWhiteArrow;
        inputPassword = binding.inputPassword;
        inputNewPassword = binding.inputNewPassword;
        binding.changePasswordButton.setOnClickListener(v -> onChangePasswordClick());

        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private String getCurrentPassword() {
        return inputPassword.getText().toString();
    }

    public String getNewPassword() {
        return inputNewPassword.getText().toString();
    }

    void onChangePasswordClick() {
        final String currentPassword = getCurrentPassword();
        final String newPassword = getNewPassword();

        subscription = profileApi.updatePassword(new ChangePasswordApiModel(currentPassword, newPassword))
                .compose(Rx.applySchedulers())
                .compose(ProgressDialog.create(this))
                .subscribe(aVoid -> finish(),
                        throwable -> ApiErrorDialogHelper.show(this, throwable));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Rx.safeUnsubscribe(subscription);
    }
}
