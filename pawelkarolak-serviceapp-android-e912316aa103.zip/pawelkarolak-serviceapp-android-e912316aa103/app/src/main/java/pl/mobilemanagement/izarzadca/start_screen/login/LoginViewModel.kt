package pl.mobilemanagement.izarzadca.start_screen.login

import android.app.Application
import android.os.Bundle
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.facebook.*
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject
import pl.mobilemanagement.izarzadca.App
import pl.mobilemanagement.izarzadca.BuildConfig
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.common.di.api.UserLoginRequest
import pl.mobilemanagement.izarzadca.common.model.api.LoginResponse
import pl.mobilemanagement.izarzadca.common.model.api.SocialErrorResponse
import pl.mobilemanagement.izarzadca.common.model.api.SocialSignInRequest
import pl.mobilemanagement.izarzadca.common.notification.api.NotificationRegisterService
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource
import pl.mobilemanagement.izarzadca.start_screen.login.di.LoginServiceApi
import pl.mobilemanagement.izarzadca.start_screen.login_or_register.SocialApiService
import pl.mobilemanagement.izarzadca.start_screen.login_or_register.SocialData
import pl.mobilemanagement.izarzadca.tools.SingleLiveData
import pl.mobilemanagement.izarzadca.tools.rx.Rx
import retrofit2.HttpException
import rx.functions.Action1
import timber.log.Timber
import javax.inject.Inject

class LoginViewModel @Inject constructor(
    private val app: Application,
    val loginManager: LoginManager,
    val callbackManager: CallbackManager,
    private val tokenDataSource: TokenDataSource,
    private val accountTypeDataSource: AccountTypeDataSource
): ViewModel(), FacebookCallback<LoginResult> {

    private lateinit var socialApiService: SocialApiService
    private lateinit var loginServiceApi: LoginServiceApi
    private lateinit var notificationRegisterService: NotificationRegisterService

    enum class UserState {
        USER_EXIST,
        NEW_USER,
        LOGIN_SUCCESS;

        open var isProvider = false
    }

    var socialData = SocialData()

    private val _isUserExist = SingleLiveData<UserState>()
    val isUserExist: LiveData<UserState> = _isUserExist

    private val _error = SingleLiveData<String>()
    val error: LiveData<String> = _error

    private val _errorDialog = SingleLiveData<Throwable>()
    val errorDialog: LiveData<Throwable> = _errorDialog

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading

    init {
        provideService()
        loginManager.registerCallback(callbackManager, this)
    }

    fun setGoogleAccount(account: GoogleSignInAccount) {
        val socialSignInRequest = SocialSignInRequest(
                userToken = account.idToken.orEmpty(),
        )
        socialData.email = account.email
        socialData.firstName = account.givenName
        socialData.lastName = account.familyName
        sendSocialRequest(socialSignInRequest, true)
    }

    private fun sendSocialRequest(socialSignInRequest: SocialSignInRequest, isGoogle: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _loading.postValue(true)
                val loginResponse = if(isGoogle)
                    socialApiService.signInWithGoogle(socialSignInRequest.userToken)
                else
                    socialApiService.signInWithFacebook(socialSignInRequest.userToken)
                if (loginResponse.accountType == null) {
                    _error.postValue(app.getString(R.string.unsupported_user))
                    return@launch
                }
                accountTypeDataSource.setVersionCode(BuildConfig.VERSION_CODE)
                tokenDataSource.saveTokenInfo(loginResponse.accessToken)
                accountTypeDataSource.saveAccountType(loginResponse.accountType)
                _isUserExist.postValue(UserState.USER_EXIST)
            } catch(e: HttpException) {
                val errorBody = Gson().fromJson(e.response()?.errorBody()?.string(), SocialErrorResponse::class.java)
                if(errorBody.code == "500")
                    _isUserExist.postValue(UserState.NEW_USER)
                else
                    _error.postValue(errorBody.message.orEmpty())
            } catch(e: Exception) {
                e.printStackTrace()
            } finally {
                _loading.postValue(false)
            }
        }
    }

    override fun onSuccess(result: LoginResult) {
        val accessToken = AccessToken.getCurrentAccessToken() ?: return

        val request = GraphRequest.newMeRequest(accessToken) { obj: JSONObject?, response: GraphResponse? ->
            Timber.e("facebook response %s", response.toString())
            try {
                val email = obj?.getString("email")
                val firstName = obj?.getString("first_name")
                val lastName = obj?.getString("last_name")
                val avatar = obj?.getJSONObject("picture")?.getJSONObject("data")?.getString("url")
                val signInRequest = SocialSignInRequest(
                        userToken = accessToken.token,
                )
                Timber.e("onSuccess facebook picture=%s", avatar)
                Timber.e("onSuccess facebook email=%s", email)
                socialData.email = email
                socialData.firstName = firstName
                socialData.lastName = lastName
                sendSocialRequest(signInRequest, false)
            } catch (e: JSONException) {
                e.printStackTrace()
            }
        }
        val parameters = Bundle()
        parameters.putString("fields", "id,email,picture,first_name,last_name")
        request.parameters = parameters
        request.executeAsync()
    }

    override fun onCancel() {
        Timber.e("facebook onCancel")
    }

    override fun onError(error: FacebookException) {
        Timber.e("facebook onError %s", error.message)
    }

    override fun onCleared() {
        super.onCleared()
        loginManager.unregisterCallback(callbackManager)
    }

    fun setCountry(countryId: String) {
        accountTypeDataSource.setCountry(countryId)
        provideService()
    }

    fun hasCountry() = accountTypeDataSource.hasCountry()

    private fun provideService() {
        socialApiService = App.component.provideSocialApiService()
        loginServiceApi = App.component.provideLoginServiceApi()
        notificationRegisterService = App.component.provideNotificationRegisterService()
    }

    fun login(loginOrEmail: String, password: String) {
        val userLoginRequest = UserLoginRequest(loginOrEmail, password)
        loginServiceApi.userLogin(userLoginRequest)
                .compose(Rx.applySchedulers())
                .doOnSubscribe { _loading.postValue(true) }
                .doOnUnsubscribe { _loading.postValue(false) }
                .subscribe(Action1 { loginResponse: LoginResponse ->
                    if (loginResponse.accountType == null) {
                        _error.postValue(app.getString(R.string.unsupported_user))
                        return@Action1
                    }
                    tokenDataSource.saveTokenInfo(loginResponse.accessToken)
                    accountTypeDataSource.setVersionCode(BuildConfig.VERSION_CODE)
                    accountTypeDataSource.saveAccountType(loginResponse.accountType)
                    notificationRegisterService.register(true, null)

                    _isUserExist.postValue(UserState.LOGIN_SUCCESS.apply { isProvider = loginResponse.accountType.isProvider })
                }) {
                    _errorDialog.postValue(it)
                }
    }
}