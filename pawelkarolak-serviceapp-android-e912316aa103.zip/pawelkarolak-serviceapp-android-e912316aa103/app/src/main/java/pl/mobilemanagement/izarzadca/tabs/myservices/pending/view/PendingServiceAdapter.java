package pl.mobilemanagement.izarzadca.tabs.myservices.pending.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.RowAdapter;
import pl.mobilemanagement.izarzadca.databinding.ServicePendingRowBinding;
import pl.mobilemanagement.izarzadca.tabs.myservices.ServiceDetailsClickListener;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderServiceType;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.PendingServiceOrder;
import pl.mobilemanagement.izarzadca.tools.DateUtil;
import rx.Observable;
import rx.subjects.BehaviorSubject;

class PendingServiceAdapter extends RowAdapter<PendingServiceOrder, PendingServiceAdapter.VH> {

    private final BehaviorSubject<ServiceOrder> listener = BehaviorSubject.create();
    private final ServiceDecisionClickListener serviceDecisionClickListener;
    private final ServiceDetailsClickListener detailsClickListener;

    public PendingServiceAdapter(ServiceDecisionClickListener serviceDecisionClickListener, ServiceDetailsClickListener detailsClickListener) {
        this.serviceDecisionClickListener = serviceDecisionClickListener;
        this.detailsClickListener = detailsClickListener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ServicePendingRowBinding binding = ServicePendingRowBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new VH(binding);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        holder.bind(getItem(position));
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).id.hashCode();
    }

    public Observable<ServiceOrder> orderObservable() {
        return listener;
    }

    class VH extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final ServicePendingRowBinding binding;
        private PendingServiceOrder order;

        VH(ServicePendingRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            binding.getRoot().setOnClickListener(this);
            binding.serviceDetails.setOnClickListener(this);
            binding.btnDecline.setOnClickListener(this);
            binding.btnAccept.setOnClickListener(this);
        }

        public void bind(PendingServiceOrder order) {
            this.order = order;

            String formatDateRange = DateUtil.getFormattedDate(binding.getRoot().getContext(), order.startDateTime, order.endDateTime);

            int number = getBindingAdapterPosition() + 1;
            String title = binding.getRoot().getContext().getResources().getString(R.string.text_with_number, number, order.serviceName);
            binding.title.setText(title);

            binding.distance.setText(order.distanceToCustomer);
            binding.dateValue.setText(formatDateRange);
            binding.addressValue.setText(getAddress(order));
        }

        private String getAddress(PendingServiceOrder item) {
            String address = item.street;
            if (item.number != null) {
                address += " " + item.number;
            }
            address += ", " + item.postalCode + " " + item.city;
            return address;
        }

        @Override
        public void onClick(View v) {
            if (v == binding.getRoot())
                listener.onNext(order);
            else if (v == binding.serviceDetails)
                detailsClickListener.onOrderDetailsClick(order.id, OrderServiceType.PENDING);
            else if (v == binding.btnAccept) {
                if (order.isPaymentRequired) {
                    serviceDecisionClickListener.onPayClick(order.id);
                } else {
                    serviceDecisionClickListener.onAcceptWithoutPayment(order.id);
                }
            } else if (v == binding.btnDecline) {
                serviceDecisionClickListener.onRejectClick(order.id);
            }
        }
    }
}
