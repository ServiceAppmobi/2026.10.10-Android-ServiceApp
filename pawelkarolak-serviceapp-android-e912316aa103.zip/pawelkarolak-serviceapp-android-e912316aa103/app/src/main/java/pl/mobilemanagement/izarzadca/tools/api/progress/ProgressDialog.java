package pl.mobilemanagement.izarzadca.tools.api.progress;

import android.content.Context;

import com.afollestad.materialdialogs.MaterialDialog;

import rx.Completable;
import rx.Observable;

import static pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper.show;

public class ProgressDialog {

    private MaterialDialog materialDialog;

    private ProgressDialog() {
    }

    public static <T> Observable.Transformer<T, T> create(Context context) {
        return new ProgressDialog().RxCompose(context);
    }

    public static Completable.Transformer createCompletable(Context context) {
        return new ProgressDialog().RxCompletableCompose(context);
    }

    public <T> Observable.Transformer<T, T> RxCompose(Context context) {
        return observable -> observable.doOnSubscribe(() -> materialDialog = show(context))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(materialDialog));
    }

    public Completable.Transformer RxCompletableCompose(Context context) {
        return completable -> completable.doOnSubscribe((aVoid) -> materialDialog = show(context))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(materialDialog));
    }
}
