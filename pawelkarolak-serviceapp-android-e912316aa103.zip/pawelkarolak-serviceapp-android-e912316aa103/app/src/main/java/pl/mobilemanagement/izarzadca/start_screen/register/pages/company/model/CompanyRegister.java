package pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import pl.mobilemanagement.izarzadca.common.map.Address;
import pl.mobilemanagement.izarzadca.common.model.api.CustomerRegister;
import pl.mobilemanagement.izarzadca.common.model.api.SimpleServiceModel;
import pl.mobilemanagement.izarzadca.common.user.AccountType;

public class CompanyRegister {
    @SerializedName("Phone")
    @Expose
    public String phone;
    @SerializedName("password")
    @Expose
    public String password;
    @SerializedName("code")
    @Expose
    public String code;
    @SerializedName("login")
    @Expose
    public String login;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("surname")
    @Expose
    public String surname;
    @SerializedName("street")
    @Expose
    public String street;
    @SerializedName("number")
    @Expose
    public String number;
    @SerializedName("postalCode")
    @Expose
    public String postCode;
    @SerializedName("city")
    @Expose
    public String city;
    @SerializedName("countryId")
    @Expose
    public String countryId;
    @SerializedName("countryCode")
    @Expose
    public String countryCode;
    @SerializedName("accountType")
    @Expose
    public AccountType accountType;
    @SerializedName("companyName")
    @Expose
    public String companyName;
    @SerializedName("companyNIP")
    @Expose
    public String companyNIP;
    @SerializedName("companyDesc")
    @Expose
    public String companyDesc;
    @SerializedName("companyBusinessArea")
    @Expose
    public String companyBusinessArea;
    @SerializedName("ProvidedServices")
    @Expose
    public List<SimpleServiceModel> companyServiceType;
    @SerializedName("Email")
    @Expose
    public String email;
    @Expose
    @SerializedName("lat")
    public Double latitude;
    @Expose
    @SerializedName("lng")
    public Double longitude;

    public static CompanyRegister create(CustomerRegister customerRegister, CompanyInfo companyInfo) {
        CompanyRegister companyRegister = new CompanyRegister();
        companyRegister.phone = customerRegister.phone;
        companyRegister.password = customerRegister.password;
        companyRegister.code = customerRegister.code;
        companyRegister.login = customerRegister.login;
        companyRegister.name = customerRegister.name;
        companyRegister.email = companyInfo.companyEmail;
        companyRegister.surname = customerRegister.surname;
        Address companyAddress = companyInfo.companyAddress;
        companyRegister.street = companyAddress.getStreet();
        companyRegister.number = companyAddress.getFlat();
        companyRegister.postCode = companyAddress.getPostalCode();
        companyRegister.city = companyAddress.getTown();
        companyRegister.countryId = customerRegister.countryId;
        companyRegister.countryCode = customerRegister.countryCode;
        companyRegister.accountType = customerRegister.accountType;
        companyRegister.latitude = customerRegister.latitude;
        companyRegister.longitude = customerRegister.longitude;
        companyRegister.companyName = companyInfo.companyName;
        companyRegister.companyNIP = companyInfo.companyNIP;
        companyRegister.companyDesc = companyInfo.companyDesc;
        companyRegister.companyBusinessArea = companyInfo.companyBusinessArea;
        companyRegister.companyServiceType = companyInfo.companyServiceType;
        return companyRegister;
    }
}
