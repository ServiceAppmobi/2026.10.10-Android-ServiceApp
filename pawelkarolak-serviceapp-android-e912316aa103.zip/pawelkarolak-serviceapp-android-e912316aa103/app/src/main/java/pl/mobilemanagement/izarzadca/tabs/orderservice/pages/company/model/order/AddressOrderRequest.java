package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.order;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.AddressPlace;

public class AddressOrderRequest extends OrderRequest {
    public final String countryId;
    public final String city;
    public final String postalCode;
    public final String street;
    public final String number;

    public AddressOrderRequest(AddressPlace place) {
        super(place);
        city = place.city;
        countryId = place.countryId;
        street = place.street;
        number = place.number;
        postalCode = place.postalCode;
    }
}
