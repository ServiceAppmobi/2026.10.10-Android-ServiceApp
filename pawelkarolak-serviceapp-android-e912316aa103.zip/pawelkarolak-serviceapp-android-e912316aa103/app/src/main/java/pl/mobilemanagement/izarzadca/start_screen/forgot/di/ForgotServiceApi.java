package pl.mobilemanagement.izarzadca.start_screen.forgot.di;

import pl.mobilemanagement.izarzadca.common.di.api.UserLoginRequest;
import pl.mobilemanagement.izarzadca.common.model.api.LoginResponse;
import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

public interface ForgotServiceApi {
    @POST("Account/PasswordReset")
    Observable<ForgotResponse> userForgot(@Body ForgotRequest userForgotRequest);

}
