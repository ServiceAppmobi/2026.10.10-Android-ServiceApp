package pl.mobilemanagement.izarzadca.common.map;

import java.io.Serializable;

public class Address implements Serializable {
    private final String town;
    private final String postalCode;
    private final String street;
    private final String flat;

    public Address(String town, String postalCode, String street, String flat) {
        this.town = town;
        this.postalCode = postalCode;
        this.street = street;
        this.flat = flat;
    }

    public String getTown() {
        return town;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getStreet() {
        return street;
    }

    public String getFlat() {
        return flat;
    }
}
