package pl.mobilemanagement.izarzadca.tabs.orderservice;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import pl.mobilemanagement.izarzadca.start_screen.register.LocationListener;
import pl.mobilemanagement.izarzadca.start_screen.register.OnTitleChangedListener;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.BaseView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.impl.ChoiceCompanyView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.date.ChoiceDateView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.photo.AttachPhotoView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.ServicePlaceView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.ChoiceServiceView;
import rx.functions.Action1;

public class OrderPagesPagerAdapter extends PagerAdapter {
    private final Activity activity;
    private final Context context;
    private BaseView mCurrentView;
    private final OnTitleChangedListener titleChangedListener;
    private final PageViewListener pageViewListener;
    private int lastPosition = -1;

    private final Action1<String> changeButtonText;

    private final LocationListener locationListener;

    public OrderPagesPagerAdapter(
            Context context,
            OnTitleChangedListener titleChangedListener,
            Action1<String> changeButtonText,
            PageViewListener pageViewListener,
            Activity activity,
            LocationListener locationListener
    ) {
        this.context = context;
        this.activity = activity;
        this.titleChangedListener = titleChangedListener;
        this.pageViewListener = pageViewListener;
        this.changeButtonText = changeButtonText;
        this.locationListener = locationListener;
    }

    @Override
    public void setPrimaryItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        if (isCurrentItem(position)) return;
        if (mCurrentView != null && !mCurrentView.isDetached()) {
            mCurrentView.viewDetach();
        }
        mCurrentView = (BaseView) object;
        mCurrentView.viewAttach(pageViewListener);
        final CharSequence title = mCurrentView.getTitle();
        titleChangedListener.titleChange(title);
    }

    private boolean isCurrentItem(int position) {
        if (lastPosition == position) {
            return true;
        } else {
            lastPosition = position;
        }
        return false;
    }

    @NonNull
    @Override
    public BaseView instantiateItem(ViewGroup container, int position) {
        BaseView view = createViewByPos(position);
        container.addView(view);
        return view;
    }

    private BaseView createViewByPos(int pos) {
        final BaseView orderView;
        switch (pos) {
            case 0:
                orderView = new ChoiceServiceView(context);
                break;
            case 1:
                orderView = new ChoiceDateView(context);
                break;
            case 2:
                orderView = new AttachPhotoView(context);
                break;
            case 3:
                orderView = new ServicePlaceView(context, activity, locationListener);
                break;
            case 4:
                orderView = new ChoiceCompanyView(context, changeButtonText);
                break;
            default:
                throw new IllegalArgumentException();
        }
        return orderView;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        BaseView oldView = (BaseView) object;
        if (!oldView.isDetached()) {
            oldView.viewDetach();
        }
        container.removeView(oldView);
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    public BaseView getCurrentPage() {
        return mCurrentView;
    }

    public void onDestroy() {
        if (mCurrentView != null && !mCurrentView.isDetached()) {
            mCurrentView.viewDetach();
        }
    }

    public void onNext() {
        mCurrentView.onNext();
    }
}