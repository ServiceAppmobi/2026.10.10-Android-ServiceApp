package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home

import pl.mobilemanagement.izarzadca.tabs.profile.api.UserDataApiModel
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.RequestDepositRequest
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models.Apartment
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models.ApartmentData
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface HomeApi {

    @GET("account/GetApartmentsList")
    suspend fun getApartmentList() : List<Apartment>

    @GET("Account/GetHomeScreenData")
    suspend fun getHomeScreenData(@Query("apartmentId") apartmentId: String) : ApartmentData

    @POST("community/advances/add")
    suspend fun requestDeposit(@Body requestDepositRequest: RequestDepositRequest)

    @GET("Account/GetUserData")
    suspend fun getUserData(): UserDataApiModel
}