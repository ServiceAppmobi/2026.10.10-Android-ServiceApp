package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.order;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.Place;

public class NormalOrderRequest extends OrderRequest{
    public NormalOrderRequest(Place place) {
        super(place);
    }
}
