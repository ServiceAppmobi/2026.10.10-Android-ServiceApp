package pl.mobilemanagement.izarzadca.common.model.api;

import com.google.gson.annotations.Expose;

import java.io.Serializable;

public class SimpleServiceModel implements Serializable {
    @Expose
    public final String serviceId;

    public SimpleServiceModel(String serviceId) {
        this.serviceId = serviceId;
    }
}
