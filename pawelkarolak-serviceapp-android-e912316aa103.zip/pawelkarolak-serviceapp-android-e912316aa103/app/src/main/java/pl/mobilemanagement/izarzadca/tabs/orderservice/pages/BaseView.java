package pl.mobilemanagement.izarzadca.tabs.orderservice.pages;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;
import androidx.annotation.LayoutRes;
import androidx.annotation.StringRes;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.tabs.orderservice.PageViewListener;

public abstract class BaseView extends RelativeLayout {
    protected PageViewListener pageViewListener;
    private boolean isDetached = true;

    public BaseView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BaseView(Context context) {
        super(context);
        init();
    }

    protected final String getString(@StringRes int stringRes) {
        return getContext().getString(stringRes);
    }

    private void init() {
        inflate(getContext(), layoutResource(), this);
    }

    public final void viewAttach(PageViewListener registerViewListener) {
        this.pageViewListener = registerViewListener;
        isDetached = false;
        onAttached();
    }

    protected void onAttached() {

    }

    public final void viewDetach() {
        pageViewListener = null;
        isDetached = true;
        onDetached();
    }

    protected void onDetached() {

    }

    @SuppressLint("StringFormatInvalid")
    public final CharSequence getTitle(int position) {
        return getContext().getString(R.string.registration_title, position, getTitle());
    }

    public CharSequence getTitle() {
        return getContext().getString(titleResource());
    }

    @StringRes
    protected abstract int titleResource();

    @LayoutRes
    protected abstract int layoutResource();

    public boolean isDetached() {
        return isDetached;
    }

    public void onNext() {}
}
