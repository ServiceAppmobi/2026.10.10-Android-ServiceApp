package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.RowAdapter;
import pl.mobilemanagement.izarzadca.common.adapter.orders.OrdersAdapter;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete.model.CompleteOrder;
import pl.mobilemanagement.izarzadca.tools.ItemClickListener;


public class CompletedAdapter extends RowAdapter<CompleteOrder, CompletedAdapter.VH> {
    private final ItemClickListener itemClickListener;

    public CompletedAdapter(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        final CompleteOrder completeOrder = getItem(position);
        holder.bind(completeOrder);
        holder.bindRateAndOpinion(completeOrder);
        holder.bindClickListener(itemClickListener);
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.order_complete_row, parent, false));
    }

    static class VH extends OrdersAdapter.VH {

        VH(View view) {
            super(view);
        }

        @Override
        public void bind(Order item) {
            super.bind(item);
            bindRateAndOpinion((CompleteOrder) item);
        }

        void bindRateAndOpinion(CompleteOrder item) {
        }

        void bindClickListener(ItemClickListener itemClickListener) {

        }
    }
}
