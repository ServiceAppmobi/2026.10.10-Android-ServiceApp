package pl.mobilemanagement.izarzadca.tabs.profile.di;

import dagger.Module;

@Module
public class ProfileModule {


}