package pl.mobilemanagement.izarzadca.start_screen.login_or_register

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class SocialData(
    var email: String? = null,
    var firstName: String? = null,
    var lastName: String? = null,
) : Parcelable {
    val login: String?
        get() = email?.split("@")?.firstOrNull()
}
