package pl.mobilemanagement.izarzadca.tabs.myservices.during.view;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.databinding.RecyclerViewFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.myservices.ServiceDetailsClickListener;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.ProviderOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderDetailsActivity;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderServiceType;
import pl.mobilemanagement.izarzadca.tabs.myservices.di.DaggerMyServicesComponent;
import pl.mobilemanagement.izarzadca.tabs.myservices.during.model.DuringServiceOrder;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.LCE;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;


public class DuringServiceTabFragment extends ServiceFragment<DuringServiceOrder> implements ServiceDetailsClickListener,
        LCE<DuringServiceOrder>, View.OnClickListener {
    public Subscription subscription;
    @Inject
    ProviderOrdersApi providerOrdersApi;
    public Observable<List<DuringServiceOrder>> listObservable = Observable.defer(this::createObservable).share();

    private RecyclerViewFrameBinding binding;

    private final DuringServiceAdapter duringServicesAdapter = new DuringServiceAdapter(this);
    private EarthlyLoadingDialog earthlyDialog;

    public DuringServiceTabFragment() {
        DaggerMyServicesComponent.builder().applicationComponent(App.component).build().inject(this);
    }

    @Override
    public int getTitleResource() {
        return R.string.my_services_tab_during;
    }

    @Override
    protected int getLayout() {
        return R.layout.recycler_view_frame;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding = RecyclerViewFrameBinding.bind(view);
        initRecyclerView();
        binding.btnRefresh.setOnClickListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchDuringServices();
    }

    private void fetchDuringServices() {
        Rx.safeUnsubscribe(subscription);
        subscription = listObservable
                .compose(Rx.applyLCE(this))
                .compose(Rx.applyDataLoader(this))
                .subscribe(orders -> {
                }, Throwable::new);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Rx.safeUnsubscribe(subscription);
    }

    @NonNull
    private Observable<List<DuringServiceOrder>> createObservable() {
        return providerOrdersApi.getAcceptedOrders()
                .compose(Rx.applySchedulers());
    }

    private void initRecyclerView() {
        binding.listRecyclerView.setAdapter(duringServicesAdapter);
    }

    @Override
    public void onOrderDetailsClick(String orderId, OrderServiceType orderType) {
        startActivity(OrderDetailsActivity.getIntent(requireContext(), orderId, orderType));
    }

    @Override
    public Observable<List<DuringServiceOrder>> getOrdersObservable() {
        return listObservable;
    }

    @Override
    public Observable<ServiceOrder> orderClickObservable() {
        return duringServicesAdapter.orderObservable();
    }

    @Override
    public void setData(List<DuringServiceOrder> data) {
        duringServicesAdapter.setDataList(data);
    }

    @Override
    public void showProgressBar() {
        earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager());
//        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgressBar() {
        ProgressHelper.safeDismiss(earthlyDialog);
//        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void hideError() {
        binding.errorGroup.setVisibility(View.GONE);
    }

    @Override
    public void showEmptyListError() {
        binding.errorGroup.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.during_orders_empty);
    }

    @Override
    public void showConnectionError() {
        binding.errorGroup.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.list_view_connection_error);
    }

    /*@Override
    public void onTargetNotification(Observable<Message> oMessage) {
        oMessage.subscribe(message -> {
            fetchDuringServices();
        });
    }

    @Override
    public void onMismatchTargetNotification(Observable<Message> oMessage) {

    }

    @Override
    public boolean matchesTarget(String key) {
        return PushType.parseOf(key) == PushType.PROVIDER_SERVICE_CLOSED;
    }*/

    @Override
    public void onClick(View v) {
        if (v == binding.btnRefresh) {
            fetchDuringServices();
        }
    }
}
