package pl.mobilemanagement.izarzadca.start_screen.register.pages.company

import android.annotation.SuppressLint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.ColorRes
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.databinding.ItemServiceSelectBinding
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.ServiceItem


class SelectServiceAdapter(
    private var items: List<ServiceItem>,
    private val listener: OnItemCheckedChange
): RecyclerView.Adapter<SelectServiceAdapter.ServiceViewHolder>() {

    interface OnItemCheckedChange {
        fun onChange(item: ServiceItem, checked: Boolean)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServiceViewHolder {
        val binding = ItemServiceSelectBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ServiceViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ServiceViewHolder, position: Int) {
        val item = items[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun submitList(items: List<ServiceItem>) {
        this.items = items
        notifyDataSetChanged()
    }

    inner class ServiceViewHolder(
        private val binding: ItemServiceSelectBinding
    ) : RecyclerView.ViewHolder(binding.root), View.OnClickListener {

        private var item: ServiceItem? = null

        init {
            binding.root.setOnClickListener(this)
        }

        fun bind(item: ServiceItem) {
            this.item = item
            binding.root.text = item.text
            setCheckedState(item.checked)
        }

        private fun setCheckedState(checked: Boolean) {
            if(checked)
                binding.root.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_check, 0)
            else
                binding.root.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)
            val textColorRes = if(checked) R.color.main else R.color.text1
            binding.root.setTextColor(ContextCompat.getColor(binding.root.context, textColorRes))
        }

        override fun onClick(v: View?) {
            if(item != null)
                listener.onChange(item!!, !item!!.checked)
        }
    }
}