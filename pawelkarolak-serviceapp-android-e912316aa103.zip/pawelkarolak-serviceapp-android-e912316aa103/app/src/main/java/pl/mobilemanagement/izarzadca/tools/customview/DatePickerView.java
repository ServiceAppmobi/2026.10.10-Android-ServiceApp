package pl.mobilemanagement.izarzadca.tools.customview;

import android.app.DatePickerDialog;
import android.content.Context;
import android.view.View;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;

import pl.mobilemanagement.izarzadca.R;

public class DatePickerView implements View.OnClickListener, DatePickerDialog.OnDateSetListener {
    private final TextView editText;
    private final Context context;
    private final Calendar calendar;
    private DateObject currentDateObject;

    public DatePickerView(Context context, TextView editText, Calendar calendar) {
        this.context = context;
        this.editText = editText;
        this.calendar = calendar;
        this.editText.setOnClickListener(this);
    }

    @Override
    public void onDateSet(android.widget.DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        final Date date = createDate(year, monthOfYear, dayOfMonth);
        final Date currentDate = calendar.getTime();
        if (date.before(currentDate)) {
            showAsSoonIsPossible();
            currentDateObject = new DateObject(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        } else {
            currentDateObject = new DateObject(year, monthOfYear, dayOfMonth);
            updateDisplay(year, monthOfYear, dayOfMonth);
        }
    }

    private void showAsSoonIsPossible() {
        editText.setText(R.string.order_service_select_date_as_soon_is_possible);
    }

    private Date createDate(int year, int monthOfYear, int day) {
        final Calendar c = Calendar.getInstance();
        c.set(year, monthOfYear, day, 0, 0);
        return c.getTime();
    }

    @Override
    public void onClick(View v) {
        DatePickerDialog dialog = new DatePickerDialog(context, this,
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    private void updateDisplay(int year, int monthOfYear, int dayOfMonth) {
        editText.setText(new StringBuilder().append(dayOfMonth).append("/").append(monthOfYear + 1).append("/").append(year));
    }

    public DateObject getDataObject() {
        return currentDateObject;
    }

    static class DateObject {
        final int year;
        final int monthOfYear;
        final int dayOfMonth;

        DateObject(int year, int monthOfYear, int dayOfMonth) {
            this.year = year;
            this.monthOfYear = monthOfYear;
            this.dayOfMonth = dayOfMonth;
        }
    }
}