package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.rate_order;

public class RateOrderApiModel {
    /*
        From 0 to 5
         */
    public int rating;
    public String opinion;

    public String id;

    public RateOrderApiModel(int rating, String opinion, String id) {
        this.rating = rating;
        this.opinion = opinion;
        this.id = id;
    }

}
