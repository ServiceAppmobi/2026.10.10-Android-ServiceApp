package pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class ServiceItem(
    val serviceId: String,
    val text: String,
    val checked: Boolean = false,
    val visible: Boolean = true
) : Parcelable
