package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.view;

import pl.mobilemanagement.izarzadca.common.model.api.Order;

interface PendingOrderClickListener {

    void onCancelClick(Order order);

    void onAskAgainClick(Order order);

}
