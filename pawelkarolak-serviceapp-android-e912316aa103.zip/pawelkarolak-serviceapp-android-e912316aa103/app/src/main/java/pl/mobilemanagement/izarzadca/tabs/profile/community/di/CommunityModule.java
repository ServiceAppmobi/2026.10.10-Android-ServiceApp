package pl.mobilemanagement.izarzadca.tabs.profile.community.di;

import dagger.Module;
import dagger.Provides;
import pl.mobilemanagement.izarzadca.common.di.api.Auth;
import pl.mobilemanagement.izarzadca.tabs.myorders.di.MyOrdersScope;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import retrofit2.Retrofit;

@Module
public class CommunityModule {
    @Provides
    @MyCommunityScope
    public CommunityApi communityApi(@Auth Retrofit retrofit) {
        return retrofit.create(CommunityApi.class);
    }

}