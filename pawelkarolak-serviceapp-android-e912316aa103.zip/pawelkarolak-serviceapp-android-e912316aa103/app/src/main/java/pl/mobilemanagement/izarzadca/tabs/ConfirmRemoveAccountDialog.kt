package pl.mobilemanagement.izarzadca.tabs

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.core.os.bundleOf
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import pl.mobilemanagement.izarzadca.R

class ConfirmRemoveAccountDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
            AlertDialog.Builder(requireContext())
                    .setTitle(R.string.remove_account_title)
                    .setMessage(R.string.remove_account_text)
                    .setPositiveButton(R.string.yes) { _ ,_ ->
                        setFragmentResult(RESULT_KEY, bundleOf(RESULT_KEY to true))
                        dismiss()
                    }
                    .setNegativeButton(R.string.no) { _, _ -> dismiss() }
                    .create()

    companion object {
        const val RESULT_KEY = "ConfirmRemoveAccountDialog"
    }
}