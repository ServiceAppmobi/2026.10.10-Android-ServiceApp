package pl.mobilemanagement.izarzadca.tabs.profile.creditcard.detail;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.EditText;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.common.user.profile.SimplifyCreditCard;
import pl.mobilemanagement.izarzadca.databinding.ActivityDetailCardBinding;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tabs.profile.di.DaggerProfileComponent;
import pl.mobilemanagement.izarzadca.tools.EditTextHelper;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;

public class DetailsCreditCardActivity extends AppCompatActivity {
    private static final String CARD = "card";
    public Subscription subscription;

    @Inject
    ProfileApi profileApi;

    Toolbar toolbar;
    EditText cardNumber;
    EditText creditCardDate;

    public static void start(Context context, SimplifyCreditCard simplifyCreditCard) {
        final Intent intent = new Intent(context, DetailsCreditCardActivity.class);
        intent.putExtra(CARD, simplifyCreditCard);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerProfileComponent.builder().applicationComponent(App.component).build().inject(this);

        ActivityDetailCardBinding binding = ActivityDetailCardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        toolbar = binding.toolbar.toolbarWhiteArrow;
        cardNumber = binding.cardNumber;
        creditCardDate = binding.creditCardDate;
        binding.removeCreditCardButton.setOnClickListener(v -> onClick());

        setSupportActionBar(toolbar);
        cardNumber.removeTextChangedListener(EditTextHelper.getCreditCardTextWatcher());
        updateCardInformation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Rx.safeUnsubscribe(subscription);
    }

    private void updateCardInformation() {
        SimplifyCreditCard card = (SimplifyCreditCard) getIntent().getSerializableExtra(CARD);
        cardNumber.setText(card.number);
        creditCardDate.setText(card.expirationDate);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClick() {
        subscription = profileApi.removeCreditCard()
                .compose(Rx.applySchedulers())
                .compose(ProgressDialog.create(this))
                .subscribe(aVoid -> finish(),
                        throwable -> ApiErrorDialogHelper.show(this, throwable));
    }
}
