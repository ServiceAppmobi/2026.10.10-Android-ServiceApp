package pl.mobilemanagement.izarzadca.common.di.api;

import android.app.Application;

import androidx.annotation.NonNull;

import com.chuckerteam.chucker.api.ChuckerInterceptor;

import dagger.Module;
import dagger.Provides;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import javax.inject.Named;
import javax.inject.Singleton;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import pl.mobilemanagement.izarzadca.common.LocaleFormatter;
import timber.log.Timber;

@Module
public class OkHttpInterceptorsModule {

    @Provides
    @Singleton
    @NonNull
    HttpLoggingInterceptor provideHttpLoggingInterceptor() {
        return new HttpLoggingInterceptor(message -> Timber.d(message)).setLevel(HttpLoggingInterceptor.Level.BODY);
    }

    @Provides
    @NonNull
    @Named("culture")
    Interceptor provideLanguageInterceptor(@Named("culture_tag") String cultureTag) {
        return chain -> {
            String language = Locale.getDefault().toLanguageTag();
            Request request = chain.request().newBuilder().addHeader("Culture", language).build();
            return chain.proceed(request);
        };
    }
    @Provides
    @Singleton
    @NonNull
    @Named("apikey")
    Interceptor provideKeySupport() {
        return chain -> {
            Request request = chain.request().newBuilder().addHeader("Api-Key", "058b1cda-9f08-400b-9da7-dda747e91cd0").build();
            return chain.proceed(request);
        };
    }

    @Provides
    @NonNull
    @Named("culture_tag")
    String provideLanguageLocale() {
        return LocaleFormatter.toBcp47Language(Locale.getDefault());
    }


    @Provides
    @NonNull
    List<Interceptor> provideInterceptors(HttpLoggingInterceptor httpLoggingInterceptor, @Named("culture") Interceptor interceptor, @Named("apikey")Interceptor provideKeySupport, Application app) {
        return Arrays.asList(httpLoggingInterceptor, interceptor, provideKeySupport, new ChuckerInterceptor.Builder(app).build());
    }

}