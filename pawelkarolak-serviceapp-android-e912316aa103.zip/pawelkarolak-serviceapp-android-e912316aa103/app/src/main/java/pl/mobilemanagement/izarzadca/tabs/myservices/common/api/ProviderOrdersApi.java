package pl.mobilemanagement.izarzadca.tabs.myservices.common.api;

import java.util.List;
import java.util.Map;

import pl.mobilemanagement.izarzadca.common.model.api.BraintreeCheckoutRequest;
import pl.mobilemanagement.izarzadca.common.model.api.BraintreeCheckoutResult;
import pl.mobilemanagement.izarzadca.common.model.api.BraintreeToken;
import pl.mobilemanagement.izarzadca.common.model.api.OrderId;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model.CompleteOrderDetailsApiModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model.DuringOrderDetailsApiModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model.PendingOrderDetailsApiModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.during.model.DuringServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.ended.model.CompletedOrderService;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.StripePaymentInformationModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.StripePaymentMethodsModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.PendingServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.StripePaymentAnswer;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.StripePaymentModel;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;
import rx.Observable;

public interface ProviderOrdersApi {

    @GET("Provider/GetPendingOrders")
    Observable<List<PendingServiceOrder>> getPendingOrders();

    @GET("Provider/GetAcceptedOrders")
    Observable<List<DuringServiceOrder>> getAcceptedOrders();

    @GET("Provider/GetCompletedOrders")
    Observable<List<CompletedOrderService>> getCompletedOrders();

    @POST("Provider/GetAcceptedOrderDetails")
    Observable<DuringOrderDetailsApiModel> getDuringOrderDetails(@Body OrderId orderId);

    @POST("Provider/GetPendingOrderDetails")
    Observable<PendingOrderDetailsApiModel> getPendingOrderDetails(@Body OrderId orderId);

    @POST("Provider/GetCompletedOrderDetails")
    Observable<CompleteOrderDetailsApiModel> getCompletedOrderDetails(@Body OrderId orderId);

    @POST("Account/add")
    Observable<Void> addUserToStripe();

    @GET("Payment/list-payment-methods")
    Observable<StripePaymentMethodsModel> getPaymentMethodsList();

    @GET("Payment/info-credit-card")
    Observable<StripePaymentInformationModel> getPaymentInfo();

    @POST("Payment/use-payment-intent/{paymentIntentId}")
    Observable<StripePaymentAnswer> payUsingPaymentMethod(@Path("paymentIntentId") String paymentIntentId);

    @POST("Payment/create-payment-intent")
    Observable<StripePaymentModel> getStripePaymentInformation();

    @POST("Provider/RejectOrder")
    Observable<Void> rejectOrder(@Body OrderId orderId);

    @POST("Provider/AcceptOrder")
    Observable<Void> acceptOrder(@Body OrderId orderId);

    @POST("Provider/MarkOrderAsPaid")
    Observable<Void> markOrderAsPaid(@Body OrderId orderId);

    @GET("Checkout/GetClientToken")
    Observable<BraintreeToken> getBraintreeToken(@Query("customerId") String customerId);

    @POST("Checkout/Checkout")
    Observable<BraintreeCheckoutResult> checkoutBraintree(@Body BraintreeCheckoutRequest request);

    @GET("Checkout/GetBraintreeTransactionHistory")
    Observable<List<Map<String, Object>>> getBraintreeTransactionHistory(@Query("customerId") String customerId);

}
