package pl.mobilemanagement.izarzadca.start_screen.forgot.di;

import dagger.Component;
import pl.mobilemanagement.izarzadca.common.di.ApplicationComponent;
import pl.mobilemanagement.izarzadca.start_screen.forgot.ForgotActivity;

@ForgotScope
@Component(dependencies = ApplicationComponent.class, modules = ForgotModule.class)
public interface ForgotComponent {

    void inject(ForgotActivity loginActivity);
}
