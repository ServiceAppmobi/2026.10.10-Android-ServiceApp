package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model;

import com.google.gson.annotations.Expose;

import java.io.Serializable;

public class ServiceModel implements Serializable {
    @Expose
    public final String serviceId;
    @Expose
    public final String name;

    public ServiceModel(String serviceId, String name) {
        this.serviceId = serviceId;
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ServiceModel that = (ServiceModel) o;

        return serviceId != null ? serviceId.equals(that.serviceId) : that.serviceId == null;

    }

    @Override
    public int hashCode() {
        return serviceId != null ? serviceId.hashCode() : 0;
    }
}
