package pl.mobilemanagement.izarzadca.tabs.profile.api;

import pl.mobilemanagement.izarzadca.common.user.profile.OrderAcceptCost;
import pl.mobilemanagement.izarzadca.tabs.profile.creditcard.create.model.CreditCardApiModel;
import pl.mobilemanagement.izarzadca.tabs.profile.edit.model.UpdateProviderApiModel;
import pl.mobilemanagement.izarzadca.tabs.profile.edit.model.UpdateUserApiModel;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import rx.Observable;

public interface ProfileApi {

    @GET("Account/GetUserData")
    Observable<UserDataApiModel> getUserData();

    @POST("Account/contacts/image/upload")
    Observable<Void> uploadUserImage(@Body UploadUserPhoto uploadUserPhoto);

    @DELETE("Account/contacts/image/delete")
    Observable<Void> deleteUserImage();

    @PUT("Account/ChangePassword")
    Observable<Void> updatePassword(@Body ChangePasswordApiModel changePasswordApiModel);

    @PUT("Account/ChangePassword")
    Observable<Void> updatePassword(@Body ChangePasswordApiModel changePasswordApiModel, @Header("Authorization") String accessToken);

    @POST("Account/UpdateUserData")
    Observable<Void> updateUserData(@Body UpdateUserApiModel updateUserApiModel);

    @POST("Account/UpdateUserData")
    Observable<Void> updateProviderUserData(@Body UpdateProviderApiModel updateUserApiModel);

    @POST("Account/UpdateUserData")
    Observable<Void> updateProviderUserData(@Body UpdateProviderApiModel updateUserApiModel, @Header("Authorization") String accessToken);

    @DELETE("Account/CreditCard")
    Observable<Void> removeCreditCard();

    @POST("Account/CreditCard")
    Observable<Void> registerCreditCard(@Body CreditCardApiModel creditCardToCreate);

    @GET("Account/contact/serviceEnabled")
    Observable<OrderAcceptCost> getOrderAcceptCost();

    @DELETE("account/deleteContact")
    Observable<Void> deleteAccount();

}
