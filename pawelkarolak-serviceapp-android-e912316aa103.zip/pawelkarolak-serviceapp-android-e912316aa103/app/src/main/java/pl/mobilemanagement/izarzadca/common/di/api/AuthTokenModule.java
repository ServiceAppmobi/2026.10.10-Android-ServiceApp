package pl.mobilemanagement.izarzadca.common.di.api;

import androidx.annotation.NonNull;
import dagger.Module;
import dagger.Provides;
import okhttp3.Interceptor;
import okhttp3.Request;
import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;
import pl.mobilemanagement.izarzadca.common.user.profile.UserProfileDataSource;
import pl.mobilemanagement.izarzadca.common.user.profile.UserService;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import retrofit2.Retrofit;

@Module
public class AuthTokenModule {

    @Provides
    public ProfileApi providesProfileApi(@Auth Retrofit retrofit) {
        return retrofit.create(ProfileApi.class);
    }

    @Provides
    @NonNull
    UserService providesUserService(ProfileApi profileApi, UserProfileDataSource userProfileDataSource, AccountTypeDataSource accountTypeDataSource) {
        return new UserService(profileApi, userProfileDataSource, accountTypeDataSource);
    }

    @Provides
    @NonNull
    UserProfileDataSource providesUserDataSource(DataSourceRepository dataSource) {
        return new UserProfileDataSource(dataSource);
    }

    @Provides
    @NonNull
    TokenDataSource providesTokenRepository(DataSourceRepository dataSourceRepository) {
        return new TokenDataSource(dataSourceRepository);
    }

    @Provides
    @NonNull
    AccountTypeDataSource providesAccountTypeRepository(DataSourceRepository dataSourceRepository) {
        return new AccountTypeDataSource(dataSourceRepository);
    }

    @Provides
    @NonNull
    @Auth
    Interceptor providesAuthHeaderInterceptor(final TokenDataSource tokenDataSource) {
        return chain -> {
            Request request = chain.request();
            String token = tokenDataSource.getTokenInfo();
            if (token != null) {
                request = request.newBuilder()
                        .addHeader("Authorization", "Bearer " + token)
                        .build();
            }
            return chain.proceed(request);
        };
    }
}
