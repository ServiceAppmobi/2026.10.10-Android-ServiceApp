package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model;

import java.io.Serializable;

public abstract class Place implements Serializable {
    public final String placeId;

    public Place(String placeId) {
        this.placeId = placeId;
    }
}
