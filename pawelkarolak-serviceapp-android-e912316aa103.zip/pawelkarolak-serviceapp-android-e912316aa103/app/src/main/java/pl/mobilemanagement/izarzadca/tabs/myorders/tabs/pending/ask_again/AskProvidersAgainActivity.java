package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.ask_again;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.EditText;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.jetbrains.annotations.NotNull;

import java.util.Calendar;
import java.util.Date;
import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.databinding.AskProvidersAgainBinding;
import pl.mobilemanagement.izarzadca.tabs.myorders.api.ClientOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myorders.di.DaggerMyOrdersComponent;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.customview.DateTimeView;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;


public class AskProvidersAgainActivity extends AppCompatActivity {
    private static final String ORDER_DESCR_KEY = "ORDER_DESCR_KEY";
    private static final String ORDER_ID_KEY = "ORDER_ID_KEY";

    @Inject
    ClientOrdersApi clientOrdersApi;

    EditText orderDescription;
    DateTimeView dateFrom;
    DateTimeView dateTo;

    private EarthlyLoadingDialog earthlyDialog;
    private final Calendar calendar = Calendar.getInstance();

    public static void start(Context context, String orderId, String prevDescription) {
        final Intent startIntent = new Intent(context, AskProvidersAgainActivity.class);
        startIntent.putExtra(ORDER_ID_KEY, orderId);
        startIntent.putExtra(ORDER_DESCR_KEY, prevDescription);
        context.startActivity(startIntent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AskProvidersAgainBinding binding = AskProvidersAgainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar.toolbarWhiteArrow);
        orderDescription = binding.descriptionOrder;
        dateFrom = binding.dateFrom;
        dateTo = binding.dateTo;

        binding.askAgainButton.setOnClickListener(v -> askAgainButtonClick());

        final String orderDesrc = getIntent().getStringExtra(ORDER_DESCR_KEY);
        orderDescription.setText(orderDesrc);
        DaggerMyOrdersComponent.builder().applicationComponent(App.component).build().inject(this);
    }

    private Date normalizeDate(Date date) {
        if (isDateNeedNormalize(date)) {
            return new Date();
        }
        return date;
    }

    private boolean isDateNeedNormalize(Date date) {
        return date == null || calendar.getTime().after(date);
    }

    private void askAgainButtonClick() {
        final String orderId = getIntent().getStringExtra(ORDER_ID_KEY);
        final String description = orderDescription.getText().toString();


        Date normalizeStartDate = normalizeDate(dateFrom.getSelectedDate());
        Date normalizeEndDate = normalizeDate(dateTo.getSelectedDate());
        if (normalizeEndDate.before(normalizeStartDate)) {
            normalizeEndDate = normalizeStartDate;
        }

        final AskOrderAgainApiModel askOrderAgainApiModel = new AskOrderAgainApiModel(orderId, description, normalizeStartDate, normalizeEndDate);
        clientOrdersApi.postDatesAndIssueDescription(askOrderAgainApiModel)
                .compose(Rx.applySchedulers())
                .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getSupportFragmentManager()))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                .subscribe(aVoid -> {
                    finish();
                }, throwable -> ApiErrorDialogHelper.show(this, throwable));
    }

    @Override
    public boolean onOptionsItemSelected(@NotNull MenuItem item) {
        finish();
        return true;
    }
}
