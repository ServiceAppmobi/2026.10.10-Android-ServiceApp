package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.view;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import pl.mobilemanagement.izarzadca.tools.spinner.SpinnerItem;


public class ServiceTypeSpinnerItem implements SpinnerItem {

    private final ServiceModel serviceModel;

    public ServiceTypeSpinnerItem(ServiceModel serviceModel) {
        this.serviceModel = serviceModel;
    }

    public ServiceModel getServiceModel() {
        return serviceModel;
    }

    @Override
    public String toString() {
        return serviceModel.name;
    }
}