package pl.mobilemanagement.izarzadca.common.model.api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import pl.mobilemanagement.izarzadca.common.user.AccountType;

public class LoginResponse {

    @SerializedName("access_token")
    @Expose
    public String accessToken;

    @SerializedName("token_type")
    @Expose
    public String tokenType;

    @SerializedName("expires_in")
    @Expose
    public Integer expiresIn;

    @SerializedName("userName")
    @Expose
    public String userName;

    @SerializedName("accountTypeId")
    @Expose
    public AccountType accountType;

    @SerializedName(".issued")
    @Expose
    public String issued;

    @SerializedName(".expires")
    @Expose
    public String expires;

}