package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import pl.mobilemanagement.izarzadca.App
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi
import pl.mobilemanagement.izarzadca.common.model.entity.Country
import pl.mobilemanagement.izarzadca.databinding.ActivityDifferentAddressBinding
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.AddressPlace
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper
import pl.mobilemanagement.izarzadca.tools.rx.Rx
import pl.mobilemanagement.izarzadca.tools.spinner.CountrySpinnerItem
import pl.mobilemanagement.izarzadca.tools.spinner.HintAdapter
import rx.Subscription
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import javax.inject.Inject

class DifferentAddressActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityDifferentAddressBinding

    private var countryFetchSubscription: Subscription? = null

    private var selectedCountry: Country? = null

    @Inject
    lateinit var unauthorizedApi: UnauthorizedApi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDifferentAddressBinding.inflate(layoutInflater)
        setContentView(binding.root)

        selectedCountry = savedInstanceState?.getSerializable(COUNTRY) as? Country

        App.component.inject(this)

        binding.next.setOnClickListener(this)
        binding.backArrow.setOnClickListener(this)

        binding.countrySpinner.onItemClickListener = OnItemClickListener { parent: AdapterView<*>, _: View?, position: Int, _: Long ->
            val item = parent.adapter.getItem(position) as CountrySpinnerItem
            selectedCountry = item.country
        }

        fetchCountries()
    }

    private fun EditText.getTrimmedText() : String {
        return text?.toString().orEmpty().trim()
    }

    override fun onClick(v: View?) {
        if (v?.id == R.id.next) {
            val intent = Intent().apply {
                putExtra(COUNTRY, selectedCountry?.id)
                putExtra(CITY, binding.city.getTrimmedText())
                putExtra(STREET, binding.street.getTrimmedText())
                putExtra(APARTMENT, binding.apartment.getTrimmedText())
                putExtra(POSTAL_CODE, binding.postal.getTrimmedText())
            }
            setResult(RESULT_OK, intent)
        }
        finish()
    }

    private fun fetchCountries() {
        countryFetchSubscription = unauthorizedApi.countries
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ countries: List<Country?>? ->
                    val countrySpinnerItems = CountrySpinnerItem.createSpinnerItems(countries)
                    HintAdapter.setHintData(binding.countrySpinner, countrySpinnerItems)
                }, { throwable: Throwable? -> ApiErrorDialogHelper.show(this, throwable) })
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        outState.putSerializable(COUNTRY, selectedCountry)
    }

    override fun onDestroy() {
        super.onDestroy()
        Rx.safeUnsubscribe(countryFetchSubscription)
    }

    companion object {
        private const val COUNTRY = "COUNTRY"
        private const val CITY = "CITY"
        private const val STREET = "STREET"
        private const val APARTMENT = "APARTMENT"
        private const val POSTAL_CODE = "POSTAL_CODE"

        @JvmStatic
        fun getAddressFromIntent(intent: Intent) : AddressPlace {
            val city = intent.getStringExtra(CITY)
            val countryId = intent.getStringExtra(COUNTRY)
            val street = intent.getStringExtra(STREET)
            val apartment = intent.getStringExtra(APARTMENT)
            val postalCode = intent.getStringExtra(POSTAL_CODE)
            return AddressPlace(city, countryId, street, apartment, postalCode)
        }
    }
}