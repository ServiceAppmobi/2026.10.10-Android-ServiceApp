package pl.mobilemanagement.izarzadca.tabs

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.map
import androidx.lifecycle.viewModelScope
import io.intercom.android.sdk.Intercom
import io.intercom.android.sdk.IntercomError
import io.intercom.android.sdk.IntercomStatusCallback
import io.intercom.android.sdk.UserAttributes
import io.intercom.android.sdk.identity.Registration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.RequestDepositRequest
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.HomeApi
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models.Apartment
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models.ApartmentData
import retrofit2.HttpException
import javax.inject.Inject
import kotlin.coroutines.resumeWithException

class MainActivityViewModel @Inject constructor(
    private val homeApi: HomeApi,
    private val accountTypeDataSource: AccountTypeDataSource
): ViewModel() {

    enum class UserType {
        APP_USER, APP_USER_WITH_PROPERTY,
        SERVICE_PROVIDER, SERVICE_PROVIDER_WITH_PROPERTY
    }

    private val _apartments = MutableLiveData<List<Apartment>>()
    val apartments: LiveData<List<Apartment>> = _apartments

    private val _apartmentData = MutableLiveData<ApartmentData?>()
    val apartmentData: LiveData<ApartmentData?> = _apartmentData

    val displayPayments = apartmentData.map {
        it?.payments.orEmpty().take(3)
    }

    private val _selectedApartment = MutableLiveData<Apartment>()
    val selectedApartment: LiveData<Apartment> = _selectedApartment

    private val _userType = MutableLiveData<UserType>()
    val userType: LiveData<UserType> = _userType

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading

    private val _isProfessional = MutableLiveData<Boolean>()
    val isProfessional: LiveData<Boolean> = _isProfessional

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _loading.postValue(true)
                val apartmentList = homeApi.getApartmentList()
                _apartments.postValue(apartmentList)

                if(apartmentList.isNotEmpty()) {
                    _selectedApartment.postValue(apartmentList[0])
                }

                val userType = if(accountTypeDataSource.accountType.isProvider)
                    if(apartmentList.isEmpty()) UserType.SERVICE_PROVIDER
                    else UserType.SERVICE_PROVIDER_WITH_PROPERTY
                else
                    if(apartmentList.isEmpty()) UserType.APP_USER
                    else UserType.APP_USER_WITH_PROPERTY

                _userType.postValue(userType)
            } catch(e: HttpException) {
                e.printStackTrace()
            } finally {
                _loading.postValue(false)
            }
        }
    }

    fun setApartmentByIndex(index: Int) {
        setApartment(apartments.value!![index])
    }

    fun setApartment(apartment: Apartment) {
        _selectedApartment.value = apartment
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _loading.postValue(true)
                val apartmentData = homeApi.getHomeScreenData(apartment.id)
                _apartmentData.postValue(apartmentData)
            } catch(e: HttpException) {
                e.printStackTrace()
            } finally {
                _loading.postValue(false)
            }
        }
    }

    fun loginIntercom() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                Intercom.client().logout()
                val userData = homeApi.getUserData()
                _isProfessional.postValue(userData.isProfessional)
                val registration = Registration.create().withUserId(userData.userId).withUserAttributes(
                        UserAttributes.Builder()
                                .withEmail(userData.email)
                                .withPhone(userData.phone)
                                .build()
                )
                loginInIntercom(registration)
            } catch (e: Exception) {

            }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private suspend fun loginInIntercom(registration: Registration) = suspendCancellableCoroutine<Unit> { continuation ->
        Intercom.client().loginIdentifiedUser(registration, object : IntercomStatusCallback {
            override fun onSuccess() {
                continuation.resume(Unit, null)
            }

            override fun onFailure(intercomError: IntercomError) {
                continuation.resumeWithException(Exception(intercomError.errorMessage))
            }
        })
    }

    fun requestDeposit(amount: String, note: String) {
        val apartmentId = selectedApartment.value?.id ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _loading.postValue(true)
                val requestDepositRequest = RequestDepositRequest(
                    amount = amount,
                    note = note,
                    apartmentId = apartmentId
                )
                homeApi.requestDeposit(requestDepositRequest)
                val apartmentData = homeApi.getHomeScreenData(apartmentId)
                _apartmentData.postValue(apartmentData)
            } catch(e: HttpException) {
                e.printStackTrace()
            } finally {
                _loading.postValue(false)
            }
        }
    }

}