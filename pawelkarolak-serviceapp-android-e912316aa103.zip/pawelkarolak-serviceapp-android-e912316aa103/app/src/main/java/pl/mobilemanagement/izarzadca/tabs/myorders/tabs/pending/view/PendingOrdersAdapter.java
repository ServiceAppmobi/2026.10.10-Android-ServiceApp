package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.orders.OrdersAdapter;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.databinding.OrderWaitRowBinding;

class PendingOrdersAdapter extends OrdersAdapter<PendingOrdersAdapter.PendingVH> {
    final private PendingOrderClickListener pendingOrderClickListener;


    PendingOrdersAdapter(PendingOrderClickListener pendingOrderClickListener) {
        this.pendingOrderClickListener = pendingOrderClickListener;
    }

    @NonNull
    @Override
    public PendingVH onCreateViewHolder(ViewGroup parent, int viewType) {
        return new PendingVH(LayoutInflater.from(parent.getContext()).inflate(R.layout.order_wait_row, parent, false));
    }

    @Override
    public void onBindViewHolder(PendingVH holder, int position) {
        final Order item = getItem(position);
        holder.bind(item);
    }

    class PendingVH extends OrdersAdapter.VH implements View.OnClickListener {

        private Order item;

        PendingVH(View itemView) {
            super(itemView);
            OrderWaitRowBinding binding = OrderWaitRowBinding.bind(itemView);
            binding.askAgainButton.setOnClickListener(this);
            binding.removeOrder.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int id = v.getId();
            if (id == R.id.ask_again_button)
                pendingOrderClickListener.onAskAgainClick(item);
            else if (id == R.id.remove_order)
                pendingOrderClickListener.onCancelClick(item);
        }

        @Override
        public void bind(Order item) {
            super.bind(item);
            this.item = item;
        }
    }
}
