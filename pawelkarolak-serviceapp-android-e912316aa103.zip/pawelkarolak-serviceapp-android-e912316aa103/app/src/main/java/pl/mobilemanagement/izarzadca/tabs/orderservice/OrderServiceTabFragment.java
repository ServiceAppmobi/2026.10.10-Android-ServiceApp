package pl.mobilemanagement.izarzadca.tabs.orderservice;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.viewpager.widget.ViewPager;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import pl.mobilemanagement.izarzadca.BuildConfig;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.BackHandlerInterface;
import pl.mobilemanagement.izarzadca.databinding.OrderServiceTabBinding;
import pl.mobilemanagement.izarzadca.start_screen.register.LocationListener;
import pl.mobilemanagement.izarzadca.tabs.TabFragment;
import pl.mobilemanagement.izarzadca.tabs.orderservice.model.OrderSummary;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.BaseView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.OrderSummaryActivity;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.impl.ChoiceCompanyView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.photo.AttachPhotoView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.ServicePlaceView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.Place;
import rx.functions.Action0;

public class OrderServiceTabFragment extends TabFragment implements PageViewListener, BackHandlerInterface, ViewPager.OnPageChangeListener, View.OnClickListener {
    public static final String BUILDER_OBJECT = "BUILDER_OBJECT";

    private OrderPagesPagerAdapter adapter;

    private OrderBuilder orderBuilder;

    private int currentPosition = 0;

    private OrderServiceTabBinding binding;

    public String photoFilePath;

    private final ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    AttachPhotoView targetUI = (AttachPhotoView) adapter.getCurrentPage();
                    targetUI.loadPhoto(photoFilePath, targetUI, getOrderBuilder());
                    photoFilePath = null;
                }
            }
    );

    private final ActivityResultLauncher<Intent> pickLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        Uri selectedImage = data.getData();
                        AttachPhotoView targetUI = (AttachPhotoView) adapter.getCurrentPage();
                        targetUI.loadPhoto(selectedImage.toString(), targetUI, getOrderBuilder());
                    }
                }
            }
    );

    private Action0 onSuccess;

    private final ActivityResultLauncher<String[]> locationPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(),
            result -> {
                boolean allGranted = true;
                for (boolean r : result.values()) {
                    if (!r) {
                        allGranted = false;
                        break;
                    }
                }
                if (allGranted && onSuccess != null) {
                    onSuccess.call();
                }
            }
    );

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding = OrderServiceTabBinding.bind(view);
        initOrderBuilder(savedInstanceState);

        LocationListener locationListener = onSuccess -> {
            OrderServiceTabFragment.this.onSuccess = onSuccess;
            locationPermissionLauncher.launch(new String[] { Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION });
        };

        adapter = new OrderPagesPagerAdapter(
            getContext(),
            newTitle -> binding.subtitleOrder.setText(newTitle),
            newText -> binding.next.setText(newText),
            this,
            getActivity(),
            locationListener
        );

        binding.orderViewPager.setAdapter(adapter);
        setHasOptionsMenu(true);
        setActionBarVisibility(currentPosition > 0);
        binding.titleOrder.setText(getString(R.string.step_x_of_y, 1, adapter.getCount()));

        binding.orderViewPager.addOnPageChangeListener(this);
        binding.next.setOnClickListener(this);
    }

    public void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            File photoFile = createImageFile();
            photoFilePath = photoFile.getAbsolutePath();
            Uri photoURI = FileProvider.getUriForFile(
                requireContext(),
                BuildConfig.APPLICATION_ID + ".provider",
                photoFile
            );
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
            cameraLauncher.launch(takePictureIntent);
        } catch (IOException ignored) {

        }
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis());
        return new File(requireContext().getCacheDir(), timeStamp + ".jpg");
    }

    public void dispatchChooseFromGalleryIntent() {
        Intent chooseGalleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickLauncher.launch(chooseGalleryIntent);
    }

    @Override
    public void onClick(View v) {
        adapter.onNext();
    }

    public void setAddress(Place place) {
        if (adapter.getCurrentPage() instanceof ServicePlaceView)
            ((ServicePlaceView) adapter.getCurrentPage()).setAddress(place);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        adapter.onDestroy();
        setActionBarVisibility(false);
    }

    private void initOrderBuilder(@Nullable Bundle savedInstanceState) {
        if (savedInstanceState != null && savedInstanceState.getSerializable(BUILDER_OBJECT) != null) {
            orderBuilder = (OrderBuilder) savedInstanceState.getSerializable(BUILDER_OBJECT);
        } else {
            createOrderBuilderIfNotExist();
        }
    }

    private void createOrderBuilderIfNotExist() {
        if (orderBuilder == null) {
            orderBuilder = new OrderBuilder();
        }
    }

    @Override
    public int getIconResource() {
        return R.drawable.ico_tab_order;
    }

    @Override
    public int getTitleResource() {
        return R.string.tabs_order_service;
    }

    @Override
    protected int getLayout() {
        return R.layout.order_service_tab;
    }

    @Override
    public void showNextPage() {
        final int currentItemPos = binding.orderViewPager.getCurrentItem();
        currentPosition = currentItemPos + 1;
        binding.orderViewPager.setCurrentItem(currentPosition, false);
        binding.titleOrder.setText(getString(R.string.step_x_of_y, currentPosition + 1, adapter.getCount()));
    }

    private void setActionBarVisibility(boolean visible) {
        ActionBar actionBar = ((AppCompatActivity) requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(visible);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public OrderServiceTabFragment getCurrentFragment() {
        return this;
    }

    public boolean onBackPressed() {
        final int currentItemPos = binding.orderViewPager.getCurrentItem();
        if (currentItemPos == 0) {
            return false;
        } else {
            binding.orderViewPager.setCurrentItem(currentItemPos - 1, false);
            binding.titleOrder.setText(getString(R.string.step_x_of_y, binding.orderViewPager.getCurrentItem() + 1, adapter.getCount()));
            return true;
        }
    }

    public BaseView getCurrentPage() {
        return adapter.getCurrentPage();
    }

    @Override
    public void finishOrder(OrderSummary orderSummary) {
        orderBuilder = new OrderBuilder();
        binding.orderViewPager.setCurrentItem(0, false);
        binding.titleOrder.setText(getString(R.string.step_x_of_y, 1, adapter.getCount()));
        binding.subtitleOrder.setText(adapter.getCurrentPage().getTitle());
        OrderSummaryActivity.startForResult(getActivity(), orderSummary);
    }

    @Override
    public OrderBuilder getOrderBuilder() {
        return orderBuilder;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putSerializable(BUILDER_OBJECT, orderBuilder);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}

    @Override
    public void onPageSelected(int position) {
        if (adapter.getCurrentPage() instanceof ChoiceCompanyView)
            binding.next.setText(R.string.order_service_choose_companies);
        else
            binding.next.setText(R.string.order_service_btn_next);
        setActionBarVisibility(position > 0);
    }

    @Override
    public void onPageScrollStateChanged(int state) {}
}
