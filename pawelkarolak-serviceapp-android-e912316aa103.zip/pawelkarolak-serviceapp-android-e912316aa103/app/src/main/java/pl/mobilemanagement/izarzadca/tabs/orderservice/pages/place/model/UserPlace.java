package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model;

public class UserPlace extends Place {
    public static final String USER_PLACE = "100000001";

    public UserPlace() {
        super(USER_PLACE);
    }
}
