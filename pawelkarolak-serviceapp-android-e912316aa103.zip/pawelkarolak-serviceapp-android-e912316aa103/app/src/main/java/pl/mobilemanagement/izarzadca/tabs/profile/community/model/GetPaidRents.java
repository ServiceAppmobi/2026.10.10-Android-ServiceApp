package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Date;

public class GetPaidRents implements Serializable {
    @SerializedName("amount")
    public String amount;

    @SerializedName("createDate")
    public Date createDate;

    @SerializedName("paymentType")
    public String paymentType;

    @SerializedName("name")
    public String name;

    @SerializedName("local")
    public String local;

}
