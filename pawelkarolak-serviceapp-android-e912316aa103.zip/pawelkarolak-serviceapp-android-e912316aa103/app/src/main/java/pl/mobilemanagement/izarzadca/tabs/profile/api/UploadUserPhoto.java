package pl.mobilemanagement.izarzadca.tabs.profile.api;

public class UploadUserPhoto {

    public final String imageString;

    public UploadUserPhoto(String imageString) {
        this.imageString = imageString;
    }
}
