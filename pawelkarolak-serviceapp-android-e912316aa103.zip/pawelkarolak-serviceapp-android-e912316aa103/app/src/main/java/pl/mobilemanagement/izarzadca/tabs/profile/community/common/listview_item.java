package pl.mobilemanagement.izarzadca.tabs.profile.community.common;

/**
 * Created by katak on 27.02.2017.
 */

public class listview_item {

    public String textItem1;
    public String textItem2;
    public String textItem3;
    public String textItem4;
    public String message;
    public String title;

    public boolean isActive = false;
    public int statusId = 0;

    public listview_item(String title, String textItem1, String textItem2, String textItem3, String textItem4, String message) {
        this.title = title;
        this.textItem1 = textItem1;
        this.textItem2 = textItem2;
        this.textItem3 = textItem3;
        this.textItem4 = textItem4;
        this.message = message;
    }

    public listview_item(String title, String textItem1, String textItem2, String textItem3, String textItem4, String message, boolean isActive) {
        this(title, textItem1, textItem2, textItem3, textItem4, message);
        this.isActive = isActive;
    }

    public listview_item(String title, String textItem1, String textItem2, String textItem3, String textItem4, String message, int statusId) {
        this(title, textItem1, textItem2, textItem3, textItem4, message);
        this.statusId = statusId;
    }
}
