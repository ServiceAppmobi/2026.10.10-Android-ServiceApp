package pl.mobilemanagement.izarzadca.tabs.myservices.ended.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.RowAdapter;
import pl.mobilemanagement.izarzadca.databinding.ServiceCompleteRowBinding;
import pl.mobilemanagement.izarzadca.tabs.myservices.ServiceDetailsClickListener;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderServiceType;
import pl.mobilemanagement.izarzadca.tabs.myservices.ended.model.CompletedOrderService;
import rx.Observable;
import rx.subjects.BehaviorSubject;

class CompletedServiceAdapter extends RowAdapter<CompletedOrderService, CompletedServiceAdapter.VH> {
    private final BehaviorSubject<ServiceOrder> listener = BehaviorSubject.create();
    private final ServiceDetailsClickListener detailsClickListener;

    public CompletedServiceAdapter(ServiceDetailsClickListener detailsClickListener) {
        this.detailsClickListener = detailsClickListener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.service_complete_row, parent, false));
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        holder.bind(getItem(position));
    }

    public Observable<ServiceOrder> orderObservable() {
        return listener;
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).id.hashCode();
    }

    class VH extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final ServiceCompleteRowBinding binding;

        private CompletedOrderService item;

        VH(View itemView) {
            super(itemView);
            binding = ServiceCompleteRowBinding.bind(itemView);
            binding.getRoot().setOnClickListener(this);
            binding.serviceDetails.setOnClickListener(this);
        }

        public void bind(CompletedOrderService item) {
            this.item = item;
            int number = getBindingAdapterPosition() + 1;
            binding.title.setText(itemView.getContext().getResources().getString(R.string.text_with_number, number, item.serviceName));
            binding.serviceRating.setRating(item.rating);
        }

        @Override
        public void onClick(View v) {
            if (v == binding.getRoot()) {
                listener.onNext(item);
            } else if (v == binding.serviceDetails) {
                detailsClickListener.onOrderDetailsClick(item.id, OrderServiceType.ENDED);
            }
        }
    }
}
