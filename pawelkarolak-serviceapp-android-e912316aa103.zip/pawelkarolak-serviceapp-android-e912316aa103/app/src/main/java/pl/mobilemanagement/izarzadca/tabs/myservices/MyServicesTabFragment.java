package pl.mobilemanagement.izarzadca.tabs.myservices;

import static pl.mobilemanagement.izarzadca.common.map.MapHelper.mapViewObservable;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.badge.MyServiceBadge;
import pl.mobilemanagement.izarzadca.common.map.MapCircleFactory;
import pl.mobilemanagement.izarzadca.common.map.MapData;
import pl.mobilemanagement.izarzadca.common.map.MapHelper;
import pl.mobilemanagement.izarzadca.common.map.MapMarkerStorage;
import pl.mobilemanagement.izarzadca.common.map.MapWithPos;
import pl.mobilemanagement.izarzadca.common.user.profile.UserService;
import pl.mobilemanagement.izarzadca.common.viewpager.AdapterPageChangeOnSubscribe;
import pl.mobilemanagement.izarzadca.common.viewpager.RxTitledTabsFragmentAdapter;
import pl.mobilemanagement.izarzadca.databinding.TabMyServiceBinding;
import pl.mobilemanagement.izarzadca.tabs.TabFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.during.view.DuringServiceTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.ended.view.CompletedServiceTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.view.PendingServiceTabFragment;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class MyServicesTabFragment extends TabFragment {
    public Subscription onMoveMapToPosSubscription;
    @Inject
    UserService userService;
    @Inject
    MyServiceBadge myServiceBadge;

    TabLayout tabLayout;
    ViewPager viewPager;
    MapView mapView;

    private Subscription mapWithMarkersSubscription;

    public MyServicesTabFragment() {
        App.component.inject(this);
    }

    @Override
    protected void bindTabView(View indicator) {
        myServiceBadge.getBadgeIsAvailable()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(hasUnreaded -> {
                    indicator.setVisibility(hasUnreaded ? View.VISIBLE : View.GONE);
                });
    }

    @Override
    public int getIconResource() {
        return R.drawable.ico_tab_my_services;
    }

    @Override
    public int getTitleResource() {
        return R.string.tabs_my_services;
    }

    @Override
    protected int getLayout() {
        return R.layout.tab_my_service;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        TabMyServiceBinding binding = TabMyServiceBinding.bind(view);
        tabLayout = binding.myServicesTabLayout;
        viewPager = binding.myServicesViewPager;
        mapView = binding.mapView;

        MapHelper.initMapView(mapView);
        final MapMarkerStorage mapMarkerStorage = new MapMarkerStorage();
        final Observable<GoogleMap> googleMapObservable = createGoogleMapObservableWithSelectedPos();
        RxTitledTabsFragmentAdapter<ServiceFragment<? extends ServiceOrder>> tabsFragmentAdapter = createTabAdapter();
        final Observable<ServiceFragment<? extends ServiceOrder>> serviceFragmentObservable = Observable.create(new AdapterPageChangeOnSubscribe<>(tabsFragmentAdapter))
                .share();
        onMoveMapToPosSubscription = createMoveMapToClickedObservable(googleMapObservable, serviceFragmentObservable)
                .subscribe(mapWithPos -> {
                    mapWithPos.googleMap.animateCamera(CameraUpdateFactory.newLatLng(mapWithPos.userPos));
                }, throwable -> Timber.e(throwable, "My services error"));
        mapWithMarkersSubscription = getMapWithMarkerDataObservable(mapMarkerStorage, googleMapObservable, serviceFragmentObservable)
                .subscribe(data -> mapMarkerStorage.addMarkers(data.googleMap, data.markerOptionList),
                        throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
        viewPager.setAdapter(tabsFragmentAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }

    @Override
    public void onResume() {
        super.onResume();
        myServiceBadge.informBadgeWatched();
    }

    private Observable<MapWithPos> createMoveMapToClickedObservable(Observable<GoogleMap> googleMapObservable, Observable<ServiceFragment<? extends ServiceOrder>> serviceFragmentObservable) {
        return serviceFragmentObservable.switchMap(serviceFragment ->
                Observable.combineLatest(serviceFragment.orderClickObservable(),
                        googleMapObservable, (o, googleMap) -> new MapWithPos(googleMap, o.getLatLng())));
    }

    private Observable<MapData> getMapWithMarkerDataObservable(MapMarkerStorage mapMarkerStorage, Observable<GoogleMap> googleMapObservable, Observable<ServiceFragment<? extends ServiceOrder>> serviceFragmentObservable) {
        return serviceFragmentObservable
                .doOnNext(mapData -> mapMarkerStorage.removePreviousMarkers())
                .switchMap(serviceFragment -> Observable.zip(pointsObservable(serviceFragment), googleMapObservable, MapData::new));
    }

    private RxTitledTabsFragmentAdapter<ServiceFragment<? extends ServiceOrder>> createTabAdapter() {
        return new RxTitledTabsFragmentAdapter<>(
                getContext(),
                getChildFragmentManager(),
                Arrays.asList(
                        new PendingServiceTabFragment(),
                        new DuringServiceTabFragment(),
                        new CompletedServiceTabFragment()
                )
        );
    }

    private Observable<GoogleMap> createGoogleMapObservableWithSelectedPos() {
        return mapViewObservable(mapView).zipWith(
                        userService.getProfilePreferOnlyCache()
                                .compose(Rx.applySchedulers()),
                        (googleMap, userProfile) -> new MapWithPos(googleMap, userProfile.lat, userProfile.lng))
                .doOnNext(MapHelper::markCurrentUserPosition)
                .map(mapWithUser -> mapWithUser.googleMap)
                .cache();
    }

    private Observable<List<MarkerOptions>> pointsObservable(ServiceFragment<? extends ServiceOrder> serviceFragment) {
        return serviceFragment.getOrdersObservable()
                .map(this::mapOrdersToPos)
                .map(latLngs -> MapCircleFactory.createServiceOrdersMarkers(getContext(), latLngs));
    }

    private List<LatLng> mapOrdersToPos(List<? extends ServiceOrder> serviceOrders) {
        final List<LatLng> latLngs = new ArrayList<>(serviceOrders.size());
        for (ServiceOrder serviceOrder : serviceOrders) {
            latLngs.add(serviceOrder.getLatLng());
        }
        return latLngs;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        MapHelper.safeDestroyMapView(mapView);
        Rx.safeUnsubscribe(mapWithMarkersSubscription, onMoveMapToPosSubscription);
    }

    /*@Override
    public void onTargetNotification(Observable<Message> oMessage) {
        oMessage.subscribe(message -> {
            myServiceBadge.informBadgeWatched();
        });
    }

    @Override
    public void onMismatchTargetNotification(Observable<Message> oMessage) {

    }

    @Override
    public boolean matchesTarget(String key) {
        return PushType.isServicesPush(key);
    }*/
}
