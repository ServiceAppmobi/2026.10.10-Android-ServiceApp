package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.location.Location;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;

import androidx.annotation.StringRes;

import com.jakewharton.rxbinding.view.RxView;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.location.CurrentLocationService;
import pl.mobilemanagement.izarzadca.common.user.profile.UserService;
import pl.mobilemanagement.izarzadca.databinding.OrderServicePlaceBinding;
import pl.mobilemanagement.izarzadca.start_screen.register.LocationListener;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.orderservice.OrderBuilder;
import pl.mobilemanagement.izarzadca.tabs.orderservice.di.DaggerOrderComponent;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.BaseView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.GPSPlace;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.Place;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.UserPlace;
import pl.mobilemanagement.izarzadca.tools.Pair;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class ServicePlaceView extends BaseView implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    public Subscription fetchCurrentUserProfileAddressSubscription;

    @Inject
    UserService userService;

    private Place selectedUserPlace;

    private final CurrentLocationService locationService;

    private final OrderServicePlaceBinding binding;

    private final Activity activity;

    private final LocationListener locationListener;

    public ServicePlaceView(Context context, Activity activity, LocationListener locationListener) {
        super(context);
        this.activity = activity;
        this.locationListener = locationListener;
        locationService = new CurrentLocationService(activity);
        DaggerOrderComponent.builder().applicationComponent(App.component).build().inject(this);
        binding = OrderServicePlaceBinding.bind(getChildAt(0));

        setMyAddress(binding.rbMyLocation, R.string.my_location);
        setMyAddress(binding.rbAddress, R.string.address);

        binding.tvDifferentAddress.setOnClickListener(this);
        binding.rbMyLocation.setOnCheckedChangeListener(this);
        binding.rbAddress.setOnCheckedChangeListener(this);
    }

    @Override
    public void onNext() {
        super.onNext();
        if (selectedUserPlace == null) {
            ValidationErrorDialogHelper.show(getContext(), new Validator().addError(getString(R.string.place_not_selected)));
        } else {
            final OrderBuilder orderBuilder = pageViewListener.getOrderBuilder();
            orderBuilder.setPlace(selectedUserPlace);
            pageViewListener.showNextPage();
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.tvDifferentAddress) {
            Intent intent = new Intent(getContext(), DifferentAddressActivity.class);
            activity.startActivityForResult(intent, MainActivity.REQ_SET_DIFFERENT_ADDRESS);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked)
            binding.tvDifferentAddress.setSelected(false);
    }

    private void setMyAddress(RadioButton radioButton, @StringRes int stringRes) {
        SpannableStringBuilder spannable = new SpannableStringBuilder(getString(stringRes).replace("\n%s", ""));
        spannable.setSpan(
            new StyleSpan(Typeface.BOLD),
            0, spannable.length(),
            Spannable.SPAN_EXCLUSIVE_INCLUSIVE
        );
        spannable.setSpan(
            new AbsoluteSizeSpan(14, true),
            0, spannable.length(),
            Spannable.SPAN_EXCLUSIVE_INCLUSIVE
        );
        radioButton.setText(spannable);
    }

    private void setMyAddress(RadioButton radioButton, @StringRes int stringRes, String address) {
        String text = getContext().getString(stringRes, address);
        SpannableStringBuilder spannable = new SpannableStringBuilder(text);
        spannable.setSpan(
                new StyleSpan(Typeface.BOLD),
                0, text.indexOf('\n'),
                Spannable.SPAN_EXCLUSIVE_INCLUSIVE
        );
        spannable.setSpan(
                new AbsoluteSizeSpan(14, true),
                0, text.indexOf('\n'),
                Spannable.SPAN_EXCLUSIVE_INCLUSIVE
        );
        radioButton.setText(spannable);
    }

    public void setAddress(Place place) {
        selectedUserPlace = place;
        binding.tvDifferentAddress.setSelected(true);
        binding.rbAddress.setChecked(false);
        binding.rbMyLocation.setChecked(false);
    }

    @Override
    protected void onAttached() {
        super.onAttached();
        fetchCurrentUserProfileAddressSubscription = fetchCurrentUserProfileAddress();

        locationListener.requestLocationPermissions(() -> {
            final Observable<Place> gpsObservable = locationService.fetchCurrentGPSPosition()
                    .observeOn(Schedulers.io())
                    .flatMap(this::wrapObservable)
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnNext(locationStringPair -> setMyAddress(binding.rbMyLocation, R.string.my_location, locationStringPair.second))
                    .map(locationStringPair -> {
                        final Location location = locationStringPair.first;
                        return new GPSPlace(location);
                    });

            final Observable<Observable<Place>> gpsClickObservable = RxView
                    .clicks(binding.rbMyLocation)
                    .startWith((Void) null)
                    .map(aVoid -> gpsObservable);

            final Observable<Observable<Place>> profileClickObservable =
                    RxView.clicks(binding.rbAddress)
                            .map(aVoid -> Observable.fromCallable(UserPlace::new));

            Observable.switchOnNext(Observable.merge(gpsClickObservable, profileClickObservable))
                    .subscribe(place -> selectedUserPlace = place);
        });

        binding.rbMyLocation.performClick();
    }

    private Observable<Pair<Location, String>> wrapObservable(Location location) {
        return Observable.zip(
                Observable.just(location),
                locationService.getReverseGeocodeObservable(location)
                    .map(geoAddress ->
                        formattedAddress(
                            geoAddress.getPostalCode(),
                            geoAddress.getLocality(),
                            geoAddress.getAddressLine(0),
                            geoAddress.getAddressLine(1)
                        )
                    ),
                Pair::new
        );
    }

    private Subscription fetchCurrentUserProfileAddress() {
        return userService.getProfilePreferOnlyCache()
                .compose(Rx.applySchedulers())
                .subscribe(
                    userProfile -> updateProfileLocation(userProfile.postalCode, userProfile.city, userProfile.street, userProfile.number),
                    throwable -> ApiErrorDialogHelper.show(getContext(), throwable)
                );
    }

    private void updateProfileLocation(String postalCode, String city, String street, String number) {
        final String address = formattedAddress(postalCode, city, street, number);
        setMyAddress(binding.rbAddress, R.string.address, address);
    }

    private String formattedAddress(String postalCode, String city, String street, String number) {
        return String.format("%s %s, %s %s", postalCode, city, street, number);
    }

    @Override
    protected void onDetached() {
        super.onDetached();
        Rx.safeUnsubscribe(fetchCurrentUserProfileAddressSubscription);
    }

    @Override
    protected int titleResource() {
        return R.string.order_service_order_place;
    }

    @Override
    protected int layoutResource() {
        return R.layout.order_service_place;
    }
}
