package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata;

import java.util.regex.Pattern;

public class FlatNumberValidator {
    private static final Pattern FLAT_PATTERN
            = Pattern.compile("[0-9]+(/[a-zA-Z0-9]+)?");

    public boolean isValid(String flatNumber) {
        return FLAT_PATTERN.matcher(flatNumber).matches();
    }
}
