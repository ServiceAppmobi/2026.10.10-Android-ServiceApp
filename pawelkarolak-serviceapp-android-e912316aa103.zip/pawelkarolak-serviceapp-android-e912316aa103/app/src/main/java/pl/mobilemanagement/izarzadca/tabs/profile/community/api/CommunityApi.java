package pl.mobilemanagement.izarzadca.tabs.profile.community.api;

import java.util.List;

import pl.mobilemanagement.izarzadca.tabs.profile.community.model.CheckIfCommunityMember;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.CommunityBoardMembers;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.CommunityInfo;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetAnnouncements;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetFailureReports;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetFailureSubjects;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetPaidRents;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetRents;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.RegisterFailureReport;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.RentBalance;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetEmails;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import rx.Observable;

/**
 * Created by katak on 10.01.2017.
 */

public interface CommunityApi {

    @GET("Community/GetContactDetails")

    public Observable<CommunityInfo> getCommunityInfo();

    @GET("Community/GetCommunityBoardMembers")

    public Observable<List<CommunityBoardMembers>> getCommunityBoardMembers();

    @GET("finance/GetRentBalance")

    public Observable<RentBalance> getRentBalance();

    @GET("finance/GetRents")
    public Observable<List<GetRents>> getRents();

    @GET("finance/GetPaidRents")
    public Observable<List<GetPaidRents>> getPaidRents();


    @GET("community/GetAnnouncements")
    public Observable<List<GetAnnouncements>> getAnnouncements();


    @GET("Community/GetFailureReports")
    public Observable<List<GetFailureReports>> getFailureReports();


    @GET("Community/CheckIfCommunityMember")
    public Observable<CheckIfCommunityMember> checkIfCommunityMember();

    @GET("Account/GetEmails")
    public Observable<List<GetEmails>> GetEmails();




    @GET("Dictionaries/GetFailureSubjects")
    public Observable<List<GetFailureSubjects>> getFailureSubjects();

    @POST("Community/RegisterFailureReport")
    Observable<Void> registerFailureReport(@Body RegisterFailureReport report);
}
