package pl.mobilemanagement.izarzadca.common.di.api;

import java.util.List;

import pl.mobilemanagement.izarzadca.common.model.api.CustomerRegister;
import pl.mobilemanagement.izarzadca.common.model.api.DistanceArea;
import pl.mobilemanagement.izarzadca.common.model.api.LoginResponse;
import pl.mobilemanagement.izarzadca.common.model.entity.AccountTypeName;
import pl.mobilemanagement.izarzadca.common.model.entity.Country;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.CheckLoginOccupation;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.CompanyRegister;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneactivate.CheckCodeVerification;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneregister.PhoneVerification;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import pl.mobilemanagement.izarzadca.tabs.profile.api.UserDataApiModel;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import rx.Observable;

public interface UnauthorizedApi {

    @POST("Register/GetLoginExists")
    Observable<Void> checkLoginExist(@Body CheckLoginOccupation login);

    @POST("Register/AccountVerification")
    Observable<Void> sendCodeToPhoneNumber(@Body PhoneVerification phoneVerification);

    @POST("Register/CheckVerificationCode")
    Observable<Void> checkVerificationCode(@Body CheckCodeVerification checkCodeVerification);

    @GET("Dictionaries/GetAccountType")
    Observable<List<AccountTypeName>> getAvailableAccountsTypes();

    @GET("Dictionaries/GetCountries")
    Observable<List<Country>> getCountries();

    @GET("Dictionaries/GetAllTypesServices")
    Observable<List<ServiceModel>> getTypeServicesResponse();

    @GET("Dictionaries/GetDistanceArea")
    Observable<List<DistanceArea>> getDistanceArea();

    @POST("Register/RegisterCustomer")
    Observable<LoginResponse> registerCustomer(@Body CustomerRegister customerRegister);


    @POST("Register/RegisterServiceProvider")
    Observable<LoginResponse> registerCompany(@Body CompanyRegister companyRegister);

    @GET("Account/GetUserDataByPhone")
    Observable<UserDataApiModel> getUserDataByPhone(
        @Query("phoneNumber") String phoneNumber,
        @Query("smsCode") String smsCode
    );
}
