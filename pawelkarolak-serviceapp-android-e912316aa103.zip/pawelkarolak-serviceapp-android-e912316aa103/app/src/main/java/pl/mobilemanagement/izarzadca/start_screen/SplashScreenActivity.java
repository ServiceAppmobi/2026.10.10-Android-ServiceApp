package pl.mobilemanagement.izarzadca.start_screen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;

public class SplashScreenActivity extends Activity {
    @Inject
    TokenDataSource tokenDataSource;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        App.component.inject(this);
        final boolean isUserLogin = tokenDataSource.hasToken();
        final Intent intent;
        if (isUserLogin) {
            intent = new Intent(this, MainActivity.class);
        } else {
            intent = new Intent(this, LoginOrRegisterActivity.class);
        }
        finish();
        startActivity(intent);
    }

}
