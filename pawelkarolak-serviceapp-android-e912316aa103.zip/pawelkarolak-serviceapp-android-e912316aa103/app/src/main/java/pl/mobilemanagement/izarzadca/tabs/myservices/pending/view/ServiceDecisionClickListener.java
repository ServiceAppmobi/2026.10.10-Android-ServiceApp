package pl.mobilemanagement.izarzadca.tabs.myservices.pending.view;

interface ServiceDecisionClickListener {

    void onPayClick(String orderId);

    void onRejectClick(String orderId);

    void onAcceptWithoutPayment(String orderId);
}
