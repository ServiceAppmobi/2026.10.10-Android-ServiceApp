package pl.mobilemanagement.izarzadca.start_screen.login.di;

import dagger.Module;
import dagger.Provides;
import retrofit2.Retrofit;

@Module
public class LoginModule {

    @Provides
    public LoginServiceApi providesLoginApi(Retrofit retrofit) {
        return retrofit.create(LoginServiceApi.class);
    }
}