package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.AddressPlace;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.GPSPlace;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.Place;

public abstract class ServiceProviderRequest {

    final String placeType;
    final String serviceId;

    // GPS provider
    String lat;
    String lng;

    // Address provider
    String countryId;
    String city;
    String postalCode;
    String street;
    String number;

    ServiceProviderRequest(String serviceId, Place place) {
        this.serviceId = serviceId;
        this.placeType = place.placeId;
    }

    public static ServiceProviderRequest createProviderRequest(String serviceId, Place place) {
        ServiceProviderRequest orderRequest;
        if (place instanceof AddressPlace) {
            orderRequest = new AddressServiceProviderRequest(serviceId, (AddressPlace) place);
        } else if (place instanceof GPSPlace) {
            orderRequest = new GPSServiceProviderRequest(serviceId, (GPSPlace) place);
        } else {
            orderRequest = new NormalProviderRequest(serviceId, place);
        }
        return orderRequest;
    }
}
