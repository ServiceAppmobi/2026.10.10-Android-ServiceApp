package pl.mobilemanagement.izarzadca.tabs.orderservice;

import android.view.View;
import android.view.ViewGroup;
import androidx.viewpager.widget.PagerAdapter;
import pl.mobilemanagement.izarzadca.start_screen.register.OnTitleChangedListener;
import pl.mobilemanagement.izarzadca.tools.pages.PageListener;
import pl.mobilemanagement.izarzadca.tools.pages.PageView;

public abstract class PagesAdapter<T> extends PagerAdapter {
  private PageView<T> mCurrentView;

  private PageListener<T> pageViewListener;

  private OnTitleChangedListener titleChangedListener;

  private int lastPosition = -1;

  public PagesAdapter(OnTitleChangedListener titleChangedListener, PageListener<T> pageViewListener) {
    this.titleChangedListener = titleChangedListener;
    this.pageViewListener = pageViewListener;
  }

  @Override
  public final void setPrimaryItem(ViewGroup container, int position, Object object) {
    if (isCurrentItem(position)) {
      return;
    }
    if (mCurrentView != null && !mCurrentView.isDetached()) {
      mCurrentView.viewDetach();
    }
    mCurrentView = (PageView<T>) object;
    mCurrentView.viewAttach(pageViewListener);
    final int humanPosition = position + 1;
    final CharSequence title = mCurrentView.getTitle(humanPosition);
    titleChangedListener.titleChange(title);
  }

  private boolean isCurrentItem(int position) {
    if (lastPosition == position) {
      return true;
    } else {
      lastPosition = position;
    }
    return false;
  }

  @Override
  public final PageView<T> instantiateItem(ViewGroup container, int position) {
    PageView<T> view = createViewByPos(position);
    container.addView(view);
    return view;
  }

  public abstract PageView<T> createViewByPos(int pos);

  @Override
  public final void destroyItem(ViewGroup container, int position, Object object) {
    PageView oldView = (PageView) object;
    if (!oldView.isDetached()) {
      oldView.viewDetach();
    }
    container.removeView(oldView);
  }

  @Override
  public abstract int getCount();

  @Override
  public boolean isViewFromObject(View view, Object object) {
    return view == object;
  }

  public final PageView<T> getCurrentPage() {
    return mCurrentView;
  }

  public void onDestroy() {
    if (mCurrentView != null && !mCurrentView.isDetached()) {
      mCurrentView.viewDetach();
    }
  }
}