package pl.mobilemanagement.izarzadca.common.model.api;

import java.io.Serializable;
import java.util.Date;

public class Order implements Serializable {
    public String id;
    public Date startDateTime;
    public Date endDateTime;
    public String street;
    public String number;
    public String postalCode;
    public String city;
    public String country;
    public String serviceName;
    public String issueDescription;
    public String serviceProvider;
}
