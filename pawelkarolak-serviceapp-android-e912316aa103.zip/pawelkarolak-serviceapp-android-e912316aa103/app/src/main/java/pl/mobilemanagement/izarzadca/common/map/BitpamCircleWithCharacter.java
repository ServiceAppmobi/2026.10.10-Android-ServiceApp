package pl.mobilemanagement.izarzadca.common.map;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import pl.mobilemanagement.izarzadca.R;

public class BitpamCircleWithCharacter {
    private final Paint textPaint;
    private final Paint circlePaint;
    private final Paint circlePaintStroke;

    private final int size;
    private Rect r = new Rect();

    public BitpamCircleWithCharacter(Context context) {
        size = convertToPixels(context, 25);
        textPaint = initTextPaint(context);
        circlePaintStroke = createCircleStrokePaint(context);
        circlePaint = createCirclePaint(context);
    }

    public static int convertToPixels(Context context, int nDP) {
        final float conversionScale = context.getResources().getDisplayMetrics().density;
        return (int) ((nDP * conversionScale) + 0.5f);
    }

    private Paint createCirclePaint(Context context) {
        final Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(ContextCompat.getColor(context, R.color.light_blue));
        return paint;
    }


    private Paint createCircleStrokePaint(Context context) {
        final Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(convertToPixels(context, 2));
        return paint;
    }

    public Bitmap drawCharacterAtCenter(String text) {
        Bitmap bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bm);
        drawCircle(canvas);
        drawCircleShape(canvas);
        drawTextOnCenterCanvas(canvas, text);
        return bm;
    }

    private void drawCircleShape(Canvas canvas) {
        canvas.drawCircle(getCenterX(), getCenterY(), getRadius(), circlePaintStroke);
    }

    private int getRadius() {
        return r.height() / 2 - 2;
    }

    private int getCenterY() {
        return r.height() / 2;
    }

    private int getCenterX() {
        return r.width() / 2;
    }

    private void drawCircle(Canvas canvas) {
        canvas.getClipBounds(r);
        canvas.drawCircle(getCenterX(), getCenterY(), getRadius(), circlePaint);
    }


    private void drawTextOnCenterCanvas(Canvas canvas, String text) {
        canvas.getClipBounds(r);
        int cHeight = r.height();
        int cWidth = r.width();
        textPaint.getTextBounds(text, 0, text.length(), r);
        float x = cWidth / 2f - getCenterX() - r.left;
        float y = cHeight / 2f + getCenterY() - r.bottom;
        canvas.drawText(text, x, y, textPaint);
    }


    @NonNull
    private Paint initTextPaint(Context context) {
        Paint paint = new Paint();
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setColor(Color.WHITE);
        paint.setTextSize(convertToPixels(context, 13));
        return paint;
    }
}
