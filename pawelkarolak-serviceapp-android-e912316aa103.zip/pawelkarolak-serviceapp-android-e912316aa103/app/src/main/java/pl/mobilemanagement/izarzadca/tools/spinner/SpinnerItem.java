package pl.mobilemanagement.izarzadca.tools.spinner;

public interface SpinnerItem {
}
