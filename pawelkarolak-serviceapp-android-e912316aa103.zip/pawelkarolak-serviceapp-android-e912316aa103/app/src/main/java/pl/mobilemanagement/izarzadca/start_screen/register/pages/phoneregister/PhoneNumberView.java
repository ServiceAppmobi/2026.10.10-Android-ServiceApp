package pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneregister;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.regex.Pattern;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.CountrySpinnerAdapter;
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi;
import pl.mobilemanagement.izarzadca.common.model.entity.Country;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.databinding.RegisterPhoneNumberBinding;
import pl.mobilemanagement.izarzadca.start_screen.register.RegisterBuilder;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.PageRegisterView;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class PhoneNumberView extends PageRegisterView implements View.OnClickListener {
    private static final Pattern PHONE_PATTERN
            = Pattern.compile(                      // sdd = space, dot, or dash
            "(\\+[0-9]+[\\- \\.]*)?"        // +<digits><sdd>*
                    + "(\\([0-9]+\\)[\\- \\.]*)?"   // (<digits>)<sdd>*
                    + "([0-9][0-9\\- \\.]+[0-9])"); // <digit><digit|sdd>+<digit>
    public Subscription countryFetchSubscription;
    public Subscription sendPhoneNumberSubscription;

    TextInputEditText phoneNumber;
    TextInputLayout tlPhoneNumber;
    MaterialAutoCompleteTextView countrySpinner;
    MaterialCheckBox ruleCheckbox;
    TextView ruleLink;
    TextView privacyPolicyLink;

    @Inject
    UnauthorizedApi unauthorizedApi;

    @Inject
    AccountTypeDataSource accountTypeDataSource;

    private Country selectedCountry;

    public PhoneNumberView(Context context) {
        super(context);

        RegisterPhoneNumberBinding binding = RegisterPhoneNumberBinding.bind(this);
        phoneNumber = binding.etRegisterPhone;
        tlPhoneNumber = binding.tlPhone;
        countrySpinner = binding.countrySpinner;
        ruleCheckbox = binding.ruleCheckbox;
        ruleLink = binding.ruleLink;
        privacyPolicyLink = binding.privacyPolicyLink;
        binding.next.setOnClickListener(v -> onNextButtonClick());

        App.component.inject(this);
        createSpinnerAdapter();
    }

    private void createSpinnerAdapter() {
        countrySpinner.setOnItemClickListener((parent, view, position, id) -> {
            this.selectedCountry = (Country) parent.getAdapter().getItem(position);
            tlPhoneNumber.setPrefixText(selectedCountry.areaCode);
        });
    }

    @Override
    protected void onAttached() {
        fetchCountries();
        ruleLink.setOnClickListener(this);
        privacyPolicyLink.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if(id == R.id.ruleLink) {
            goByLink("https://serviceapp.mobi/terms");
        } else if (id == R.id.privacyPolicyLink) {
            goByLink("https://serviceapp.mobi/privacy");
        }
    }

    private void goByLink(String link) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
        browserIntent.addFlags(FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(browserIntent);
    }

    private void fetchCountries() {
        countryFetchSubscription = unauthorizedApi.getCountries()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(countries -> {
                    CountrySpinnerAdapter adapter = new CountrySpinnerAdapter(getContext(), android.R.layout.simple_list_item_1, countries);
                    countrySpinner.setAdapter(adapter);
                }, throwable -> ApiErrorDialogHelper.show(getContext(), throwable));

    }

    @Override
    protected void onDetached() {
        countrySpinner.dismissDropDown();
        Rx.safeUnsubscribe(countryFetchSubscription, sendPhoneNumberSubscription);
    }

    private void onNextButtonClick() {
        Validator validator = validateInput();
        if (validator.isValid()) {
            sendPhoneNumber();
        } else {
            ValidationErrorDialogHelper.show(getContext(), validator);
        }
    }

    private void sendPhoneNumber() {
        final String phoneNumberWithPrefix = getPhoneNumberWithPrefix();
        final String phoneNumber = getPhoneNumber();
        sendPhoneNumberSubscription = unauthorizedApi.sendCodeToPhoneNumber(new PhoneVerification(phoneNumberWithPrefix))
                .compose(Rx.applySchedulers())
                .compose(ProgressDialog.create(getContext()))
                .subscribe((aVoid) -> {
                    RegisterBuilder builder = getCurrentBuilder();
                    builder.setPhoneNumber(phoneNumber);
                    builder.setCountry(selectedCountry);
                    accountTypeDataSource.setCountry(selectedCountry.id);
                    pageViewListener.showNextPage();
                }, throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    private Validator validateInput() {
        Validator validator = new Validator();
        if (!ruleCheckbox.isChecked()) {
            validator.addError(getContext().getString(R.string.account_data_you_have_to_accent_rules));
        }
        final CharSequence selectedText = countrySpinner.getText();
        if (TextUtils.isEmpty(selectedText)) {
            validator.addError(getContext().getString(R.string.register_phone_you_have_to_choose_country));
        }
        if (!isPhoneNumber() || isWrongNumberLength()) {
            validator.addError(getContext().getString(R.string.register_phone_wrong_phone_number));
        }
        return validator;
    }

    private boolean isPhoneNumber() {
        return PHONE_PATTERN.matcher(getPhoneNumber()).matches();
    }

    private boolean isWrongNumberLength() {
        final int numberLength = getPhoneNumber().length();
        return numberLength > 30 && numberLength < 9;
    }

    @Override
    protected int titleResource() {
        return R.string.registration_phone_number;
    }

    @Override
    protected int layoutResource() {
        return R.layout.register_phone_number;
    }

    private String getPhoneNumber() {
        return phoneNumber.getText().toString();
    }

    private String getPhoneNumberWithPrefix() {
        return tlPhoneNumber.getPrefixText() + getPhoneNumber();
    }
}
