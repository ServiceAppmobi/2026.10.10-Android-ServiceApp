package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider.ServiceProvider;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.AddressPlace;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.GPSPlace;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.Place;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;

public abstract class OrderRequest {
    public final String placeType;
    public String serviceId;
    public String issueDescription;
    public Date startDateTime;
    public Date endDateTime;
    public List<String> serviceProviders;
    public List<String> photos;

    protected OrderRequest(Place place) {
        this.placeType = place.placeId;
    }

    public static OrderRequest createOrderSpecificByData(Place place) {
        OrderRequest orderRequest;
        if (place instanceof AddressPlace) {
            orderRequest = new AddressOrderRequest((AddressPlace) place);
        } else if (place instanceof GPSPlace) {
            orderRequest = new GpsOrderRequest((GPSPlace) place);
        } else {
            orderRequest = new NormalOrderRequest(place);
        }
        return orderRequest;
    }

    public void setServiceProviders(List<ServiceProvider> providers) {
        final List<String> providersIds = new ArrayList<>(providers.size());
        for (ServiceProvider serviceProvider : providers) {
            providersIds.add(serviceProvider.id);
        }
        this.serviceProviders = providersIds;
    }

    public void setServiceType(ServiceModel selectedServiceType) {
        this.serviceId = selectedServiceType.serviceId;
    }
}
