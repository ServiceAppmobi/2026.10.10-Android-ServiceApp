package pl.mobilemanagement.izarzadca.tabs.myservices.common;

import java.util.List;

import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import rx.Observable;


public abstract class ServiceFragment<T extends ServiceOrder> extends TitledTabFragment {
    public abstract Observable<List<T>> getOrdersObservable();

    public abstract Observable<ServiceOrder> orderClickObservable();
}
