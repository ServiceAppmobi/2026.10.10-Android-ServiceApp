package pl.mobilemanagement.izarzadca.start_screen.login_or_register

import pl.mobilemanagement.izarzadca.common.model.api.LoginResponse
import pl.mobilemanagement.izarzadca.common.model.api.SocialSignInRequest
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface SocialApiService {
    @Headers("Content-Type: application/json")
    @POST("Account/GoogleLogin")
    suspend fun signInWithGoogle(@Body socialSignInRequest: String) : LoginResponse

    @Headers("Content-Type: application/json")
    @POST("Account/FacebookLogin")
    suspend fun signInWithFacebook(@Body facebookSignInRequest: String) : LoginResponse
}