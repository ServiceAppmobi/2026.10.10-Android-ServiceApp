package pl.mobilemanagement.izarzadca.common.model.api;

import pl.mobilemanagement.izarzadca.common.user.profile.UserProfile;

public class BraintreeCheckoutRequest {

    public UserProfile user;
    public double amount;
    public String currency;
    public String nonce;
    public String orderId;
    public BraintreePaymentNonce paymentNonce;

    public BraintreeCheckoutRequest() {

    }

    public BraintreeCheckoutRequest(UserProfile user, double amount, String currency, String nonce, String orderId, BraintreePaymentNonce paymentNonce) {
        this.user = user;
        this.amount = amount;
        this.currency = currency;
        this.nonce = nonce;
        this.orderId = orderId;
        this.paymentNonce = paymentNonce;
    }

}
