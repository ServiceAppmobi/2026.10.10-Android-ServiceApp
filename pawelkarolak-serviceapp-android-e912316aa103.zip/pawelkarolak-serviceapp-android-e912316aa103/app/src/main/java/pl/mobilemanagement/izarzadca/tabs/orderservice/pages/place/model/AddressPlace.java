package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model;

public class AddressPlace extends Place {
    public static final String ADDRESS_PLACE = "100000000";
    public final String city;
    public final String countryId;
    public final String street;
    public final String number;
    public final String postalCode;

    public AddressPlace(String city, String countryId, String street, String number, String postalCode) {
        super(ADDRESS_PLACE);
        this.city = city;
        this.countryId = countryId;
        this.street = street;
        this.number = number;
        this.postalCode = postalCode;
    }
}
