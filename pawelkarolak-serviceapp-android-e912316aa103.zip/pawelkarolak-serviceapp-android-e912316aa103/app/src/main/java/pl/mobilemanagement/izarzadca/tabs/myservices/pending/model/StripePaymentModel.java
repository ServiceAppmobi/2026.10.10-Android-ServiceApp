package pl.mobilemanagement.izarzadca.tabs.myservices.pending.model;

public class StripePaymentModel {
    public String clientSecret;
    public String ephemeralKey;
    public String customerId;
}
