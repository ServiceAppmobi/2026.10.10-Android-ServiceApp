package pl.mobilemanagement.izarzadca.start_screen.register;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import pl.mobilemanagement.izarzadca.common.invite.InviteFriendActivity;
import pl.mobilemanagement.izarzadca.common.invite.contact.InviteType;
import pl.mobilemanagement.izarzadca.databinding.RegisterFriendsBinding;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.TabToMove;

public class RecommendToFriendActivity extends AppCompatActivity {

    public static final int ASK_FOR_FRIEND = 123;

    public static void startActivityOnTop(Context context) {
        Intent startIntent = new Intent(context, RecommendToFriendActivity.class);
        startIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(startIntent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        RegisterFriendsBinding binding = RegisterFriendsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.skipReccomendToFriend.setOnClickListener(v -> onBackPressed());
        binding.registrationFriendSms.setOnClickListener(v -> inviteSMS());
        binding.registrationFriendEmail.setOnClickListener(v -> inviteEmail());
    }

    @Override
    public void onBackPressed() {
        MainActivity.startActivity(this, TabToMove.PROFILE);
    }

    private void inviteSMS() {
        InviteFriendActivity.startForResult(this, InviteType.PHONE, ASK_FOR_FRIEND, false);
    }

    private void inviteEmail() {
        InviteFriendActivity.startForResult(this, InviteType.EMAIL, ASK_FOR_FRIEND, false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ASK_FOR_FRIEND && resultCode == Activity.RESULT_OK)
            MainActivity.startActivity(this, TabToMove.PROFILE);
        else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}
