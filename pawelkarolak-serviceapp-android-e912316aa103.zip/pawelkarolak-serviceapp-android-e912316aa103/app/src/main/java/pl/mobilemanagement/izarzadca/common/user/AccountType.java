package pl.mobilemanagement.izarzadca.common.user;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import static pl.mobilemanagement.izarzadca.common.user.AccountType.Constants.CUSTOMER_ID;
import static pl.mobilemanagement.izarzadca.common.user.AccountType.Constants.PROVIDER_ID;


public enum AccountType {
    @Expose
    @SerializedName(CUSTOMER_ID)
    CUSTOMER,
    @Expose
    @SerializedName(PROVIDER_ID)
    SERVICE_PROVIDER;

    public static AccountType createAccountTypeFromInt(int accountType) {
        if (Integer.toString(accountType).equals(PROVIDER_ID))
            return SERVICE_PROVIDER;
        else
            return CUSTOMER;
    }

    public boolean isProvider() {
        return this == SERVICE_PROVIDER;
    }

    static class Constants {
        static final String CUSTOMER_ID = "100000009";
        static final String PROVIDER_ID = "100000006";
    }
}
