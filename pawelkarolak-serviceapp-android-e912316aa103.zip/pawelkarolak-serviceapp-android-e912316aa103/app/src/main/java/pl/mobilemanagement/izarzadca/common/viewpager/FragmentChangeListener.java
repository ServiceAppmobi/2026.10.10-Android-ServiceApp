package pl.mobilemanagement.izarzadca.common.viewpager;

public interface FragmentChangeListener<T> {
    void onPagePrimary(T fragment);
}
