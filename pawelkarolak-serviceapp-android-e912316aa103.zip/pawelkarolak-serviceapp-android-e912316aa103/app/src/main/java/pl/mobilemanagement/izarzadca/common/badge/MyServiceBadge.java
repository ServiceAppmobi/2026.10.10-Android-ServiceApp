package pl.mobilemanagement.izarzadca.common.badge;

import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;

public class MyServiceBadge extends BadgeListener {
    private static final String SERVICES_NOT_READED = "services_readed";

    public MyServiceBadge(DataSourceRepository localDataRepository) {
        super(localDataRepository, SERVICES_NOT_READED);
    }
}
