package pl.mobilemanagement.izarzadca.tabs.myservices.pending.model;

import java.util.List;

public class StripePaymentMethodsModel {
    public List<StripePaymentMethodModel> data;
}

