package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model;

import java.io.Serializable;

import pl.mobilemanagement.izarzadca.common.map.Address;

public class PersonalData implements Serializable {
    private final String userName;
    private final String surName;
    private final String email;

    public PersonalData(String userName, String surName, String email) {
        this.userName = userName;
        this.surName = surName;
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public String getSurName() {
        return surName;
    }

    public String getEmail() {
        return email;
    }

}
