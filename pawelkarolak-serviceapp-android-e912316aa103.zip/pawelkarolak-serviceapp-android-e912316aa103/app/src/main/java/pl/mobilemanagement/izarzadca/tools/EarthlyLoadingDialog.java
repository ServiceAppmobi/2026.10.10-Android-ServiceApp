package pl.mobilemanagement.izarzadca.tools;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import pl.mobilemanagement.izarzadca.R;

public class EarthlyLoadingDialog extends DialogFragment {

  ImageView imageView;

  @Nullable
  @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.earthly_loading_dialog, container);

    imageView = view.findViewById(R.id.imageView);

    getDialog().setCancelable(false);
    getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
    getDialog().setCanceledOnTouchOutside(false);
    return view;
  }

  @Override
  public void onActivityCreated(Bundle savedInstanceState) {
    super.onActivityCreated(savedInstanceState);
    startAnimate();
  }

  protected void startAnimate() {

    imageView.setBackgroundResource(R.drawable.earthly_animation);

    // Get the background, which has been compiled to an AnimationDrawable object.
    AnimationDrawable frameAnimation = (AnimationDrawable) imageView.getBackground();

    // Start the animation (looped playback by default).
    frameAnimation.start();
  }

  @Override
  public void dismiss() {
    try {
      super.dismiss();
    } catch (Exception e) {
      Log.e("Dismiss", e.getLocalizedMessage());
    }
  }
}
