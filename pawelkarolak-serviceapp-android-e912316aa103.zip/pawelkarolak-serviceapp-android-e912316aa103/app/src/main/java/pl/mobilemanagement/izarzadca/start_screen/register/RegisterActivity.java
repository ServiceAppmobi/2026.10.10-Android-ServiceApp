package pl.mobilemanagement.izarzadca.start_screen.register;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.phone.SmsRetriever;

import java.util.ArrayList;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.invite.InviteFriendActivity;
import pl.mobilemanagement.izarzadca.common.invite.contact.InviteType;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.databinding.ActivityRegisterBinding;
import pl.mobilemanagement.izarzadca.start_screen.login_or_register.SocialData;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.CompanyDataView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.ServiceSelectActivity;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.CompanyInfo;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.ServiceItem;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneactivate.PhoneActivateView;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.TabToMove;
import pl.mobilemanagement.izarzadca.tools.AdsBannerUtil;
import pl.mobilemanagement.izarzadca.tools.pages.PageListener;
import pl.mobilemanagement.izarzadca.tools.pages.PageView;
import rx.functions.Action0;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String REGISTER_SAVED_STATE = "register_saved_state";
    public static final String SOCIAL_DATA_EXTRA = "SOCIAL_DATA_EXTRA";
    public static final int REQ_USER_CONSENT = 200;
    public static final int ASK_FOR_FRIEND = 123;

    private ActivityRegisterBinding binding;

    private RegisterBuilder registerBuilder = new RegisterBuilder();

    private AdsBannerUtil adsBannerUtil;

    private RegisterPagerAdapter adapter;

    @Inject
    AccountTypeDataSource accountTypeDataSource;

    private Action0 onSuccess;

    private final ActivityResultLauncher<String[]> locationPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(),
            result -> {
                boolean allGranted = true;
                for (boolean r : result.values()) {
                    if (!r) {
                        allGranted = false;
                        break;
                    }
                }
                if (allGranted && onSuccess != null) {
                    onSuccess.call();
                }
            }
    );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        restorePreviousBuilderIfPossible(savedInstanceState);

        App.component.inject(this);

        adsBannerUtil = new AdsBannerUtil(getApplication(), accountTypeDataSource);
        adsBannerUtil.init(binding.adsBanner.bottomAds);

        SocialData socialData = getIntent().getParcelableExtra(SOCIAL_DATA_EXTRA);
        if(socialData == null)
            socialData = new SocialData();

        LocationListener locationListener = onSuccess -> {
            RegisterActivity.this.onSuccess = onSuccess;
            locationPermissionLauncher.launch(new String[] { Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION });
        };

        adapter = new RegisterPagerAdapter(this, newTitle -> {}, new PageListener<RegisterBuilder>() {
            @Override
            public void showNextPage() {
                final int currentItemPos = binding.viewPager.getCurrentItem();
                final int newItemPosition = currentItemPos + 1;
                binding.viewPager.setCurrentItem(newItemPosition, false);
            }

            @Override
            public void finishPaging() {
                if(registerBuilder.inviteType != null)
                    InviteFriendActivity.startForResult(RegisterActivity.this, registerBuilder.inviteType, ASK_FOR_FRIEND, true);
                else
                    MainActivity.startActivity(RegisterActivity.this, TabToMove.PROFILE);
            }

            @Override
            public RegisterBuilder getCurrentBuilder() {
                return registerBuilder;
            }
        }, locationListener, this, socialData);
        binding.viewPager.setAdapter(adapter);

        binding.backArrow.setOnClickListener(this);
    }

    private void restorePreviousBuilderIfPossible(@Nullable Bundle savedInstanceState) {
        if (hasPreviousBuilder(savedInstanceState)) {
            registerBuilder = ((RegisterBuilder) savedInstanceState.getSerializable(REGISTER_SAVED_STATE));
        }
    }

    private boolean hasPreviousBuilder(Bundle savedInstanceState) {
        return savedInstanceState != null && savedInstanceState.getSerializable(REGISTER_SAVED_STATE) != null;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if(id == R.id.backArrow) {
            onBackPressed();
        }
    }

    @Override
    public void onBackPressed() {
        final int currentItemPos = binding.viewPager.getCurrentItem();
        if (currentItemPos == 0) {
            super.onBackPressed();
        } else {
            binding.viewPager.setCurrentItem(currentItemPos - 1, false);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable(REGISTER_SAVED_STATE, registerBuilder);
    }

    @Override
    protected void onPause() {
        super.onPause();
        adsBannerUtil.releaseAdsView();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ_USER_CONSENT) {
            if(resultCode == RESULT_OK && data != null) {
                String message = data.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE);
                PageView<RegisterBuilder> currentPage = adapter.getCurrentPage();
                if(currentPage instanceof PhoneActivateView) {
                    ((PhoneActivateView)currentPage).onMessageReceived(message);
                }
            }
        } else if (requestCode == ASK_FOR_FRIEND && resultCode == Activity.RESULT_OK)
            MainActivity.startActivity(this, TabToMove.PROFILE);
        else if(requestCode == ServiceSelectActivity.REQ_SERVICES_RESULT && resultCode == Activity.RESULT_OK && data != null) {
            PageView<RegisterBuilder> currentPage = adapter.getCurrentPage();
            if(currentPage instanceof CompanyDataView) {
                Parcelable[] resultData = data.getParcelableArrayExtra(ServiceSelectActivity.ARG_SERVICES);
                ArrayList<ServiceItem> serviceItems = new ArrayList<>();
                for(Parcelable result : resultData) {
                    serviceItems.add((ServiceItem)result);
                }
                ((CompanyDataView)currentPage).companyInfoController.setSelectedTypeServices(serviceItems);
            }
        }
    }
}
