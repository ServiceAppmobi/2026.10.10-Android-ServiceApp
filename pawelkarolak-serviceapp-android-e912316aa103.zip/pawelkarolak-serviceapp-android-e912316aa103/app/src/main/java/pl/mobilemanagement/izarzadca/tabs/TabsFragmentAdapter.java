package pl.mobilemanagement.izarzadca.tabs;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import java.util.List;

class TabsFragmentAdapter extends FragmentPagerAdapter {
    private final List<TabFragment> fragments;


    public TabsFragmentAdapter(@NonNull FragmentManager fm, @NonNull List<TabFragment> tabFragments) {
        super(fm);
        this.fragments = tabFragments;
    }

    @Override
    public TabFragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }



}