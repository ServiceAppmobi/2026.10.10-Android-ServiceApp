package pl.mobilemanagement.izarzadca.start_screen;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import io.intercom.android.sdk.Intercom;
import pl.mobilemanagement.izarzadca.databinding.ActivityLoginRegisterBinding;
import pl.mobilemanagement.izarzadca.start_screen.login.LoginActivity;
import pl.mobilemanagement.izarzadca.start_screen.register.RegisterActivity;

public class LoginOrRegisterActivity extends AppCompatActivity {

    public static void startOnTop(Context context) {
        Intent startIntent = new Intent(context, LoginOrRegisterActivity.class);
        startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(startIntent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityLoginRegisterBinding binding = ActivityLoginRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.loginButton.setOnClickListener(v -> onLoginClick());
        binding.registerButton.setOnClickListener(v -> onRegisterClick());

        Intercom.client().logout();
    }

    void onLoginClick() {
        startActivity(new Intent(this, LoginActivity.class));
    }

    void onRegisterClick() {
        startActivity(new Intent(this, RegisterActivity.class));
    }
}
