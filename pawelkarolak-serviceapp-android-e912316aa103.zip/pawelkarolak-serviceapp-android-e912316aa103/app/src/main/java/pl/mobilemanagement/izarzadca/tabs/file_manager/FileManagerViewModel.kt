package pl.mobilemanagement.izarzadca.tabs.file_manager

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.annotation.RequiresApi
import androidx.core.net.toFile
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.FileOutputStream
import javax.inject.Inject

class FileManagerViewModel @Inject constructor(
    private val fileManagerApi: FileManagerApi,
    private val app: Application
): ViewModel() {

    private val _loading = MutableLiveData(false)
    val loading: LiveData<Boolean> = _loading

    private val _files = MutableLiveData(emptyList<File>())
    val files : LiveData<List<File>> = _files

    private val _openFile = MutableSharedFlow<Pair<java.io.File, Uri?>>()
    val openFile = _openFile.asSharedFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _loading.postValue(true)
                _files.postValue(fileManagerApi.getAll())
            } catch(e: HttpException) {
                e.printStackTrace()
            } finally {
                _loading.postValue(false)
            }
        }
    }

    fun downloadFile(file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _loading.postValue(true)
                val response = fileManagerApi.downloadFile(file.url)
                val fileName = file.url.split("/").last()
                val bytes = response.body()!!.bytes()

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveFileUsingMediaStore(fileName, file.extension, bytes)
                } else {
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val target = java.io.File(downloadsDir, fileName)
                    FileOutputStream(target).use { output ->
                        output.write(bytes)
                    }
                    _openFile.emit(target to null)
                }
            } catch(e: HttpException) {
                e.printStackTrace()
            } finally {
                _loading.postValue(false)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private suspend fun saveFileUsingMediaStore(fileName: String, extension: String, bytes: ByteArray) {
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension))
            put(MediaStore.MediaColumns.RELATIVE_PATH, FILES_DIR)
        }
        val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
        if (uri != null) {
            app.contentResolver.openOutputStream(uri).use { output ->
                output?.write(bytes)
            }

            val dir = Environment.getExternalStoragePublicDirectory(FILES_DIR)
            _openFile.emit(java.io.File(dir, fileName) to uri)
        }
    }

    companion object {
        private val FILES_DIR = Environment.DIRECTORY_DOWNLOADS
    }
}