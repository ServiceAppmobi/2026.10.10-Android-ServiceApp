package pl.mobilemanagement.izarzadca.tabs;

public enum TabToMove {
    PROFILE(0),
    ORDER_SERVICE(1),
    MY_ORDERS(2),
    MY_SERVICES(3);

    private final int tabPos;

    TabToMove(int tabPos) {
        this.tabPos = tabPos;
    }

    public int value() {
        return tabPos;
    }
}
