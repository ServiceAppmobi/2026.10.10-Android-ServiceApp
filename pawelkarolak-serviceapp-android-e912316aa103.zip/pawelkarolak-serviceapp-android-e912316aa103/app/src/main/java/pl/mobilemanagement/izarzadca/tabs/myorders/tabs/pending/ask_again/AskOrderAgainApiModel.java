package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.ask_again;

import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AskOrderAgainApiModel {
    public final String id;
    public final String issueDescription;
    public String startDateTime;
    public String endDateTime;

    public AskOrderAgainApiModel(String id, String issueDescription, Date startDateTime, Date endDateTime) {
        //02-02-2017 22:06:02
        //2016-08-17T16:00:28.384Z
        //SimpleDateFormat form = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS"); "12-04-2017 18:06:20  -> 2017-04-12T19:04:41.414Z
        Log.i("dsaaaaaaaaaaaaaa","asddsadasad");
        this.id = id;
        this.issueDescription = issueDescription;

        this.endDateTime = endDateTime.toString();
        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

        this.startDateTime = dateformat.format(startDateTime);

        this.endDateTime = dateformat.format(endDateTime);


    }
}
