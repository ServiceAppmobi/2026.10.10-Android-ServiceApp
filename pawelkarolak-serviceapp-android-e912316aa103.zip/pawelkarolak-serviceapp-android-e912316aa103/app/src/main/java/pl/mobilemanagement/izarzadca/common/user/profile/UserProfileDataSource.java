package pl.mobilemanagement.izarzadca.common.user.profile;

import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;

public class UserProfileDataSource {

    private final static String KEY = "profile";
    private final DataSourceRepository repository;

    public UserProfileDataSource(DataSourceRepository repository) {
        this.repository = repository;
    }

    public void clear() {
        repository.clear(KEY);
    }

    public boolean hasProfile() {
        return repository.has(KEY);
    }

    public void saveProfile(UserProfile userProfile) {
        repository.write(KEY, userProfile, UserProfile.class);
    }

    public UserProfile getUserProfile() {
        return repository.read(KEY, UserProfile.class);
    }
}