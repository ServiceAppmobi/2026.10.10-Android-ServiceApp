package pl.mobilemanagement.izarzadca.common.model.api

import com.google.gson.annotations.SerializedName

data class SocialSignInRequest(
    @SerializedName("UserToken")
    val userToken: String,
    /*@SerializedName("FirstName")
    val firstName: String,
    @SerializedName("LastName")
    val lastName: String,
    @SerializedName("ImageUrl")
    val imageUrl: String*/
)