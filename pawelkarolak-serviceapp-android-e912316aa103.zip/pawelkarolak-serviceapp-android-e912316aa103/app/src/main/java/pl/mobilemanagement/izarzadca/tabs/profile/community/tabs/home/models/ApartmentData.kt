package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models

data class ApartmentData(
    val propertyBalance: String,
    val monthlyRent: String,
    val apartmentName: String,
    val apartmentAddress: String,
    val paymentDueDate: String,
    val meetingDate: String?,
    val payments: List<Payment>,
)
