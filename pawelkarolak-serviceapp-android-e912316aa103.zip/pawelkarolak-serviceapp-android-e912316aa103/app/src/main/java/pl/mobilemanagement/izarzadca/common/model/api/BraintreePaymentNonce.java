package pl.mobilemanagement.izarzadca.common.model.api;

import java.util.Map;

public class BraintreePaymentNonce {

    public String type;
    public String description;
    public String nonce;

    // Credit Card
    public String lastFour;
    public String cardType;

    // Paypal
    public String clientMetadataId;
    public String email;
    public String firstName;
    public String lastName;
    public String payerId;
    public String phone;
    public String shippingAddress;

    // Venmo
    public String username;
    public String typeLabel;

    // Google Pay
    public String billingAddress;
    //public string ShippingAddress;
    //public string CardType;
    //public string LastFour;

    public BraintreePaymentNonce() {

    }

    public BraintreePaymentNonce(String type, String description, String nonce) {
        this.type = type;
        this.description = description;
        this.nonce = nonce;
    }
}
