package pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model;

import java.io.Serializable;
import java.util.List;

import pl.mobilemanagement.izarzadca.common.map.Address;
import pl.mobilemanagement.izarzadca.common.model.api.SimpleServiceModel;

public class CompanyInfo implements Serializable {
    public final String companyName;
    public final String companyNIP;
    public final String companyEmail;
    public final String companyDesc;
    public final String companyBusinessArea;
    public final List<SimpleServiceModel> companyServiceType;
    public final Address companyAddress;
    public CompanyInfo(String companyName,
                       String companyNIP,
                       String companyEmail,
                       String companyDesc,
                       String companyBusinessArea,
                       List<SimpleServiceModel> companyServiceType,
                       Address companyAddress) {
        this.companyName = companyName;
        this.companyNIP = companyNIP;
        this.companyEmail = companyEmail;
        this.companyDesc = companyDesc;
        this.companyBusinessArea = companyBusinessArea;
        this.companyServiceType = companyServiceType;
        this.companyAddress = companyAddress;
    }
}
