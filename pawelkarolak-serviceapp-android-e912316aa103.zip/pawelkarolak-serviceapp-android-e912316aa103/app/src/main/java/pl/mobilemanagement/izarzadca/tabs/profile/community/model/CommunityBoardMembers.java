package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Objects;

public class CommunityBoardMembers implements Serializable {
    @SerializedName("position")
    public String position;

    @SerializedName("fullName")
    public String fullName;

    @SerializedName("phone")
    public String phone;

    @SerializedName("email")
    public String email;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CommunityBoardMembers that = (CommunityBoardMembers) o;
        return Objects.equals(position, that.position) && Objects.equals(fullName, that.fullName) && Objects.equals(phone, that.phone) && Objects.equals(email, that.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(position, fullName, phone, email);
    }
}
