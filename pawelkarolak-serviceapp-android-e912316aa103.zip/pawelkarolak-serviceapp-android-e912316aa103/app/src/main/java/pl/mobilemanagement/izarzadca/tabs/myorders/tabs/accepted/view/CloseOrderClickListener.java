package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view;

import pl.mobilemanagement.izarzadca.common.model.api.Order;

public interface CloseOrderClickListener {

    void onCloseOrderClick(Order order);
    //void onPayOrderClick(Order order);

}
