package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view;

import static pl.mobilemanagement.izarzadca.tools.rx.Rx.applyDataLoader;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.applyLCE;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.applySchedulers;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.safeUnsubscribe;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jakewharton.rxbinding.support.v4.widget.RxSwipeRefreshLayout;

import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.model.api.OrderId;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.databinding.RecyclerPullViewFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.myorders.api.ClientOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myorders.di.DaggerMyOrdersComponent;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.rate_order.OrderRateActivity;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.LCE;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import rx.Observable;
import rx.Subscription;

public class AcceptedOrderTabFragment extends TitledTabFragment implements CloseOrderClickListener, LCE<Order>, View.OnClickListener {
    private final AcceptedOrderAdapter acceptedOrdersAdapter = new AcceptedOrderAdapter(this);

    @Inject
    ClientOrdersApi clientOrdersApi;

    private RecyclerPullViewFrameBinding binding;

    private Subscription fetchSubscription;

    private Subscription closeSubscription;

    private Subscription refreshSubscription;

    private EarthlyLoadingDialog earthlyDialog;

    @Override
    public int getTitleResource() {
        return R.string.my_order_tab_accepted_by_contractor;
    }

    @Override
    protected int getLayout() {
        return R.layout.recycler_pull_view_frame;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerMyOrdersComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding = RecyclerPullViewFrameBinding.bind(view);
        initRecyclerView();
        binding.noItems.noItemsMessage.setText(getString(R.string.no_orders));
        binding.noItems.btnRefresh.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnRefresh) {
            fetchSubscription = fetchAcceptedOrders().subscribe();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchSubscription = fetchAcceptedOrders().subscribe();
        refreshSubscription = RxSwipeRefreshLayout.refreshes(binding.refreshLayout)
                .flatMap(aVoid -> fetchAcceptedOrders())
                .subscribe();
    }

    @Override
    public void onPause() {
        super.onPause();
        safeUnsubscribe(fetchSubscription, closeSubscription, refreshSubscription);
    }

    private Observable<List<Order>> fetchAcceptedOrders() {
        safeUnsubscribe(fetchSubscription);
        return clientOrdersApi.getAcceptedOrders()
                .compose(applySchedulers())
                .compose(applyLCE(this))
                .compose(applyDataLoader(this));
    }

    private void initRecyclerView() {
        binding.listRecyclerView.setAdapter(acceptedOrdersAdapter);
    }

    @Override
    public void onCloseOrderClick(Order order) {
        closeSubscription = clientOrdersApi.closeCompletedOrder(new OrderId(order.id))
                .compose(applySchedulers())
                .compose(ProgressDialog.create(getContext()))
                .subscribe(aVoid -> OrderRateActivity.start(getContext(), order.id),
                        throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }
 /*   @Override
    public void onPayOrderClick(Order order) {
        PaymentActivity.start(MainActivity.instance, order);
        Log.i("Click","payOrder");
    }*/

    @Override
    public void setData(List<Order> data) {
        acceptedOrdersAdapter.setDataList(data);
        binding.noItems.getRoot().setVisibility(data.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void showProgressBar() {
        earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager());
        //        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgressBar() {
        ProgressHelper.safeDismiss(earthlyDialog);
        //        progressBar.setVisibility(View.GONE);
        binding.refreshLayout.setRefreshing(false);
    }

    @Override
    public void hideError() {
        binding.listError.setVisibility(View.GONE);
        binding.noItems.getRoot().setVisibility(View.GONE);
    }

    @Override
    public void showEmptyListError() {
        binding.noItems.getRoot().setVisibility(View.VISIBLE);
    }

    @Override
    public void showConnectionError() {
        binding.noItems.getRoot().setVisibility(View.GONE);
        binding.listError.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.list_view_connection_error);
    }
}
