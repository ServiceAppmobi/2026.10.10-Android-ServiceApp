package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.date;

import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;

import android.content.Context;

import java.util.Calendar;
import java.util.Date;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.databinding.OrderServiceDateBinding;
import pl.mobilemanagement.izarzadca.tabs.orderservice.OrderBuilder;
import pl.mobilemanagement.izarzadca.tabs.orderservice.di.DaggerOrderComponent;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.BaseView;

public class ChoiceDateView extends BaseView {

    private final Calendar calendar = Calendar.getInstance();

    private final OrderServiceDateBinding binding;

    public ChoiceDateView(Context context) {
        super(context);
        DaggerOrderComponent.builder().applicationComponent(App.component).build().inject(this);
        binding = OrderServiceDateBinding.bind(getChildAt(0));
    }

    @Override
    public void onNext() {
        super.onNext();
        Date normalizeStartDate = normalizeDate(binding.dateFrom.getSelectedDate());
        Date normalizeEndDate = normalizeDate(binding.dateTo.getSelectedDate());
        if (normalizeEndDate.before(normalizeStartDate)) {
            normalizeEndDate = normalizeStartDate;
        }
        final OrderBuilder orderBuilder = pageViewListener.getOrderBuilder();
        orderBuilder.setProposeOrderDate(normalizeStartDate, normalizeEndDate);
        orderBuilder.setIssueDescription(getTrimmedText(binding.orderDescription));
        pageViewListener.showNextPage();
    }

    private Date normalizeDate(Date date) {
        if (isDateNeedNormalize(date)) {
            return new Date();
        }
        return date;
    }

    private boolean isDateNeedNormalize(Date date) {
        return date == null || calendar.getTime().after(date);
    }

    @Override
    protected int titleResource() {
        return R.string.order_service_select_date;
    }

    @Override
    protected int layoutResource() {
        return R.layout.order_service_date;
    }
}
