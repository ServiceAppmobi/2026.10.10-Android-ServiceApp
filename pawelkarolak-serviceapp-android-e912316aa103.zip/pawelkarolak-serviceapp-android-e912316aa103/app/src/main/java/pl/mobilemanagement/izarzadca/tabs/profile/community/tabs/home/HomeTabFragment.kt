package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home

import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.isVisible
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textfield.TextInputLayout.END_ICON_DROPDOWN_MENU
import com.google.android.material.textfield.TextInputLayout.END_ICON_NONE
import pl.mobilemanagement.izarzadca.App
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.common.di.DaggerViewModelFactory
import pl.mobilemanagement.izarzadca.databinding.DialogRequestDepositBinding
import pl.mobilemanagement.izarzadca.databinding.TabHomeBinding
import pl.mobilemanagement.izarzadca.tabs.MainActivity
import pl.mobilemanagement.izarzadca.tabs.TabFragment
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.CommunityManagement
import pl.mobilemanagement.izarzadca.tools.DateUtil
import pl.mobilemanagement.izarzadca.tools.EditTextHelper
import java.util.*
import javax.inject.Inject


class HomeTabFragment : TabFragment() {

    private lateinit var binding: TabHomeBinding

    @Inject
    lateinit var viewModelFactory: DaggerViewModelFactory

    private val viewModel by viewModels<HomeTabViewModel>()

    private lateinit var dialogBinding: DialogRequestDepositBinding

    private val mainActivityViewModel by lazy {
        (requireActivity() as MainActivity).viewModel
    }

    private val paymentsAdapter by lazy {
        PaymentsAdapter(emptyList())
    }

    private val apartmentsAdapter by lazy {
        ArrayAdapter(requireContext(), R.layout.item_dropdown, mutableListOf<String>())
    }

    private val optionsAdapter by lazy {
        ArrayAdapter(requireContext(), R.layout.item_dropdown, options.toMutableList())
    }

    private val options by lazy {
        resources.getStringArray(R.array.home_options)
    }

    private var fromBackground = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.component.inject(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = TabHomeBinding.bind(view)
        dialogBinding = DialogRequestDepositBinding.inflate(layoutInflater)
        setupViews()
        observe()
        setSystemUiVisibility(false)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        setSystemUiVisibility(true)
    }

    private fun setSystemUiVisibility(light: Boolean) {
        val window = requireActivity().window
        window.statusBarColor = ContextCompat.getColor(requireContext(), if (light) R.color.white else R.color.main)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = light
    }

    override fun onStart() {
        super.onStart()
        mainActivityViewModel.selectedApartment.value?.let {
            mainActivityViewModel.setApartment(it)
        }
    }

    override fun onResume() {
        super.onResume()
        (requireActivity() as MainActivity).setToolbarVisibility(false)
    }

    override fun onStop() {
        super.onStop()
        (requireActivity() as MainActivity).setToolbarVisibility(true)
        fromBackground = true
    }

    private fun setupViews() {
        binding.viewAll.paintFlags = binding.viewAll.paintFlags or Paint.UNDERLINE_TEXT_FLAG

        binding.tvApartments.setDropDownBackgroundResource(R.drawable.bg_dropdown)
        binding.tvSpinner.setDropDownBackgroundResource(R.drawable.bg_dropdown)

        /*binding.tvApartments.setOnClickListener {
            val radius = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 16f, resources.displayMetrics)
            if(binding.tvApartments.isPopupShowing) {
                binding.tlApartments.setBoxCornerRadii(radius, radius, 0f, 0f)
                binding.dropDownIcon.rotation = 180f
            } else {
                binding.tlApartments.setBoxCornerRadii(radius, radius, radius, radius)
                binding.dropDownIcon.rotation = 0f
            }
        }*/

        /*binding.tvApartments.setOnDismissListener {
            val radius = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 16f, resources.displayMetrics)
            binding.tlApartments.setBoxCornerRadii(radius, radius, radius, radius)
            binding.dropDownIcon.rotation = 0f
        }*/

        binding.tvSpinner.setAdapter(optionsAdapter)

        binding.tvApartments.setAdapter(apartmentsAdapter)
        binding.tvApartments.setOnItemClickListener { _, _, position, _ ->
            mainActivityViewModel.setApartmentByIndex(position)
            binding.dropDownIcon.rotation = 0f
        }

        binding.tvSpinner.setOnItemClickListener { _, _, position, _ ->
            viewModel.setOptionByIndex(position)
        }

        val dividerItemDecoration = DividerItemDecorator(ContextCompat.getDrawable(requireContext(), R.drawable.divider))
        binding.rvPayments.addItemDecoration(dividerItemDecoration)

        binding.btnMenu.setOnClickListener {
            (activity as MainActivity).openDrawer()
        }

        binding.rvPayments.adapter = paymentsAdapter

        binding.btnMail.setOnClickListener {
            (activity as MainActivity).openItemInDrawer('k', true)
        }

        binding.contactManagment.setOnClickListener {
            val fragment = CommunityManagement()
            fragment.activity = activity
            activity?.supportFragmentManager?.beginTransaction()
                    ?.replace(R.id.main_frame, fragment)
                    ?.addToBackStack(null)
                    ?.commit()
        }

        binding.viewAll.setOnClickListener {
            val fragment = PaymentsFragment()
            fragment.paymentsList = mainActivityViewModel.apartmentData.value?.payments.orEmpty()
            activity?.supportFragmentManager?.beginTransaction()
                    ?.replace(R.id.main_frame, fragment)
                    ?.addToBackStack(null)
                    ?.commit()
        }

        binding.btnRequestDeposit.setOnClickListener {
            if (mainActivityViewModel.selectedApartment.value?.isTenant == true) {
                (activity as MainActivity).startFix()
            } else {
                AlertDialog.Builder(requireContext())
                        .setPositiveButton(R.string.yes) { dialog, _ ->
                            dialog.dismiss()
                            val amount = EditTextHelper.getTrimmedText(dialogBinding.amount)
                            val note = EditTextHelper.getTrimmedText(dialogBinding.notes)
                            mainActivityViewModel.requestDeposit(amount, note)
                            dialogBinding.amount.text = null
                            dialogBinding.notes.text = null
                        }
                        .setView(dialogBinding.root)
                        .show()
            }
        }
    }

    private fun observe() {
        mainActivityViewModel.apartments.observe(viewLifecycleOwner) {
            apartmentsAdapter.clear()
            apartmentsAdapter.addAll(it.map { getString(R.string.apartment_n, it.name) })
            binding.tlApartments.enableDropdown(it.size > 1)
        }
        mainActivityViewModel.selectedApartment.observe(viewLifecycleOwner) {
            apartmentsAdapter.filter.filter("")
            val apartmentName = getString(R.string.apartment_n, it.name)
            val spannable = SpannableStringBuilder(apartmentName)
            spannable.setSpan(
                    StyleSpan(Typeface.BOLD),
                    0,
                    apartmentName.length,
                    Spannable.SPAN_EXCLUSIVE_INCLUSIVE
            )
            binding.tvApartments.setText(spannable, false)

            binding.spinner.enableDropdown(!it.isTenant)
            if (it.isTenant) {
                binding.tvSpinner.dismissDropDown()

                binding.btnRequestDeposit.icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_error)
                binding.btnRequestDeposit.setText(R.string.report_fault)
            } else {
                binding.btnRequestDeposit.icon = null
                binding.btnRequestDeposit.setText(R.string.request_deposit)
            }
        }
        mainActivityViewModel.displayPayments.observe(viewLifecycleOwner) {
            paymentsAdapter.update(it)
            binding.rvPayments.post {
                val i = (binding.rvPayments.layoutManager as LinearLayoutManager).findLastCompletelyVisibleItemPosition()
                if(i == RecyclerView.NO_POSITION)
                    binding.rvPayments.isVisible = false
                else
                    paymentsAdapter.update(it.take(i + 1))
            }
        }
        mainActivityViewModel.apartmentData.observe(viewLifecycleOwner) {
            if (it != null) {
                binding.balance.text = if (viewModel.selectedOption.value == HomeTabViewModel.Balance.BALANCE)
                    it.propertyBalance
                else
                    it.monthlyRent

                binding.paymentDueDateValue.text = DateUtil.getFormattedDateFromServerDate(it.paymentDueDate, DateUtil.DD_MM_YYYY_FORMAT)

                val calendar = Calendar.getInstance()
                calendar.time = DateUtil.getDateFromServerFormat(it.paymentDueDate)
                calendar.add(Calendar.MONTH, -1)
                binding.startDate.text = DateUtil.formatDate(calendar.time, DateUtil.MMM_DD_FORMAT)
                binding.endDate.text = DateUtil.getFormattedDateFromServerDate(it.paymentDueDate, DateUtil.MMM_DD_FORMAT)

                if (it.meetingDate != null)
                    binding.adminMeetingValue.text = DateUtil.getFormattedDateFromServerDate(it.meetingDate, DateUtil.DD_MM_YYYY_FORMAT)
                else
                    binding.adminMeetingValue.text = "-"

                val apartmentName = getString(R.string.apartment_n, it.apartmentName)
                val spannable = SpannableStringBuilder(apartmentName + "\n" + it.apartmentAddress)
                spannable.setSpan(
                        StyleSpan(Typeface.BOLD),
                        0,
                        apartmentName.length,
                        Spannable.SPAN_EXCLUSIVE_INCLUSIVE
                )
                apartmentsAdapter.filter.filter("")
                binding.tvApartments.setText(spannable, false)

                if (mainActivityViewModel.selectedApartment.value?.isTenant == true)
                    viewModel.setOptionByIndex(HomeTabViewModel.Balance.BALANCE.ordinal)

                binding.paymentHistory.isVisible = it.payments.isNotEmpty()
                binding.viewAll.isVisible = it.payments.isNotEmpty()
            }
        }
        viewModel.selectedOption.observe(viewLifecycleOwner) {
            optionsAdapter.filter.filter("")
            binding.tvSpinner.setText(options[it.ordinal], false)
            mainActivityViewModel.apartmentData.value?.let {
                binding.balance.text = if (viewModel.selectedOption.value == HomeTabViewModel.Balance.BALANCE)
                    it.propertyBalance
                else
                    it.monthlyRent
            }
        }
    }

    private fun TextInputLayout.enableDropdown(enabled: Boolean) {
        if (enabled) {
            endIconMode = END_ICON_DROPDOWN_MENU
            isClickable = true
            isEnabled = true
        } else {
            endIconMode = END_ICON_NONE
            isClickable = false
            isEnabled = false
        }
    }

    override fun getLayout(): Int {
        return R.layout.tab_home
    }

    override fun getIconResource(): Int {
        return R.drawable.ic_home2
    }

    override fun getTitleResource(): Int {
        return R.string.main
    }

}