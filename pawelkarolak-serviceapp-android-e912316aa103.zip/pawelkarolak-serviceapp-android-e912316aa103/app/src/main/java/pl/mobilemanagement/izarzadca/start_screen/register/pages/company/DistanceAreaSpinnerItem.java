package pl.mobilemanagement.izarzadca.start_screen.register.pages.company;


import java.util.ArrayList;
import java.util.List;

import pl.mobilemanagement.izarzadca.common.model.api.DistanceArea;
import pl.mobilemanagement.izarzadca.tools.spinner.SpinnerItem;


public class DistanceAreaSpinnerItem implements SpinnerItem {

    private final DistanceArea distanceArea;

    public DistanceAreaSpinnerItem(DistanceArea distanceArea) {
        this.distanceArea = distanceArea;
    }

    public static List<DistanceAreaSpinnerItem> createSpinnerItems(List<DistanceArea> distanceAreas) {
        final List<DistanceAreaSpinnerItem> distanceAreaSpinnerItems = new ArrayList<>();
        for (DistanceArea distanceArea : distanceAreas) {
            distanceAreaSpinnerItems.add(new DistanceAreaSpinnerItem(distanceArea));
        }
        return distanceAreaSpinnerItems;

    }

    public DistanceArea getDistanceArea() {
        return distanceArea;
    }

    @Override
    public String toString() {
        return distanceArea.value;
    }
}