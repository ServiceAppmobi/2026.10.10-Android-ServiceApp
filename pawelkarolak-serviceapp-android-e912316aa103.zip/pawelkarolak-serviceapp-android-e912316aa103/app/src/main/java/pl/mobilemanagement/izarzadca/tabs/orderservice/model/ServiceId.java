package pl.mobilemanagement.izarzadca.tabs.orderservice.model;

import com.google.gson.annotations.Expose;

public class ServiceId {
    @Expose
    public final String serviceId;

    public ServiceId(String serviceId) {
        this.serviceId = serviceId;
    }
}


