package pl.mobilemanagement.izarzadca.tabs.orderservice.di;

import dagger.Component;
import pl.mobilemanagement.izarzadca.common.di.ApplicationComponent;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.impl.ChoiceCompanyView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.photo.AttachPhotoView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.date.ChoiceDateView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.ChoiceServiceView;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.ServicePlaceView;

@OrderScope
@Component(dependencies = ApplicationComponent.class, modules = OrderModule.class)
public interface OrderComponent {

    void inject(ChoiceDateView choiceDateView);

    void inject(ChoiceServiceView choiceServiceView);

    void inject(AttachPhotoView attachPhotoView);

    void inject(ServicePlaceView servicePlaceView);

    void inject(ChoiceCompanyView choiceCompanyView);
}
