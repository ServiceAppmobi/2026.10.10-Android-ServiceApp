package pl.mobilemanagement.izarzadca.tabs.profile.community.di;

import dagger.Component;
import pl.mobilemanagement.izarzadca.common.badge.MyOrderBadge;
import pl.mobilemanagement.izarzadca.common.di.ApplicationComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.FailureReport;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.BillsHistory;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.BillsSummary;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.CommunityCommunity;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.CommunityManagement;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.DocumentsAnnouncements;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.DocumentsApplications;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.MessagesTab;

@MyCommunityScope
@Component(dependencies = ApplicationComponent.class, modules = CommunityModule.class)
public interface MyCommunityComponent {
    MyOrderBadge f();
    void inject(CommunityCommunity communityCommunity);
    void inject(BillsHistory billsHistory);
    void inject(BillsSummary billsSummary);
    void inject(CommunityManagement communityCommunity);
    void inject(DocumentsAnnouncements documentsAnnouncements);
    void inject(DocumentsApplications documentsApplications);
    void inject(MessagesTab documentsApplications);
    void inject(FailureReport failureReport);
}
