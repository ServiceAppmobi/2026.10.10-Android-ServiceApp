package pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneactivate;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.content.ContextCompat;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Status;

import java.io.EOFException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi;
import pl.mobilemanagement.izarzadca.common.model.api.SimpleServiceModel;
import pl.mobilemanagement.izarzadca.common.model.entity.AccountTypeName;
import pl.mobilemanagement.izarzadca.common.user.AccountType;
import pl.mobilemanagement.izarzadca.databinding.RegisterActivatePhoneBinding;
import pl.mobilemanagement.izarzadca.start_screen.register.RegisterActivity;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.PageRegisterView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.CompanyInfo;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model.PersonalData;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;
import timber.log.Timber;

public class PhoneActivateView extends PageRegisterView {
    public static final int VERIFICATION_CODE_LENGHT = 6;
    public Subscription checkVerificationCodeSubscribtion;

    TextView activatePhoneNumber;

    AppCompatEditText code1;
    AppCompatEditText code2;
    AppCompatEditText code3;
    AppCompatEditText code4;
    AppCompatEditText code5;
    AppCompatEditText code6;

    @Inject
    UnauthorizedApi registerApi;

    private final Activity activity;

    private final BroadcastReceiver smsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Objects.equals(intent.getAction(), SmsRetriever.SMS_RETRIEVED_ACTION)) {
                Bundle extras = intent.getExtras();
                Status smsRetrieverStatus = (Status) extras.get(SmsRetriever.EXTRA_STATUS);
                switch (smsRetrieverStatus.getStatusCode()) {
                    case CommonStatusCodes.SUCCESS:
                        Intent messageIntent = extras.getParcelable(SmsRetriever.EXTRA_CONSENT_INTENT);
                        activity.startActivityForResult(messageIntent, RegisterActivity.REQ_USER_CONSENT);
                        break;
                }
            }
        }
    };

    public PhoneActivateView(Context context, Activity activity) {
        super(context);
        App.component.inject(this);

        RegisterActivatePhoneBinding binding = RegisterActivatePhoneBinding.bind(getChildAt(0));
        activatePhoneNumber = binding.registerActivatePhoneNumber;
        code1 = binding.code1;
        code2 = binding.code2;
        code3 = binding.code3;
        code4 = binding.code4;
        code5 = binding.code5;
        code6 = binding.code6;
        binding.next.setOnClickListener(v -> onNextButtonClick());

        this.activity = activity;

        code1.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(1)});
        code2.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(1)});
        code3.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(1)});
        code4.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(1)});
        code5.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(1)});
        code6.setFilters(new InputFilter[]{new InputFilter.AllCaps(), new InputFilter.LengthFilter(1)});

        setTextWatcher(code1, code2);
        setTextWatcher(code2, code3);
        setTextWatcher(code3, code4);
        setTextWatcher(code4, code5);
        setTextWatcher(code5, code6);
        setTextWatcher(code6, null);
    }

    private void setTextWatcher(EditText editText, EditText nextEditText) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (nextEditText != null && s.length() > 0)
                    nextEditText.requestFocus();
                else {
                    InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getWindowToken(), 0);
                }
            }
        });
    }

    @Override
    protected void onAttached() {
        String phoneNumber = getCurrentBuilder().getPhoneNumberWithPrefix();
        activatePhoneNumber.setText(getContext().getString(R.string.registration_account_activation_information, phoneNumber));
        SmsRetrieverClient client = SmsRetriever.getClient(getContext());
        client.startSmsUserConsent("Service App");
        IntentFilter intentFilter = new IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION);
        ContextCompat.registerReceiver(getContext(), smsReceiver, intentFilter, ContextCompat.RECEIVER_EXPORTED);
    }

    private String getActivationCode() {
        String c1 = code1.getText().toString();
        String c2 = code2.getText().toString();
        String c3 = code3.getText().toString();
        String c4 = code4.getText().toString();
        String c5 = code5.getText().toString();
        String c6 = code6.getText().toString();
        return (c1 + c2 + c3 + c4 + c5 + c6).trim();
    }

    public void onMessageReceived(String message) {
        char[] code = message.split(":")[1].trim().toCharArray();
        code1.setText(String.valueOf(code[0]));
        code2.setText(String.valueOf(code[1]));
        code3.setText(String.valueOf(code[2]));
        code4.setText(String.valueOf(code[3]));
        code5.setText(String.valueOf(code[4]));
        code6.setText(String.valueOf(code[5]));
        onNextButtonClick();
    }

    void onNextButtonClick() {
        Validator validator = validateInput();
        if (validator.isValid()) {
            final String codeVerification = getActivationCode();
            sendVerificationCode(codeVerification);
        } else {
            ValidationErrorDialogHelper.show(getContext(), validator);
        }
    }

    private Validator validateInput() {
        final Validator validator = new Validator();
        if (getActivationCode().length() != VERIFICATION_CODE_LENGHT) {
            validator.addError(getContext().getString(R.string.phone_activate_wrong_code));
        }
        return validator;
    }

    private void sendVerificationCode(String codeVerification) {
        String phoneNumber = getCurrentBuilder().getPhoneNumberWithPrefix();

        checkVerificationCodeSubscribtion = registerApi.getUserDataByPhone(phoneNumber, codeVerification)
                .compose(Rx.applySchedulers())
                .compose(ProgressDialog.create(getContext()))
                .subscribe(
                        response -> {
                            Timber.d(response.toString());
                            PersonalData personalData = new PersonalData(response.name, response.lastName, response.email);
                            getCurrentBuilder().setPersonalData(personalData);

                            AccountType accountType = AccountType.createAccountTypeFromInt(response.accountType);
                            getCurrentBuilder().setAccountTypeName(new AccountTypeName(accountType, response.accountName));

                            getCurrentBuilder().setVerificationCode(codeVerification);

                            List<SimpleServiceModel> services = new ArrayList<>();

                            for (ServiceModel service : response.providedServices) {
                                services.add(new SimpleServiceModel(service.serviceId));
                            }

                            getCurrentBuilder().companyInfo = new CompanyInfo(
                                    response.companyName,
                                    response.nip,
                                    response.email,
                                    response.companyDescription,
                                    response.companyBusinessArea,
                                    services,
                                    response.getAddress()
                            );

                            getCurrentBuilder().setUserName(response.userName);
                            getCurrentBuilder().accessToken = response.accessToken;

                            getCurrentBuilder().createdByPropertyManager = true;
                            pageViewListener.showNextPage();
                        }, throwable -> {
                            getCurrentBuilder().createdByPropertyManager = false;
                            if (throwable instanceof EOFException) {
                                getCurrentBuilder().setVerificationCode(codeVerification);
                                pageViewListener.showNextPage();
                            } else
                                ApiErrorDialogHelper.show(getContext(), throwable);
                        }
                );
    }

    @Override
    protected void onDetached() {
        Rx.safeUnsubscribe(checkVerificationCodeSubscribtion);
        getContext().unregisterReceiver(smsReceiver);
    }

    @Override
    protected int titleResource() {
        return R.string.registration_account_activation_title;
    }

    @Override
    protected int layoutResource() {
        return R.layout.register_activate_phone;
    }
}
