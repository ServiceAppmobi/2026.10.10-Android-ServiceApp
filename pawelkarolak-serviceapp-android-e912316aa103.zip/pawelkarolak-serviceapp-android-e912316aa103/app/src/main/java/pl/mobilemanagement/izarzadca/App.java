package pl.mobilemanagement.izarzadca;

import androidx.multidex.MultiDexApplication;

import com.newrelic.agent.android.NewRelic;
import com.stripe.android.PaymentConfiguration;

import io.intercom.android.sdk.Intercom;
import pl.mobilemanagement.izarzadca.common.di.ApplicationComponent;
import pl.mobilemanagement.izarzadca.common.di.ApplicationModule;
import pl.mobilemanagement.izarzadca.common.di.DaggerApplicationComponent;
import pl.mobilemanagement.izarzadca.common.di.api.ApiModule;
import timber.log.Timber;

public class App extends MultiDexApplication {

    public static ApplicationComponent component;

    @Override
    public void onCreate() {
        super.onCreate();
        component = DaggerApplicationComponent.builder()
                .applicationModule(new ApplicationModule(this))
                .apiModule(new ApiModule())
                .build();

        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        }

        PaymentConfiguration.init(getApplicationContext(), BuildConfig.STRIPE_PUBLISHABLE_KEY);

        NewRelic.withApplicationToken("eu01xx9ac06e6ec409cba4df4c01e26333feb91235-NRMA")
                .withLoggingEnabled(true)
                .withCrashReportingEnabled(true)
                .start(this);

        MyFirebaseMessagingService.createNotificationChannel(this);

        Intercom.initialize(this, "android_sdk-d096484e3f57a5f3445bbf47e8a2bc5ab6169953", "p47trxpc");
    }

}
