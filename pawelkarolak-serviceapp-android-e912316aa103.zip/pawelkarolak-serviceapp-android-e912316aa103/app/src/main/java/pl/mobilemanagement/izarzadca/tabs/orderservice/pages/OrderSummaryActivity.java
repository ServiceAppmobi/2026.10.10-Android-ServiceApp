package pl.mobilemanagement.izarzadca.tabs.orderservice.pages;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.List;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.databinding.OrderServiceSummaryBinding;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.TabToMove;
import pl.mobilemanagement.izarzadca.tabs.orderservice.model.OrderSummary;
import pl.mobilemanagement.izarzadca.tools.DateUtil;

public class OrderSummaryActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String SUMMARY_KEY = "SUMMARY_KEY";

    private OrderServiceSummaryBinding binding;

    public static void startForResult(Activity activity, OrderSummary summary) {
        Intent intent = getIntent(activity, summary);
        activity.startActivityForResult(intent, MainActivity.TAB_TO_SELECT);
    }

    private static Intent getIntent(Context context, OrderSummary summary) {
        Intent intent = new Intent(context, OrderSummaryActivity.class);
        intent.putExtra(SUMMARY_KEY, summary);
        return intent;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = OrderServiceSummaryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final OrderSummary orderSummary = getSummaryOrder();
        updateSummaryData(orderSummary);

        binding.orderNextServiceBtn.setOnClickListener(this);
        binding.myOrdersBtn.setOnClickListener(this);
        binding.backArrow.setOnClickListener(this);
    }

    private void updateSummaryData(OrderSummary orderSummary) {
        final String title = DateUtil.getFormattedDate(this, orderSummary.startDateTime, orderSummary.endDateTime);
        binding.dateTitle.setText(title);

        binding.serviceGroup.setText(orderSummary.serviceGroupName);
        binding.serviceType.setText(orderSummary.serviceTypeName);
        binding.serviceProvidersNames.setText(TextUtils.join(", ", orderSummary.providersName));

        binding.noAttachments.setVisibility(orderSummary.fileList.isEmpty() ? View.VISIBLE : View.GONE);
        bindPhotosToView(orderSummary.fileList);
    }

    private void bindPhotosToView(List<File> fileList) {
        for (int i = 0; i < fileList.size(); i++) {
            File file = fileList.get(i);
            switch (i) {
                case 0:
                    bindPhotoFile(file, binding.firstOrderPhoto);
                    break;
                case 1:
                    bindPhotoFile(file, binding.secondOrderPhoto);
                    break;
                default:
                    bindPhotoFile(file, binding.thirdOrderPhoto);
                    break;
            }
        }
    }

    private void bindPhotoFile(File file, ImageView iv) {
        iv.setVisibility(View.VISIBLE);
        Glide.with(iv.getContext()).load(Uri.fromFile(file)).into(iv);
    }

    private OrderSummary getSummaryOrder() {
        return (OrderSummary) getIntent().getSerializableExtra(SUMMARY_KEY);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.orderNextServiceBtn) {
            setResult(RESULT_OK, new Intent().putExtra(MainActivity.EXTRA_TAB_TO_OPEN, TabToMove.ORDER_SERVICE));
        } else if (id == R.id.myOrdersBtn) {
            setResult(RESULT_OK, new Intent().putExtra(MainActivity.EXTRA_TAB_TO_OPEN, TabToMove.MY_ORDERS));
        }
        finish();
    }
}
