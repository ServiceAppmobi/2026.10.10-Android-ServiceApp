package pl.mobilemanagement.izarzadca.common.di;

import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;

import javax.inject.Singleton;

import dagger.Component;
import pl.mobilemanagement.izarzadca.common.badge.MyOrderBadge;
import pl.mobilemanagement.izarzadca.common.badge.di.BadgeModule;
import pl.mobilemanagement.izarzadca.common.di.api.ApiModule;
import pl.mobilemanagement.izarzadca.common.di.api.Auth;
import pl.mobilemanagement.izarzadca.common.di.api.AuthTokenModule;
import pl.mobilemanagement.izarzadca.common.di.api.NetworkModule;
import pl.mobilemanagement.izarzadca.common.di.api.OkHttpInterceptorsModule;
import pl.mobilemanagement.izarzadca.common.di.api.SocialNetworkModule;
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi;
import pl.mobilemanagement.izarzadca.common.invite.InviteFriendActivity;
import pl.mobilemanagement.izarzadca.common.invite.di.ContactModule;
import pl.mobilemanagement.izarzadca.common.notification.api.NotificationRegisterService;
import pl.mobilemanagement.izarzadca.common.user.LogoutService;
import pl.mobilemanagement.izarzadca.common.user.profile.UserService;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.start_screen.LoginOrRegisterActivity;
import pl.mobilemanagement.izarzadca.start_screen.SplashScreenActivity;
import pl.mobilemanagement.izarzadca.start_screen.login.LoginActivity;
import pl.mobilemanagement.izarzadca.start_screen.login.LoginViewModel;
import pl.mobilemanagement.izarzadca.start_screen.login.di.LoginModule;
import pl.mobilemanagement.izarzadca.start_screen.login.di.LoginServiceApi;
import pl.mobilemanagement.izarzadca.start_screen.login_or_register.SocialApiService;
import pl.mobilemanagement.izarzadca.start_screen.register.RegisterActivity;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.SelectCountryDialog;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.CompanyDataView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneactivate.PhoneActivateView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneregister.PhoneNumberView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.UserDataView;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.file_manager.FileManagerFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.MyOrdersTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.MyServicesTabFragment;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.DifferentAddressActivity;
import pl.mobilemanagement.izarzadca.tabs.profile.ProfileTabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.Bills;
import pl.mobilemanagement.izarzadca.tabs.profile.community.Documents;
import pl.mobilemanagement.izarzadca.tabs.profile.community.FailureReport;
import pl.mobilemanagement.izarzadca.tabs.profile.community.Messages;
import pl.mobilemanagement.izarzadca.tabs.profile.community.ProfileCommunity;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.HomeApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.HomeTabFragment;
import retrofit2.Retrofit;

@Singleton
@Component(modules = {
        ApplicationModule.class,
        NetworkModule.class,
        OkHttpInterceptorsModule.class,
        ApiModule.class,
        LoginModule.class,
        AuthTokenModule.class,
        ContactModule.class,
        BadgeModule.class,
        SocialNetworkModule.class,
        ViewModelModule.class
})
public interface ApplicationComponent {

    Retrofit provideRetrofit();

    ProfileApi provideProfileApi();

    UnauthorizedApi provideUnauthorizedApi();

    @Auth
    Retrofit provideAuthRetrofit();

    TokenDataSource provideTokenDataSource();

    AccountTypeDataSource provideAccountTypeDataSource();

    UserService provideUserService();

    LogoutService provideLogoutService();

    NotificationRegisterService provideNotificationRegisterService();

    LoginManager provideLoginManager();

    GoogleSignInClient provideGoogleSignInClient();

    HomeApi provideHomeApi();

    SocialApiService provideSocialApiService();

    LoginServiceApi provideLoginServiceApi();
    MyOrderBadge f();

    void inject(PhoneNumberView accountDataView);

    void inject(PhoneActivateView phoneActivateView);

    void inject(UserDataView userDataView);

    void inject(CompanyDataView companyDataView);

    void inject(SplashScreenActivity splashScreenActivity);

    void inject(MainActivity mainActivity);

    void inject(MyServicesTabFragment myServicesTabFragment);

    void inject(ProfileCommunity ProfileCommunity);

    void inject(Bills bills);

    void inject(Documents documents);

    void inject(InviteFriendActivity inviteFriendActivity);

//    void inject(PromoteServiceActivity promoteServiceActivity);

    void inject(MyOrdersTabFragment myOrdersTabFragment);

    void inject(Messages messages);

    //void inject(FailureReport messages);

    void inject(LoginActivity loginActivity);

    void inject(ProfileTabFragment profileTabFragment);

    void inject(HomeTabFragment homeTabFragment);

    void inject(SelectCountryDialog selectCountryDialog);

    void inject(RegisterActivity registerActivity);

    void inject(DifferentAddressActivity differentAddressActivity);
    void inject(FileManagerFragment fileManagerFragment);
}
