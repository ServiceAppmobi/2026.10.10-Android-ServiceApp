package pl.mobilemanagement.izarzadca.tools.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import pl.mobilemanagement.izarzadca.R;


public class EditFrame extends LinearLayout {

    private final EditText editText;
    private final ImageView icon;

    public EditFrame(Context context, AttributeSet attrs) {
        super(context, attrs);
        setGravity(Gravity.CENTER);
        inflate(getContext(), R.layout.merge_edit_frame, this);
        editText = (EditText) findViewById(R.id.edit_text);
        icon = (ImageView) findViewById(R.id.iv_icon);
        initDataFromAttrs(context, attrs);
    }

    private void initDataFromAttrs(Context context, AttributeSet attrs) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.EditFrame);
        Drawable rightIcon = a.getDrawable(R.styleable.EditFrame_right_icon);
        String hint = a.getString(R.styleable.EditFrame_edit_hint);
        setRightIcon(rightIcon);
        setHint(hint);
        a.recycle();
    }

    private void setHint(String hint) {
        editText.setHint(hint);
    }

    private void setRightIcon(Drawable rightIcon) {
        if (rightIcon == null) {
            icon.setVisibility(GONE);
        } else {
            icon.setVisibility(VISIBLE);
        }
        icon.setImageDrawable(rightIcon);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

    }

}
