package pl.mobilemanagement.izarzadca.tabs.profile.creditcard.create.view;

import static com.jakewharton.rxbinding.widget.RxTextView.textChanges;
import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.Calendar;
import java.util.regex.Pattern;
import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.databinding.ActivityAddCardBinding;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tabs.profile.creditcard.create.model.CreditCardApiModel;
import pl.mobilemanagement.izarzadca.tabs.profile.di.DaggerProfileComponent;
import pl.mobilemanagement.izarzadca.tools.EditTextHelper;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.functions.Func6;

public class AddCreditCardActivity extends AppCompatActivity {
  private static final String USER_NAME = "USER_NAME_KEY";

  private static final String USER_SURNAME = "USER_SURNAME_KEY";

  public Subscription subscription;

  public Subscription addCardSubscription;

  @Inject
  ProfileApi profileApi;

  Toolbar toolbar;
  EditText cardNumber;
  EditText creditCardMM;
  EditText creditCardRR;
  EditText creditCardCVV;
  EditText name;
  EditText surname;
  View addCreditCardButton;

  public static void start(Context context, String name, String surname) {
    final Intent intent = new Intent(context, AddCreditCardActivity.class);
    intent.putExtra(USER_NAME, name);
    intent.putExtra(USER_SURNAME, surname);
    context.startActivity(intent);
  }

  @Override
  protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    DaggerProfileComponent.builder().applicationComponent(App.component).build().inject(this);

    ActivityAddCardBinding binding = ActivityAddCardBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());

    toolbar = binding.toolbar.toolbarWhiteArrow;
    cardNumber = binding.cardNumber;
    creditCardMM = binding.creditCardMM;
    creditCardRR = binding.creditCardRR;
    creditCardCVV = binding.creditCardCVV;
    name = binding.name;
    surname = binding.surname;
    addCreditCardButton = binding.addCreditCardButton;

    addCreditCardButton.setOnClickListener(v -> onClick());

    setSupportActionBar(toolbar);
    cardNumber.addTextChangedListener(EditTextHelper.getCreditCardTextWatcher());
    subscription = observeTextChange()
      .subscribe(isValid -> {
        addCreditCardButton.setEnabled(isValid);
      });

    fillUserDataInfo();
  }

  private void fillUserDataInfo() {
    final Intent intent = getIntent();
    name.setText(intent.getStringExtra(USER_NAME));
    surname.setText(intent.getStringExtra(USER_SURNAME));
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
    Rx.safeUnsubscribe(subscription, addCardSubscription);
  }

  private Observable<Boolean> observeTextChange() {
    return Observable
      .combineLatest(textChanges(cardNumber), textChanges(creditCardMM), textChanges(creditCardRR), textChanges(creditCardCVV), textChanges(name), textChanges(surname),
        validatorFunc());
  }

  private Func6<CharSequence, CharSequence, CharSequence, CharSequence, CharSequence, CharSequence, Boolean> validatorFunc() {
    return (cardNumber, cardMonth, cardYear, cardCvv, name, surname) -> (
      !isAnyEmpty(cardNumber, cardMonth, cardYear, cardCvv, name, surname) &&
        isValidCreditCardNumber(cardNumber) &&
        isValidCVV(cardCvv) &&
        isValidMonthYear(cardMonth, cardYear));
  }

  private boolean isValidCVV(CharSequence cardNumber) {
    return trimmedTextIsLength(cardNumber, 3);
  }

  private boolean isValidCreditCardNumber(CharSequence formattedCreditCard) {
    final String cardNumberString = formattedCreditCard.toString().replace(" ", "");
    return trimmedTextIsLength(cardNumberString, 16) && CardType.detect(cardNumberString) != CardType.UNKNOWN;
  }

  private boolean isValidMonthYear(CharSequence month, CharSequence year) {
    Calendar current = Calendar.getInstance();
    int monthInt = Integer.parseInt(month.toString()) - 1;
    int yearInt = Integer.parseInt(year.toString() + 2000);
    if (monthInt > 11) {
      return false;
    }
    Calendar cardCalendar = parseToCalendar(monthInt, yearInt);
    return current.before(cardCalendar);
  }

  private Calendar parseToCalendar(int month, int year) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(year, month, 0, 0, 0, 0);
    return calendar;
  }

  private boolean isAnyEmpty(CharSequence... charSequence) {
    for (CharSequence sequence : charSequence) {
      if (trimmedTextIsLength(sequence, 0)) {
        return true;
      }
    }
    return false;
  }

  private boolean trimmedTextIsLength(CharSequence sequence, int expectedLenght) {
    return sequence.toString().trim().length() == expectedLenght;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      onBackPressed();
    }
    return super.onOptionsItemSelected(item);
  }

  public void onClick() {
    String creditCardNumber = getCreditCardNumber();
    CardType cardType = CardType.detect(creditCardNumber);
    final CreditCardApiModel creditCardToCreate = new CreditCardApiModel(cardType.getId(), getFullName(), creditCardNumber, getMonth(), getYear(), getCVV());
    addCardSubscription = profileApi.registerCreditCard(creditCardToCreate)
      .compose(Rx.applySchedulers())
      .compose(ProgressDialog.create(this))
      .subscribe(aVoid -> finish(), throwable -> ApiErrorDialogHelper.show(this, throwable));
  }

  private String getCreditCardNumber() {
    return getTrimmedText(cardNumber).replace(" ", "");
  }

  private String getCVV() {
    return getTrimmedText(creditCardCVV);
  }

  private int getMonth() {
    return Integer.parseInt(getTrimmedText(creditCardMM));
  }

  private String getFullName() {
    return getTrimmedText(name) + getTrimmedText(surname);
  }

  public int getYear() {
    return Integer.parseInt(getTrimmedText(creditCardRR));
  }

  public enum CardType {
    UNKNOWN,
    VISA("^4[0-9]{12}(?:[0-9]{3})?$", 936710000),
    MASTERCARD("^5[1-5][0-9]{14}$", 936710002),
    AMERICAN_EXPRESS("^3[47][0-9]{13}$", 936710001),
    DISCOVER("^6(?:011|5[0-9]{2})[0-9]{12}$", 936710003);

    private Pattern pattern;

    private int id;

    public static CardType detect(String cardNumber) {

      for (CardType cardType : CardType.values()) {
        if (null == cardType.pattern) {
          continue;
        }
        if (cardType.pattern.matcher(cardNumber).matches()) {
          return cardType;
        }
      }

      return UNKNOWN;
    }

    CardType() {
    }

    CardType(String pattern, int id) {
      this.pattern = Pattern.compile(pattern);
      this.id = id;
    }

    public int getId() {
      return id;
    }
  }
}
