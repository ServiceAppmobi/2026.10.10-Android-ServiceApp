package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.photo;

import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.io.File;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.databinding.OrderServiceAttachPhotoBinding;
import pl.mobilemanagement.izarzadca.tabs.orderservice.OrderBuilder;
import pl.mobilemanagement.izarzadca.tabs.orderservice.PhotosBag;
import pl.mobilemanagement.izarzadca.tabs.orderservice.di.DaggerOrderComponent;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.BaseView;

public class AttachPhotoView extends BaseView implements View.OnClickListener {

    public static final int MAX_PHONE_SIZE = 1024;

    public OrderServiceAttachPhotoBinding binding;

    public AttachPhotoView(Context context) {
        super(context);
        DaggerOrderComponent.builder().applicationComponent(App.component).build().inject(this);
    }

    private static ImageView getPhotoViewByPos(AttachPhotoView attachPhotoView, int imagePos) {
        final ImageView iv;
        switch (imagePos) {
            case 1:
                iv = attachPhotoView.binding.firstOrderPhoto;
                break;
            case 2:
                iv = attachPhotoView.binding.secondOrderPhoto;
                break;
            case 3:
                iv = attachPhotoView.binding.thirdOrderPhoto;
                break;
            default:
                throw new IllegalArgumentException();
        }
        return iv;
    }

    private ImageView getPhotoRemoveBtnByPos(int imagePos) {
        final ImageView iv;
        switch (imagePos) {
            case 1:
                iv = binding.removeFirstPhoto;
                break;
            case 2:
                iv = binding.removeSecondPhoto;
                break;
            case 3:
                iv = binding.removeThirdPhoto;
                break;
            default:
                throw new IllegalArgumentException();
        }
        return iv;
    }

    @Override
    public void onNext() {
        super.onNext();
        pageViewListener.showNextPage();
    }

    @Override
    protected int titleResource() {
        return R.string.order_service_attach_photo;
    }

    @Override
    protected int layoutResource() {
        return R.layout.order_service_attach_photo;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.firstOrderPhoto) choosePhoto(1);
        else if (id == R.id.secondOrderPhoto) choosePhoto(2);
        else if (id == R.id.thirdOrderPhoto) choosePhoto(3);
        else if (id == R.id.removeFirstPhoto) removePhoto(binding.firstOrderPhoto, v);
        else if (id == R.id.removeSecondPhoto) removePhoto(binding.secondOrderPhoto, v);
        else if (id == R.id.removeThirdPhoto) removePhoto(binding.thirdOrderPhoto, v);
    }

    private void removePhoto(ImageView photo, View btnRemove) {
        if (binding.firstOrderPhoto == photo) {
            pageViewListener.getOrderBuilder().getPhotos().removePhotoByPos(1);
        } else if (binding.secondOrderPhoto == photo) {
            pageViewListener.getOrderBuilder().getPhotos().removePhotoByPos(2);
        } else if (binding.thirdOrderPhoto == photo) {
            pageViewListener.getOrderBuilder().getPhotos().removePhotoByPos(3);
        }
        photo.setImageResource(R.drawable.add_photo_placeholder);
        btnRemove.setVisibility(GONE);
    }

    @Override
    protected void onAttached() {
        binding = OrderServiceAttachPhotoBinding.bind(getChildAt(0));

        binding.firstOrderPhoto.setOnClickListener(this);
        binding.secondOrderPhoto.setOnClickListener(this);
        binding.thirdOrderPhoto.setOnClickListener(this);

        binding.removeFirstPhoto.setOnClickListener(this);
        binding.removeSecondPhoto.setOnClickListener(this);
        binding.removeThirdPhoto.setOnClickListener(this);

        restorePhotos();
    }

    private void restorePhotos() {
        final OrderBuilder orderBuilder = pageViewListener.getOrderBuilder();
        final PhotosBag photos = orderBuilder.getPhotos();
        loadFileIfNotNull(binding.firstOrderPhoto, binding.removeFirstPhoto, photos.firstPhoto);
        loadFileIfNotNull(binding.secondOrderPhoto, binding.removeSecondPhoto, photos.secondPhoto);
        loadFileIfNotNull(binding.thirdOrderPhoto, binding.removeThirdPhoto, photos.thirdPhoto);
    }

    private void loadFileIfNotNull(ImageView iv, ImageView btnRemove, String fileUri) {
        if (fileUri != null) {
            Glide.with(iv.getContext()).load(fileUri).into(iv);
        }
        btnRemove.setVisibility(fileUri != null ? VISIBLE : GONE);
    }

    private void choosePhoto(int imagePos) {
        new AlertDialog.Builder(getContext())
                .setTitle(R.string.select_photo_source)
                .setItems(R.array.photo_sources, (dialog, which) -> {
                    if (which == 0)
                        launchCamera(imagePos);
                    else if (which == 1)
                        launchGallery(imagePos);
                })
                .show();
    }

    private int imagePos = 0;

    private void launchGallery(int imagePos) {
        this.imagePos = imagePos;
        pageViewListener.dispatchChooseFromGalleryIntent();
    }

    private void launchCamera(int imagePos) {
        this.imagePos = imagePos;
        pageViewListener.dispatchTakePictureIntent();
    }

    public void loadPhoto(String uriPath, AttachPhotoView targetUI, OrderBuilder orderBuilder) {
        final PhotosBag photos = orderBuilder.getPhotos();
        photos.setPhoto(imagePos, uriPath);
        final ImageView photo = getPhotoViewByPos(targetUI, imagePos);
        Glide.with(getContext())
                .load(uriPath)
                .into(photo);
        getPhotoRemoveBtnByPos(imagePos).setVisibility(VISIBLE);
    }

}
