package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.impl.opinion;

//
//class CompanyOpinionAdapter extends RowAdapter<ProviderOpinionsApiModel, CompanyOpinionAdapter.VH> {
//    private final SelectedCompanyProviderChangedListener listener;
//    private final HashSet<ServiceProvider> selectedProviders = new HashSet<>();
//
//    public CompanyOpinionAdapter(SelectedCompanyProviderChangedListener listener) {
//        this.listener = listener;
//    }
//
//    @Override
//    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
//        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.provider_row, parent, false));
//    }
//
//    @Override
//    public void onBindViewHolder(VH holder, int position) {
//        holder.bind(getItem(position));
//
//    }
//
//    @Override
//    public void setDataList(List<ServiceProvider> data) {
//        super.setDataList(data);
//        updateSelectedProviders();
//    }
//
//    @Override
//    public long getItemId(int position) {
//        return getItem(position).id.hashCode();
//    }
//
//    private boolean isProviderSelected(ServiceProvider serviceProvider) {
//        return selectedProviders.contains(serviceProvider);
//    }
//
//    private void updateSelectedProviders() {
//        listener.onSelectedProvidersChange(selectedProviders.isEmpty());
//    }
//
//    class VH extends RecyclerView.ViewHolder {
//
//    }
