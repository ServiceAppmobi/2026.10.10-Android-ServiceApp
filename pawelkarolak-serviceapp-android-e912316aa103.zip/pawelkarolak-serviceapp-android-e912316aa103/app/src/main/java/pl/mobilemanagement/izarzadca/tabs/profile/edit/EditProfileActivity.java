package pl.mobilemanagement.izarzadca.tabs.profile.edit;

import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.flexbox.FlexboxLayout;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.SpinnerTextView;
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi;
import pl.mobilemanagement.izarzadca.common.model.api.DistanceArea;
import pl.mobilemanagement.izarzadca.common.model.entity.Country;
import pl.mobilemanagement.izarzadca.common.user.AccountType;
import pl.mobilemanagement.izarzadca.common.user.profile.UserProfile;
import pl.mobilemanagement.izarzadca.common.user.profile.UserService;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.databinding.ActivityModifyProfileBinding;
import pl.mobilemanagement.izarzadca.databinding.ActivityModifyProfileCompanyDataBinding;
import pl.mobilemanagement.izarzadca.databinding.ActivityModifyProfileUserDataBinding;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.ServiceSelectActivity;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.ServiceItem;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.AddressController;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.CompanyInfoController;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.PersonalInfoController;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.TabToMove;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tabs.profile.di.DaggerProfileComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.edit.model.UpdateProviderApiModel;
import pl.mobilemanagement.izarzadca.tabs.profile.edit.model.UpdateUserApiModel;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;

public class EditProfileActivity extends AppCompatActivity {
    public Subscription subscription;

    public Subscription updateSubscription;

    @Inject
    ProfileApi profileApi;

    @Inject
    UserService userService;

    @Inject
    AccountTypeDataSource accountTypeDataSource;

    @Inject
    UnauthorizedApi unauthorizedApi;

    Toolbar toolbar;
    EditText name;
    EditText surname;
    EditText address;
    EditText postalCode;
    EditText city;
    EditText flat;
    EditText email;
    EditText phoneNumber;
    SpinnerTextView accountTypeSpinner;
    TextInputEditText companyName;
    TextInputEditText companyNIP;
    TextInputEditText companyDescription;
    SpinnerTextView companyArea;
    TextView companyServices;
    LinearLayout companyFrame;
    FlexboxLayout servicesFrame;

    private AddressController addressController;

    private PersonalInfoController personalController;

    private CompanyInfoController companyController;

    private Country country;

    public static void start(Context context) {
        context.startActivity(new Intent(context, EditProfileActivity.class));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerProfileComponent.builder().applicationComponent(App.component).build().inject(this);

        ActivityModifyProfileBinding binding = ActivityModifyProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ActivityModifyProfileUserDataBinding userData = ActivityModifyProfileUserDataBinding.bind(binding.getRoot());
        ActivityModifyProfileCompanyDataBinding companyData = ActivityModifyProfileCompanyDataBinding.bind(binding.getRoot());

        toolbar = binding.toolbar.toolbarWhiteArrow;
        name = userData.name;
        surname = userData.surname;
        address = userData.address;
        postalCode = userData.postalCode;
        city = userData.city;
        flat = userData.flat;
        email = userData.email;
        phoneNumber = userData.phoneNumber;
        accountTypeSpinner = userData.accountTypeSpinner;
        companyName = companyData.companyName;
        companyNIP = companyData.companyNIP;
        companyDescription = companyData.companyDescription;
        companyArea = companyData.companyArea;
        companyServices = companyData.tlCompanyServices;
        companyFrame = companyData.companyFrame;
        servicesFrame = companyData.servicesFrame;

        setSupportActionBar(toolbar);
        subscription = userService.getProfilePreferOnlyCache()
                .compose(Rx.applySchedulers())
                .subscribe(this::updateProfileData);
        addressController = new AddressController(city, postalCode, address, flat);
        personalController = new PersonalInfoController(unauthorizedApi, surname, email, name, accountTypeSpinner);
        personalController.onCreate(accountType -> companyFrame.setVisibility(accountType.type.isProvider() ? View.VISIBLE : View.GONE));
        companyController = new CompanyInfoController(unauthorizedApi, companyName, companyNIP, companyServices, this, companyDescription, companyArea, servicesFrame);
        companyController.onCreate();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Rx.safeUnsubscribe(subscription, updateSubscription);
        personalController.onDestroy();
        companyController.onDestroy();
    }

    private void updateProfileData(UserProfile userProfile) {
        name.setText(userProfile.name);
        surname.setText(userProfile.lastName);
        address.setText(userProfile.street);
        flat.setText(userProfile.number);
        postalCode.setText(userProfile.postalCode);
        city.setText(userProfile.city);
        email.setText(userProfile.email);
        phoneNumber.setText(userProfile.phone);
        country = new Country(userProfile.countryId, userProfile.country);
        personalController.restoreAccountType(userProfile.accountType, userProfile.accountName);
        if (userProfile.isProvider()) {
            companyNIP.setText(userProfile.nip);
            companyArea.setText(userProfile.companyBusinessArea);
            companyDescription.setText(userProfile.companyDescription);
            companyName.setText(userProfile.companyName);
            final DistanceArea distanceArea = new DistanceArea(userProfile.companyBusinessAreaId, userProfile.companyBusinessArea);
            companyController.restore(distanceArea, userProfile.providedServices);
            companyArea.setText(userProfile.companyBusinessArea);
        } else {
            companyFrame.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        } else if (item.getItemId() == R.id.action_save_profile) {
            onSaveProfileClick();
        }
        return super.onOptionsItemSelected(item);
    }

    private UpdateProviderApiModel createProviderUserApiModel(UpdateUserApiModel updateUserApiModel) {
        final String companyNameText = companyController.getCompanyName();
        final String nipText = companyController.getCompanyNIP();
        final String companyDescriptionText = companyController.getDescription();
        return new UpdateProviderApiModel(updateUserApiModel, companyNameText, nipText,
                companyDescriptionText, Long.parseLong(companyController.getSelectedDistanceArea()), companyController.getSelectedSericeTypes());
    }

    private UpdateUserApiModel createUserApiModel() {
        final String firstName = personalController.getUserName();
        final String secondName = personalController.getSurname();
        final String emailText = personalController.getEmail();
        final String streetText = addressController.getStreet();
        final String postalText = addressController.getPostalCode();
        final String flatText = addressController.getFlat();
        final String cityText = addressController.getTown();
        final String phoneText = getTrimmedText(phoneNumber);
        return new UpdateUserApiModel(firstName, secondName, emailText, streetText, flatText,
                postalText, cityText, country.id, phoneText);
    }

    private void onSaveProfileClick() {
        final Validator validator = createValidator();
        if (validator.isValid()) {
            final AccountType selectedType = personalController.getSelectedAccountTypeName().type;
            UpdateUserApiModel userApiModel = createUserApiModel();
            updateSubscription = getUpdateUserObservable(userApiModel)
                    .compose(Rx.applySchedulers())
                    .compose(ProgressDialog.create(this))
                    .subscribe(aVoid -> {
                        if (selectedType != accountTypeDataSource.getAccountType()) {
                            accountTypeDataSource.saveAccountType(selectedType);
                        }
                        MainActivity.startActivity(this, TabToMove.PROFILE);
                    }, throwable -> ApiErrorDialogHelper.show(this, throwable));
        } else {
            ValidationErrorDialogHelper.show(this, validator);
        }
    }

    private Observable<Void> getUpdateUserObservable(UpdateUserApiModel userApiModel) {
        if (personalController.isSelectedProvider()) {
            return profileApi.updateProviderUserData(createProviderUserApiModel(userApiModel));
        }
        return profileApi.updateUserData(userApiModel);
    }

    private Validator createValidator() {
        Validator validator = new Validator();
        validator.validateWith(personalController.validateInput());
        validator.validateWith(addressController.validateInput());
        if (personalController.isSelectedProvider()) {
            validator.validateWith(companyController.validateInput());
        }
        return validator;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_profile, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == ServiceSelectActivity.REQ_SERVICES_RESULT && resultCode == Activity.RESULT_OK && data != null) {
            Parcelable[] resultData = data.getParcelableArrayExtra(ServiceSelectActivity.ARG_SERVICES);
            ArrayList<ServiceItem> serviceItems = new ArrayList<>();
            for(Parcelable result : resultData) {
                serviceItems.add((ServiceItem)result);
            }
            companyController.setSelectedTypeServices(serviceItems);
        }
    }
}
