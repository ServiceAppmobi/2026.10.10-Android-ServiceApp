package pl.mobilemanagement.izarzadca.start_screen.login.di;

import pl.mobilemanagement.izarzadca.common.di.api.UserLoginRequest;
import pl.mobilemanagement.izarzadca.common.model.api.LoginResponse;
import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

public interface LoginServiceApi {
    @POST("Account/Token")
    Observable<LoginResponse> userLogin(@Body UserLoginRequest userLoginRequest);

}
