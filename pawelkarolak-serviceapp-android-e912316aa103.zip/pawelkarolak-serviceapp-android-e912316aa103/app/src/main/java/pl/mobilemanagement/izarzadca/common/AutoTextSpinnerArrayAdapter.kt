package pl.mobilemanagement.izarzadca.common

import android.content.Context
import android.widget.ArrayAdapter
import android.widget.Filter
import pl.mobilemanagement.izarzadca.tools.spinner.SpinnerItem

class AutoTextSpinnerArrayAdapter(
        context: Context,
        values: List<SpinnerItem>,
        val emptyValue: SpinnerItem?,
        val mResource: Int = android.R.layout.simple_list_item_1,
        val fieldId: Int = 0
) : ArrayAdapter<SpinnerItem>(context, mResource, values) {
    val emptyFilter = object : Filter() {

        override fun performFiltering(p0: CharSequence?): FilterResults {
            val results = FilterResults()
            results.values = values
            results.count = values.size
            return results
        }

        override fun publishResults(p0: CharSequence?, p1: FilterResults?) {
            notifyDataSetChanged()
        }
    }

    override fun getFilter(): Filter {
        return emptyFilter
    }
}