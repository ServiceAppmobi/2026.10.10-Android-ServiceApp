package pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model;

import java.util.Date;
import java.util.List;

public class DuringOrderDetailsApiModel {
    public final String number;
    public final String name;
    public final String lastname;
    public final String emial;
    public final String phone;
    public final String issueDescription;
    public final Date startDateTime;
    public final Date endDateTime;
    public final String street;
    public final String postalCode;
    public final String city;
    public final String serviceName;
    public final List<String> photos;

    public DuringOrderDetailsApiModel(String number, String name, String lastname, String emial, String phone, String issueDescription, Date startDateTime, Date endDateTime, String street, String postalCode, String city, String country, String serviceName, List<String> photos, String id) {
        this.number = number;
        this.name = name;
        this.lastname = lastname;
        this.emial = emial;
        this.phone = phone;
        this.issueDescription = issueDescription;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.street = street;
        this.postalCode = postalCode;
        this.city = city;
        this.serviceName = serviceName;
        this.photos = photos;
    }

    public String getFullName() {
        return name + " " + lastname;
    }

    public String getAddress() {
        String address = street;
        if (number != null) {
            address += " " + number;
        }
        return address + " " + city;
    }
}
