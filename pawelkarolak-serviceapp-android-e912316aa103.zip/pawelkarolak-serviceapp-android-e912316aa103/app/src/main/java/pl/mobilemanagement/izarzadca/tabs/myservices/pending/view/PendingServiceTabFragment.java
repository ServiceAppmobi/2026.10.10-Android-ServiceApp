package pl.mobilemanagement.izarzadca.tabs.myservices.pending.view;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.stripe.android.paymentsheet.PaymentSheet;
import com.stripe.android.paymentsheet.PaymentSheetResult;

import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.OrderId;
import pl.mobilemanagement.izarzadca.common.user.profile.OrderAcceptCost;
import pl.mobilemanagement.izarzadca.databinding.RecyclerViewFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.myservices.ServiceDetailsClickListener;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.ProviderOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderDetailsActivity;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderServiceType;
import pl.mobilemanagement.izarzadca.tabs.myservices.di.DaggerMyServicesComponent;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.PendingServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.StripePaymentAnswer;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.StripePaymentInformationModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.StripePaymentMethodsModel;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.model.StripePaymentModel;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.LCE;
import pl.mobilemanagement.izarzadca.tools.Recycler;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.functions.Action1;
import timber.log.Timber;

public class PendingServiceTabFragment extends ServiceFragment<PendingServiceOrder> implements
        LCE<PendingServiceOrder>,
        ServiceDetailsClickListener, ServiceDecisionClickListener, View.OnClickListener {

    public Subscription loadListSubscriber;

    public Subscription loadStripeInformationSubscriber;

    public Subscription loadPaymentInfoSubscriber;

    public Subscription loadPaymentMethodsSubscriber;

    public Subscription payUsingMethodSubscriber;

    public Subscription addUserToStripeSubscriber;

    public Subscription acceptSubscription;

    public Subscription userSubscription;

    public Subscription checkoutSubscription;

    public Subscription rejectSubscription;

    private PaymentSheet paymentSheet;

    @Inject
    ProviderOrdersApi providerOrdersApi;

    @Inject
    ProfileApi profileApi;

    public Observable<List<PendingServiceOrder>> pendingServicesObservable = Observable.defer(this::createPendingServiceObservable).share();

    private EarthlyLoadingDialog earthlyDialog;

    private String selectedOrderId;

    private final Action1<Throwable> onErrorAction = throwable -> {
        FirebaseCrashlytics.getInstance().recordException(throwable);

        FirebaseCrashlytics.getInstance().log(throwable.toString());
        ProgressHelper.safeDismiss(earthlyDialog);
        ApiErrorDialogHelper.show(getContext(), throwable);
    };

    private final PendingServiceAdapter pendingServicesAdapter = new PendingServiceAdapter(this, this);

    private RecyclerViewFrameBinding binding;

    public PendingServiceTabFragment() {
        DaggerMyServicesComponent.builder().applicationComponent(App.component).build().inject(this);
    }

    @Override
    public int getTitleResource() {
        return R.string.my_services_tab_wait;
    }

    @Override
    protected int getLayout() {
        return R.layout.recycler_view_frame;
    }

    private void fetchPendingService() {
        Rx.safeUnsubscribe(loadListSubscriber);
        pendingServicesObservable
                .compose(Rx.applyLCE(this))
                .compose(Rx.applyDataLoader(this))
                .subscribe(orders -> {
                }, Throwable::new);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        paymentSheet = new PaymentSheet(this, this::onPaymentSheetResult);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding = RecyclerViewFrameBinding.bind(view);
        initRecyclerView();
        fetchPendingService();
        binding.btnRefresh.setOnClickListener(this);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Rx.safeUnsubscribe(
                loadListSubscriber,
                acceptSubscription,
                userSubscription,
                checkoutSubscription,
                rejectSubscription,
                addUserToStripeSubscriber,
                loadStripeInformationSubscriber,
                loadPaymentInfoSubscriber,
                loadPaymentMethodsSubscriber,
                payUsingMethodSubscriber
        );
    }

    @NonNull
    private Observable<List<PendingServiceOrder>> createPendingServiceObservable() {
        return providerOrdersApi.getPendingOrders()
                .compose(Rx.applySchedulers());
    }

    private void initRecyclerView() {
        binding.listRecyclerView.setAdapter(pendingServicesAdapter);
    }


    @Override
    public void onRejectClick(String orderId) {
        rejectSubscription = providerOrdersApi.rejectOrder(new OrderId(orderId))
                .compose(Rx.applySchedulers())
                .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager()))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                .subscribe(aVoid -> fetchPendingService(),
                        throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    @Override
    public Observable<List<PendingServiceOrder>> getOrdersObservable() {
        return pendingServicesObservable;
    }

    @Override
    public Observable<ServiceOrder> orderClickObservable() {
        return pendingServicesAdapter.orderObservable();
    }

    @Override
    public void setData(List<PendingServiceOrder> data) {
        pendingServicesAdapter.setDataList(data);
    }

    @Override
    public void showProgressBar() {
        binding.errorGroup.setVisibility(View.GONE);
        if (earthlyDialog != null) {
            ProgressHelper.safeDismiss(earthlyDialog);
        }
        earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager());
        //        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgressBar() {
        ProgressHelper.safeDismiss(earthlyDialog);
        //        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void hideError() {
        binding.errorGroup.setVisibility(View.GONE);
        binding.promoteMyServiceEnquiryButton.setVisibility(View.GONE);
        binding.listRecyclerView.setVisibility(View.VISIBLE);
    }

    @Override
    public void showEmptyListError() {
        binding.errorGroup.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.pending_orders_empty);
        binding.listRecyclerView.setVisibility(View.GONE);

        userSubscription = profileApi.getOrderAcceptCost()
                .compose(Rx.applySchedulers())
                .subscribe(this::showPromoteMyServiceButton,
                        throwable -> Timber.e(throwable.toString()));
    }

    @Override
    public void showConnectionError() {
        binding.errorGroup.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.list_view_connection_error);
    }

    private void showPromoteMyServiceButton(OrderAcceptCost orderAcceptCost) {
        if (orderAcceptCost != null && orderAcceptCost.value) {
            binding.promoteMyServiceEnquiryButton.setVisibility(View.VISIBLE);
            binding.promoteMyServiceEnquiryButton.setOnClickListener(v -> Toast.makeText(requireContext(), "Coming soon" , Toast.LENGTH_SHORT).show());
        } else binding.promoteMyServiceEnquiryButton.setVisibility(View.GONE);
    }

    @Override
    public void onOrderDetailsClick(String orderId, OrderServiceType orderType) {
        OrderDetailsActivity.start(getContext(), orderId, orderType);
    }

    /*@Override
    public void onTargetNotification(Observable<Message> oMessage) {
        oMessage.subscribe(message -> fetchPendingService());
    }

    @Override
    public void onMismatchTargetNotification(Observable<Message> oMessage) {

    }

    @Override
    public boolean matchesTarget(String key) {
        return PushType.parseOf(key) == PushType.PROVIDER_NEW_PENDING;
    }*/

    private void showDetailOrder(String orderId) {
        FirebaseCrashlytics.getInstance().log("Service" + "showDetailOrder()");
        onOrderDetailsClick(orderId, OrderServiceType.DURING);
        fetchPendingService();
        ProgressHelper.safeDismiss(earthlyDialog);
    }

    @Override
    public void onPayClick(String orderId) {
        selectedOrderId = orderId;
        addUserToStripe();
    }

    @Override
    public void onAcceptWithoutPayment(String orderId) {
        onAcceptOrder(orderId);
    }

    private void addUserToStripe() {
        addUserToStripeSubscriber = providerOrdersApi.addUserToStripe()
                .compose(Rx.applySchedulers())
                .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager()))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                .subscribe(aVoid -> getMethodsList(), throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    private void getMethodsList() {
        loadPaymentMethodsSubscriber = providerOrdersApi.getPaymentMethodsList()
                .compose(Rx.applySchedulers())
                .subscribe(this::sendSelectedMethod, throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    private void sendSelectedMethod(StripePaymentMethodsModel stripePaymentMethodsModel) {
        if (!stripePaymentMethodsModel.data.isEmpty()) {
            loadPaymentInfoSubscriber = providerOrdersApi.getPaymentInfo()
                    .compose(Rx.applySchedulers())
                    .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager()))
                    .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                    .subscribe(info -> openStripeDialog(info, stripePaymentMethodsModel.data.get(0).id), throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
        } else getStripePaymentInformation();
    }

    private void openStripeDialog(StripePaymentInformationModel info, String stripePaymentId) {
        new AlertDialog.Builder(getContext())
                .setTitle(getString(R.string.payment_confirmation_title))
                .setMessage(String.format(getString(R.string.payment_confirmation_description), info.currency, info.amount, info.brand, info.last4))
                .setCancelable(true)
                .setPositiveButton(R.string.registration_confirm_password_btn, (dialog, id) -> payUsingPaymentMethod(stripePaymentId))
                .setNeutralButton(getString(R.string.payment_use_another_card), (dialog, id) -> getStripePaymentInformation())
                .show();
    }

    private void payUsingPaymentMethod(String id) {
        payUsingMethodSubscriber = providerOrdersApi.payUsingPaymentMethod(id)
                .compose(Rx.applySchedulers())
                .subscribe(this::isPaymentAccepted, throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    private void isPaymentAccepted(StripePaymentAnswer answer) {
        if (answer != null) {
            if (answer.id != null) {
                onAcceptOrder(selectedOrderId);
                Toast.makeText(requireContext(), getString(R.string.payment_message_ok), Toast.LENGTH_LONG).show();
            } else Toast.makeText(requireContext(), answer.message, Toast.LENGTH_LONG).show();
        }
    }

    private void getStripePaymentInformation() {
        loadStripeInformationSubscriber = providerOrdersApi.getStripePaymentInformation()
                .compose(Rx.applySchedulers())
                .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager()))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                .subscribe(this::presentPaymentSheet, throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    private void presentPaymentSheet(StripePaymentModel paymentModel) {
        paymentSheet.presentWithPaymentIntent(
                paymentModel.clientSecret,
                new PaymentSheet.Configuration(
                        getString(R.string.summary_order),
                        new PaymentSheet.CustomerConfiguration(
                                paymentModel.customerId,
                                paymentModel.ephemeralKey
                        )
                )
        );
    }

    private void onPaymentSheetResult(final PaymentSheetResult paymentSheetResult) {
        if (paymentSheetResult instanceof PaymentSheetResult.Canceled) {
            Toast.makeText(requireContext(), getString(R.string.payment_canceled), Toast.LENGTH_LONG).show();
        } else if (paymentSheetResult instanceof PaymentSheetResult.Failed) {
            Toast.makeText(requireContext(), getString(R.string.payment_failed), Toast.LENGTH_LONG).show();
            Timber.e(((PaymentSheetResult.Failed) paymentSheetResult).getError(), "Got error: ");
        } else if (paymentSheetResult instanceof PaymentSheetResult.Completed) {
            onAcceptOrder(selectedOrderId);
            Toast.makeText(requireContext(), getString(R.string.payment_message_ok), Toast.LENGTH_LONG).show();
        }
    }

    private void onAcceptOrder(String orderId) {
        acceptSubscription = providerOrdersApi.acceptOrder(new OrderId(orderId))
                .compose(Rx.applySchedulers())
                .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager()))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                .subscribe(aVoid -> showDetailOrder(orderId)
                        , throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    @Override
    public void onClick(View v) {
        if (v == binding.btnRefresh)
            fetchPendingService();
    }
}
