package pl.mobilemanagement.izarzadca.start_screen.register;

import pl.mobilemanagement.izarzadca.common.model.api.CustomerRegister;
import pl.mobilemanagement.izarzadca.common.model.entity.AccountTypeName;
import pl.mobilemanagement.izarzadca.common.model.entity.Country;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model.PersonalData;

public interface RegisterViewListener {
    void showNextPage();

    void setPhoneNumberWithPrefix(String phoneNumber);

    String getPhoneNumberWithPrefix();

    void setUserName(String userName);

    void setPassword(String password);

    void setVerificationCode(String codeVerification);

    AccountTypeName getAccountType();

    void setPersonalUserData(PersonalData personalData);

    CustomerRegister createCustomerRegisterModel();

    void setAccountType(AccountTypeName selectedAccountTypeName);

    void setCountry(Country selectedCountry);

    void hideLoader();

    void showLoader();

    void endRegistration();

    PersonalData getPersonalData();
}
