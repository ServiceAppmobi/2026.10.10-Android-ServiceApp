package pl.mobilemanagement.izarzadca.tabs.profile;

import static android.app.Activity.RESULT_OK;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.Group;
import androidx.fragment.app.FragmentActivity;

import com.facebook.AccessToken;
import com.facebook.GraphRequest;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.material.card.MaterialCardView;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;

import de.hdodenhof.circleimageview.CircleImageView;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.invite.InviteFriendActivity;
import pl.mobilemanagement.izarzadca.common.invite.contact.InviteType;
import pl.mobilemanagement.izarzadca.common.user.AccountType;
import pl.mobilemanagement.izarzadca.common.user.LogoutService;
import pl.mobilemanagement.izarzadca.common.user.profile.OrderAcceptCost;
import pl.mobilemanagement.izarzadca.common.user.profile.UserProfile;
import pl.mobilemanagement.izarzadca.common.user.profile.UserService;
import pl.mobilemanagement.izarzadca.databinding.TabProfileBinding;
import pl.mobilemanagement.izarzadca.start_screen.LoginOrRegisterActivity;
import pl.mobilemanagement.izarzadca.tabs.ConfirmRemoveAccountDialog;
import pl.mobilemanagement.izarzadca.tabs.TabFragment;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import pl.mobilemanagement.izarzadca.tabs.profile.api.UploadUserPhoto;
import pl.mobilemanagement.izarzadca.tabs.profile.di.DaggerProfileComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.edit.EditProfileActivity;
import pl.mobilemanagement.izarzadca.tabs.profile.password.ChangePasswordActivity;
import pl.mobilemanagement.izarzadca.tools.Base64Helper;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ErrorHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;
import timber.log.Timber;

public class ProfileTabFragment extends TabFragment {

    @Inject
    UserService userService;

    @Inject
    LogoutService logoutService;

    @Inject
    GoogleSignInClient googleSignInClient;

    @Inject
    LoginManager loginManager;

    CircleImageView profileImage;
    TextView nameSurname;
    TextView address;
    TextView profileCountryName;
    TextView profilePhone;
    TextView profileEmail;
    TextView profileCompanyName;
    TextView profileNip;
    TextView profileAccountServices;
    MaterialCardView userInfo;
    TextView editProfileButton;
    Group companyGroup;

    private Subscription profileSubscription;

    private Subscription logoutSubscription;

    private Subscription deleteAccountSubscription;

    private UserProfile userProfile;

    private Bitmap imageBitmap;

    private EarthlyLoadingDialog earthlyDialog = null;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        DaggerProfileComponent.builder().applicationComponent(App.component).build().inject(this);

        getChildFragmentManager().setFragmentResultListener(
            ConfirmRemoveAccountDialog.RESULT_KEY, this, (key, bundle) -> {
                boolean result = bundle.getBoolean(ConfirmRemoveAccountDialog.RESULT_KEY);
                if(result)
                    deleteAccountSubscription = userService.deleteAccount()
                            .compose(Rx.applySchedulers())
                            .compose(ProgressDialog.create(requireContext()))
                            .subscribe(
                                aVoid -> {
                                    logoutService.clearPersonalData();
                                    LoginOrRegisterActivity.startOnTop(requireContext().getApplicationContext());
                                    requireActivity().finish();
                                },
                                throwable -> {
                                    try {
                                        ApiErrorDialogHelper.show(requireContext(), throwable);
                                    } catch(Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            );
            }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TabProfileBinding binding = TabProfileBinding.bind(view);
        profileImage = binding.profileImage;
        nameSurname = binding.nameValue;
        address = binding.addressValue;
        profileCountryName = binding.profileCountryName;
        profilePhone = binding.profilePhone;
        profileEmail = binding.profileEmail;
        profileCompanyName = binding.profileCompanyName;
        profileNip = binding.profileNip;
        profileAccountServices = binding.profileAccountServices;
        userInfo = binding.userInfo;
        editProfileButton = binding.editProfileButton;
        companyGroup = binding.companyGroup;

        binding.removeAccount.setOnClickListener(v -> onDeleteAccountClick());
        binding.chooseProfileImageButton.setOnClickListener(v -> onChooseProfileImageClick());
        binding.btnLogout.setOnClickListener(v -> onLogoutClick());
        binding.editProfileButton.setOnClickListener(v -> onEditProfileClick());
        binding.btnChangePassword.setOnClickListener(v -> onChangePasswordClick());
        binding.inviteFromSMS.setOnClickListener(v -> onInviteSmsClick());
        binding.inviteFromEmail.setOnClickListener(v -> onInviteEmailClick());

        editProfileButton.setPaintFlags(editProfileButton.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
    }

    void onDeleteAccountClick() {
        ConfirmRemoveAccountDialog dialog = new ConfirmRemoveAccountDialog();
        dialog.show(getChildFragmentManager(), null);
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchUserProfile();
    }

    @Override
    public void onPause() {
        super.onPause();
        Rx.safeUnsubscribe(profileSubscription, logoutSubscription, deleteAccountSubscription);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                Bundle extras = data.getExtras();
                imageBitmap = (Bitmap) extras.get("data");
            } else if (requestCode == 2) {
                Uri selectedImage = data.getData();
                try {
                    imageBitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            String imageString = Base64Helper.bitmapToBase64(imageBitmap);
            profileSubscription = userService.uploadUserImage(new UploadUserPhoto(imageString))
                    .compose(Rx.applySchedulers())
                    .subscribe(aVoid -> {
                                profileImage.setImageBitmap(imageBitmap);
                                this.userProfile.image = imageString;
                            },
                            throwable -> {
                                try {
                                    ApiErrorDialogHelper.show(requireContext(), throwable);
                                } catch(Exception e) {
                                    e.printStackTrace();
                                }
                            });
        }
    }

    private void fetchUserProfile() {
        earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager());
        profileSubscription = userService.getProfileFromCacheAndApi()
                .subscribe(
                    this::updateUserProfile,
                    throwable -> {
                        try {
                            if (!ErrorHelper.authorizationErrorHandled(throwable, getContext(), logoutService)) {
                                ApiErrorDialogHelper.show(getContext(), throwable);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                );
        Timber.e("fetchUserProfile");
        profileSubscription = userService.getOrderAcceptCost()
                .subscribe(this::updatePrice,
                        throwable -> Timber.e(throwable.toString()));
    }

    private void updatePrice(OrderAcceptCost orderAcceptCost) {
        /*if (orderAcceptCost != null && orderAcceptCost.value) {
            priceForAcceptService.setVisibility(View.VISIBLE);
            priceForAcceptService.setText(getString(R.string.fee_for_accepted_order) + orderAcceptCost.currency + orderAcceptCost.price);
            showPromoteMyServiceButton();
        } else {
            priceForAcceptService.setVisibility(View.GONE);
            //promoteMyServiceButton.setVisibility(View.GONE);
        }*/
    }

    private void updateUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;

        if (earthlyDialog != null)
            earthlyDialog.dismiss();

        userInfo.setVisibility(View.VISIBLE);

        if (userProfile.image != null) {
            Bitmap imageBitmap = Base64Helper.base64ToBitmap(userProfile.image);
            profileImage.setImageBitmap(imageBitmap);
        } else profileImage.setImageResource(R.drawable.ic_profile_image);

        final String fullName = String.format("%s %s", userProfile.name, userProfile.lastName);
        nameSurname.setText(fullName);

        if (userProfile.hasAdress()) {
            final String formattedAddress = String.format(getString(R.string.profile_adress_format), userProfile.postalCode, userProfile.city, userProfile.street, userProfile.number);
            address.setText(formattedAddress);
        } else {
            address.setText("-");
        }

        profileEmail.setText(userProfile.email);
        profilePhone.setText(userProfile.phone);
        profileCountryName.setText(userProfile.country);

        if (AccountType.SERVICE_PROVIDER.equals(userProfile.accountType)) {
            showCompanyInfo(userProfile);
            // showCreditCardInfo(userProfile);
        } else {
            hideCompanyInfo();
            showMakeMeServiceProviderButton();
            // hideCreditCardInfo();
            hideCompanyPriceInfo();
        }
    }

    private void hideCompanyPriceInfo() {
        //priceForAcceptService.setVisibility(View.GONE);
    }

    private void showPromoteMyServiceButton() {
        /*promoteMyServiceButton.setVisibility(View.VISIBLE);
        makeMeServiceProviderButton.setVisibility(View.GONE);*/
    }

    private void showMakeMeServiceProviderButton() {
        /*promoteMyServiceButton.setVisibility(View.GONE);
        makeMeServiceProviderButton.setVisibility(View.VISIBLE);*/
    }

//    private void hideCreditCardInfo() {
//        cardLayout.setVisibility(View.GONE);
//    }

//    private void showCreditCardInfo(UserProfile userProfile) {
//        cardLayout.setVisibility(View.VISIBLE);
//        if (userProfile.card != null) {
//             detailsCreditCardButton.setVisibility(View.VISIBLE);
//            addCreditCardLayout.setVisibility(View.GONE);
//        } else {
//             detailsCreditCardButton.setVisibility(View.GONE);
//              addCreditCardLayout.setVisibility(View.VISIBLE);
//        }
//    }

    private void hideCompanyInfo() {
        companyGroup.setVisibility(View.GONE);
    }

    private void showCompanyInfo(UserProfile userProfile) {
        companyGroup.setVisibility(View.VISIBLE);
        profileNip.setText(userProfile.nip);
        profileCompanyName.setText(userProfile.companyName);
        String servicesTitle = getFormattedServices(userProfile.providedServices);
        profileAccountServices.setText(servicesTitle);
    }

    private String getFormattedServices(List<ServiceModel> providedServices) {
        StringBuilder text = new StringBuilder();
        int size = providedServices.size();
        for (int i = 0; i < size; i++) {
            ServiceModel providedService = providedServices.get(i);
            text.append(providedService.name);
            if (i != size - 1) {
                text.append(", ");//Kontakt podstawowy dla konta, jednostka biznesowa
            }
        }
        return text.toString();
    }

    void onChooseProfileImageClick() {
        if (this.userProfile.image != null) {
            new AlertDialog.Builder(getContext())
                    .setMessage(R.string.select_photo_source)
                    .setCancelable(true)
                    .setPositiveButton(R.string.photo_source_camera, (dialog, id) -> dispatchTakePictureIntent())
                    .setNegativeButton(R.string.photo_source_gallery, (dialog, id) -> dispatchChooseFromGalleryIntent())
                    .setNeutralButton(getString(R.string.photo_source_delete_photo), (dialog, id) -> deletePhoto())
                    .show();
        } else {
            new AlertDialog.Builder(getContext())
                    .setMessage(R.string.select_photo_source)
                    .setCancelable(true)
                    .setPositiveButton(R.string.photo_source_camera, (dialog, id) -> dispatchTakePictureIntent())
                    .setNeutralButton(R.string.photo_source_gallery, (dialog, id) -> dispatchChooseFromGalleryIntent())
                    .show();
        }
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, 1);
    }

    private void dispatchChooseFromGalleryIntent() {
        Intent chooseGalleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(chooseGalleryIntent, 2);
    }

    private void deletePhoto() {
        profileSubscription = userService.deleteUserImage()
                .compose(Rx.applySchedulers())
                .subscribe(aVoid -> {
                            profileImage.setImageResource(R.drawable.ic_profile_image);
                            this.userProfile.image = null;
                        },
                        throwable -> {
                            try {
                                ApiErrorDialogHelper.show(requireContext(), throwable);
                            } catch(Exception e) {
                                e.printStackTrace();
                            }
                        });
    }

    void onLogoutClick() {
        logoutSubscription = logoutService.logoutRemovePushKey()
                .compose(Rx.applySchedulersCompletable())
                .compose(ProgressDialog.createCompletable(getContext()))
                .subscribe(() -> {
                    final FragmentActivity activity = getActivity();
                    if (activity != null) {
                        LoginOrRegisterActivity.startOnTop(activity);
                        activity.finish();
                    }
                }, throwable -> {
                    try {
                        ApiErrorDialogHelper.show(requireContext(), throwable);
                    } catch(Exception e) {
                        e.printStackTrace();
                    }
                });

        googleSignInClient.signOut();

        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        if(accessToken == null) return;
        new GraphRequest(
                accessToken,
                "/me/permissions/",
                null,
                HttpMethod.DELETE,
                graphResponse -> {
                    loginManager.logOut();
                }
        ).executeAsync();
    }

    void onEditProfileClick() {
        EditProfileActivity.start(requireContext());
    }

    void onChangePasswordClick() {
        ChangePasswordActivity.start(requireContext());
    }

    void onInviteSmsClick() {
        InviteFriendActivity.start(getContext(), InviteType.PHONE);
    }

    void onInviteEmailClick() {
        InviteFriendActivity.start(getContext(), InviteType.EMAIL);
    }

    @Override
    public int getIconResource() {
        return R.drawable.ico_tab_my_profile;
    }

    @Override
    public int getTitleResource() {
        return R.string.tabs_my_profile;
    }

    @Override
    protected int getLayout() {
        return R.layout.tab_profile;
    }
}
