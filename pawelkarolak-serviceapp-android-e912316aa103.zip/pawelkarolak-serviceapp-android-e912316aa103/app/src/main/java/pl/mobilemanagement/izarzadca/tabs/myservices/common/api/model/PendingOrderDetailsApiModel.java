package pl.mobilemanagement.izarzadca.tabs.myservices.common.api.model;

import java.util.Date;
import java.util.List;

public class PendingOrderDetailsApiModel {
    public final String issueDescription;
    public final Date startDateTime;
    public final Date endDateTime;
    public final String street;
    public final String postalCode;
    public final String city;
    public final String serviceName;
    public final List<String> photos;

    public PendingOrderDetailsApiModel(String issueDescription, Date startDateTime, Date endDateTime, String street, String postalCode, String city, String serviceName, List<String> photos) {
        this.issueDescription = issueDescription;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.street = street;
        this.postalCode = postalCode;
        this.city = city;
        this.serviceName = serviceName;
        this.photos = photos;
    }

    public String getFormattedCustomerDetails() {
        return getAddress() + " " + postalCode;
    }

    public String getAddress() {
        return street + " " + city;
    }
}