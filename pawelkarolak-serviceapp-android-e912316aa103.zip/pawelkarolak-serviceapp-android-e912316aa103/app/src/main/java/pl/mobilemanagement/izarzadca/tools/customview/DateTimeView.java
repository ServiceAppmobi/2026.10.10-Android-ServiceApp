package pl.mobilemanagement.izarzadca.tools.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;
import java.util.Date;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.databinding.DateViewBinding;

public class DateTimeView extends LinearLayout {
    public DatePickerView datePickerView;

    public TimePickerView timePickerView;

    public String hint;

    TextInputLayout dateInputLayout;
    TextInputEditText orderDate;
    TextView orderHour;

    Calendar calendar = Calendar.getInstance();

    public DateTimeView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView(attrs);
    }

    public DateTimeView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(attrs);
    }

    private void initView(AttributeSet attrs) {
        DateViewBinding binding = DateViewBinding.inflate(LayoutInflater.from(getContext()), this);
        dateInputLayout = binding.dateInputLayout;
        orderDate = binding.orderFromDate;
        orderHour = binding.orderFromHour;

        if (attrs != null) {
            TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.DateFrame);
            int dateHintRes = a.getResourceId(R.styleable.DateFrame_time_hint, 0);
            hint = getResources().getString(dateHintRes);
            a.recycle();
        }
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        dateInputLayout.setHint(hint);
        datePickerView = new DatePickerView(getContext(), orderDate, calendar);
        timePickerView = new TimePickerView(getContext(), orderHour, calendar);
    }

    public Date getSelectedDate() {
        final DatePickerView.DateObject selectedDate = datePickerView.getDataObject();
        final TimePickerView.TimeObject selectedTime = timePickerView.getTimeObject();
        final Calendar calendarInstance = Calendar.getInstance();
        if (selectedDate != null) {
            calendarInstance.set(Calendar.YEAR, selectedDate.year);
            calendarInstance.set(Calendar.MONTH, selectedDate.monthOfYear);
            calendarInstance.set(Calendar.DAY_OF_MONTH, selectedDate.dayOfMonth);
        }
        if (selectedTime != null) {
            calendarInstance.set(Calendar.HOUR_OF_DAY, selectedTime.hourOfDay);
            calendarInstance.set(Calendar.MINUTE, selectedTime.minute);
        }
        return calendarInstance.getTime();
    }
}
