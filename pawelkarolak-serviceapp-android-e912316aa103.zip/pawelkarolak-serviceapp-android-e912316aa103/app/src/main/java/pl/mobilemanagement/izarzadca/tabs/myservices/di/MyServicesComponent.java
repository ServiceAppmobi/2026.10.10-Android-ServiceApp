package pl.mobilemanagement.izarzadca.tabs.myservices.di;

import dagger.Component;
import pl.mobilemanagement.izarzadca.common.di.ApplicationComponent;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderDetailsActivity;
import pl.mobilemanagement.izarzadca.tabs.myservices.ended.view.CompletedServiceTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.during.view.DuringServiceTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.pending.view.PendingServiceTabFragment;

@MyServicesScope
@Component(dependencies = ApplicationComponent.class, modules = MyServicesModule.class)
public interface MyServicesComponent {

    void inject(PendingServiceTabFragment pendingServiceTabFragment);

    void inject(CompletedServiceTabFragment completedServiceTabFragment);

    void inject(DuringServiceTabFragment duringServiceTabFragment);

    void inject(OrderDetailsActivity orderDetailsActivity);
}
