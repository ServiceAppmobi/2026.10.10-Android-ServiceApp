package pl.mobilemanagement.izarzadca.common.model.api;

import java.io.Serializable;

public class BraintreeToken implements Serializable {

    public String token;

}
