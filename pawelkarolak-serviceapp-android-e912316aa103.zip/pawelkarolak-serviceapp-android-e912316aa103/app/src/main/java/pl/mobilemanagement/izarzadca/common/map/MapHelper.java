package pl.mobilemanagement.izarzadca.common.map;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import rx.Observable;
import rx.Subscriber;

public class MapHelper {

    public static void markCurrentUserPosition(MapWithPos mapWithPos) {
        final LatLng userPosition = mapWithPos.userPos;
        final GoogleMap googleMap = mapWithPos.googleMap;
        final MarkerOptions currentPosMarker = new MarkerOptions().position(userPosition);
        googleMap.addMarker(currentPosMarker);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userPosition, 15));
    }

    public static Observable<GoogleMap> mapViewObservable(final MapView mapView) {
        return Observable.create(new Observable.OnSubscribe<GoogleMap>() {
            @Override
            public void call(final Subscriber<? super GoogleMap> subscriber) {
                OnMapReadyCallback mapReadyCallback = (t) -> {
                    subscriber.onNext(t);
                    subscriber.onCompleted();
                };
                mapView.getMapAsync(mapReadyCallback);
            }
        });
    }

    public static void initMapView(MapView mapView) {
        mapView.onCreate(null);
        mapView.onResume();
    }

    public static void safeDestroyMapView(MapView mapView) {
        if (mapView != null) {
            mapView.onPause();
            mapView.onDestroy();
        }
    }
}
