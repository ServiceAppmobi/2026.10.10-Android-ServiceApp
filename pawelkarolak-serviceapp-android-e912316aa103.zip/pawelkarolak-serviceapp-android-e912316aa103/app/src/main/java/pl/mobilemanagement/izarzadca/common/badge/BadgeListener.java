package pl.mobilemanagement.izarzadca.common.badge;

import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;
import rx.Observable;
import rx.subjects.BehaviorSubject;
import rx.subjects.SerializedSubject;

abstract class BadgeListener {
    private final DataSourceRepository dataSourceRepository;
    private final String badgeKey;
    private final SerializedSubject<Boolean, Boolean> unreadedBadge;

    public BadgeListener(DataSourceRepository localDataRepository, String badgeKey) {
        this.badgeKey = badgeKey;
        dataSourceRepository = localDataRepository;
        final Boolean anyUnreadedServices = localDataRepository.readBoolean(badgeKey, false);
        unreadedBadge = BehaviorSubject.create(anyUnreadedServices).toSerialized();
    }

    public void informNewBadgeAvaiable() {
        informAboutChanges(true);
    }

    public void informBadgeWatched() {
        informAboutChanges(false);
    }

    private void informAboutChanges(boolean hasServicesUnread) {
        unreadedBadge.onNext(hasServicesUnread);
        dataSourceRepository.write(badgeKey, hasServicesUnread);
    }

    public Observable<Boolean> getBadgeIsAvailable() {
        return unreadedBadge.asObservable();
    }
}
