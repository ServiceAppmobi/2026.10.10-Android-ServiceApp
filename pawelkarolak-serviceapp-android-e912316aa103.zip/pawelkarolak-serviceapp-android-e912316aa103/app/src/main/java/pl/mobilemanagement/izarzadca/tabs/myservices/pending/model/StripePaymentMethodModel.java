package pl.mobilemanagement.izarzadca.tabs.myservices.pending.model;

public class StripePaymentMethodModel {
    public String id;
}
