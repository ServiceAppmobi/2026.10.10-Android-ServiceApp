package pl.mobilemanagement.izarzadca.tools;

public final class StringUtil {
    public static boolean isEmpty(String text) {
        return text == null || text.length() == 0;
    }

    public static String getNumberForPosition(int i) {
        return Integer.toString(i + 1);
    }
}
