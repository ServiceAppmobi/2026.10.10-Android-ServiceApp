package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs;

import static pl.mobilemanagement.izarzadca.tools.rx.Rx.safeUnsubscribe;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.databinding.CommunityInfoFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.di.DaggerMyCommunityComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.CommunityInfo;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by katak on 10.01.2017.
 */

public class CommunityCommunity extends TitledTabFragment {

    @Inject
    CommunityApi communityApi;

    private CommunityInfoFrameBinding binding;

    private Subscription fetchSubscription;

    @Override
    public int getTitleResource() {
        return R.string.profile_CommunityCommunity;
    }

    @Override
    protected int getLayout() {
        return R.layout.community_info_frame;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerMyCommunityComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view,savedInstanceState);
        binding = CommunityInfoFrameBinding.bind(view);
    }

    public void setData(CommunityInfo data) {
        Log.i("CommunityInfo", "setDataX");
        Log.i("CommunityInfoname", String.valueOf(data.name));
        Log.i("CommunityInfoaddress", String.valueOf(data.address));
        Log.i("CommunityInfonr", String.valueOf(data.nr));
        Log.i("CommunityInfocity", String.valueOf(data.city));
        Log.i("CommunityInfopostalCode", String.valueOf(data.postalCode));
        Log.i("CommunityInforegion", String.valueOf(data.region));
        Log.i("CommunityInfocountry", String.valueOf(data.country));
        Log.i("CommunityInfophone", String.valueOf(data.phone));
        Log.i("CommunityInfoemail", String.valueOf(data.email));
        Log.i("CommunityInfocontact", String.valueOf(data.contact));
        Log.i("CommunityInfoskype", String.valueOf(data.skype));
        Log.i("CommunityInfoaccountant", String.valueOf(data.accountant));
        Log.i("CommunityInfophoneNr", String.valueOf(data.phoneNr));

        binding.name.setText(data.name);
        binding.country.setText(data.country);
        binding.province.setText(data.region);
        binding.town.setText(data.city);
        binding.postCode.setText(data.postalCode);
        binding.street.setText(data.address);

        binding.phone.setText(data.phone);
        binding.email.setText(data.email);

        binding.skype.setVisibility(data.skype == null || data.skype.isEmpty() ? View.GONE : View.VISIBLE);
        binding.contact.setVisibility(data.contact == null || data.contact.isEmpty() ? View.GONE : View.VISIBLE);

        binding.skype.setText(data.skype);
        binding.contact.setText(data.contact);
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchSubscription = getCommunityInformation().subscribe();
    }

    public Observable<CommunityInfo> getCommunityInformation() {
        return communityApi.getCommunityInfo()
                .doOnError(this::showConnectionError)
                .onErrorResumeNext(throwable -> Observable.empty())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext(this::setData);
    }

    @Override
    public void onPause() {
        super.onPause();
        safeUnsubscribe(fetchSubscription);
    }

    public void hideError() {
        binding.noItems.getRoot().setVisibility(View.GONE);
    }

    public void showEmptyListError() {
        Log.i("CommunityInfo", "showEmptyListError");

        binding.noItems.getRoot().setVisibility(View.VISIBLE);
        binding.noItems.noItemsMessage.setText(R.string.accepted_order_empty);
    }

    public void showConnectionError(Throwable message) {
        Log.i("CommunityInfo", "showConnectionError");
        Log.i("CommunityInfo", String.valueOf(message));

        binding.noItems.getRoot().setVisibility(View.VISIBLE);
        binding.noItems.noItemsMessage.setText(R.string.list_view_connection_error);
    }
}
