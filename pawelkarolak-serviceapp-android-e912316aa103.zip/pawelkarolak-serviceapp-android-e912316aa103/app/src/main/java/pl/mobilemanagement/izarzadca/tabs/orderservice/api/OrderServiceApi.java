package pl.mobilemanagement.izarzadca.tabs.orderservice.api;

import java.util.List;

import pl.mobilemanagement.izarzadca.tabs.orderservice.model.ProviderOpinionsApiModel;
import pl.mobilemanagement.izarzadca.tabs.orderservice.model.ServiceGroupId;
import pl.mobilemanagement.izarzadca.tabs.orderservice.model.UserId;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.order.OrderRequest;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider.ServiceProvider;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider.ServiceProviderRequest;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceGroup;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import rx.Observable;

public interface OrderServiceApi {

    @GET("Service/GetServicesGroups")
    Observable<List<ServiceGroup>> getServicesGroups();

    @POST("Service/GetServiceProviderOpinions")
    Observable<List<ProviderOpinionsApiModel>> getProviderOpinion(@Body UserId providerId);

    @POST("Service/GetServices")
    Observable<List<ServiceModel>> getServicesByGroupId(@Body ServiceGroupId serviceGroupId);

    @POST("Service/GetServiceProviders")
    Observable<List<ServiceProvider>> getServiceProviders(@Body ServiceProviderRequest serviceId);

    @POST("Service/RegisterServiceRequest")
    Observable<Void> sendOrderService(@Body OrderRequest orderRequest);


}
