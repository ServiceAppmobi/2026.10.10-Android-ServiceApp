package pl.mobilemanagement.izarzadca.common.invite.contact;

public enum InviteType {
    PHONE, EMAIL
}
