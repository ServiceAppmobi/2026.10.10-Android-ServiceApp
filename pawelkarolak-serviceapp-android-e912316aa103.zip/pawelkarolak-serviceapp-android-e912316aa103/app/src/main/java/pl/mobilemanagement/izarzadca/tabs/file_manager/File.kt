package pl.mobilemanagement.izarzadca.tabs.file_manager

data class File(
    val name: String,
    val url: String,
    val lastModified: String
) {
    val extension: String
        get() = url.split(".").last()
}
