package pl.mobilemanagement.izarzadca.tools.api;

import android.content.Context;

import com.afollestad.materialdialogs.MaterialDialog;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.tools.Validator;

public class ValidationErrorDialogHelper {


    public static MaterialDialog show(Context context, Validator validator) {
        String message = validator.getErrors().get(0);
        return new MaterialDialog.Builder(context)
                .title(R.string.validation_error)
                .positiveText(R.string.ok)
                .content(message)
                .show();
    }

}
