package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete.model;

import pl.mobilemanagement.izarzadca.common.model.api.Order;

public class CompleteOrder extends Order {
    public int rating;
    public String opinion;

    public boolean isRated() {
        return rating != -1;
    }
}
