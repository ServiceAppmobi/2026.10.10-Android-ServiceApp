package pl.mobilemanagement.izarzadca.common.invite.api;

import pl.mobilemanagement.izarzadca.common.model.api.RecommendContact;
import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

public interface InviteFriendApi {

    @POST("Register/RequestContacts")
    Observable<Void> sendInformatioToFriends(@Body RecommendContact recommendContact);

}
