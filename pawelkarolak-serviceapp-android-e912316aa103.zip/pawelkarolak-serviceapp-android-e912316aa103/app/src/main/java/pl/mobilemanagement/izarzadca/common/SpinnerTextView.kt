package pl.mobilemanagement.izarzadca.common

import android.content.Context
import android.text.InputType
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatAutoCompleteTextView
import pl.mobilemanagement.izarzadca.R

class SpinnerTextView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyleAttr: Int = R.attr.autoCompleteTextViewStyle
) : AppCompatAutoCompleteTextView(context, attrs, defStyleAttr) {
    init {
        isClickable = false
        isCursorVisible = false
        isFocusable = false
        isFocusableInTouchMode = false
        inputType = InputType.TYPE_NULL
    }
}