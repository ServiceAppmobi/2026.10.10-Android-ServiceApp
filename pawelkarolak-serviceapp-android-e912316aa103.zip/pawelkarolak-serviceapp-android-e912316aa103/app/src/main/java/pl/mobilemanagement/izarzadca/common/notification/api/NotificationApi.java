package pl.mobilemanagement.izarzadca.common.notification.api;

import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import rx.Observable;

public interface NotificationApi {
    @POST("Notifications/RegisterOrUpdateDevice")
    Observable<Void> registerOrUpdateDevice(@Body Device device);


    @GET("Community/CheckIfCommunityMember")
    Observable<Boolean> checkIfCommunityMember();
}
