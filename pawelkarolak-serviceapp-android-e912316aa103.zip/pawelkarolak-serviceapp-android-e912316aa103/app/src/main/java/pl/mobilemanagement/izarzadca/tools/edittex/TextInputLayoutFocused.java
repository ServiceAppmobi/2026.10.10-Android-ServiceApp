package pl.mobilemanagement.izarzadca.tools.edittex;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import com.google.android.material.textfield.TextInputLayout;

public class TextInputLayoutFocused extends TextInputLayout {

  public TextInputLayoutFocused(Context context) {
    super(context, null);
  }

  public TextInputLayoutFocused(Context context, AttributeSet attrs) {
    super(context, attrs, 0);
  }

  @SuppressLint("RestrictedApi")
  public TextInputLayoutFocused(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
  }
}