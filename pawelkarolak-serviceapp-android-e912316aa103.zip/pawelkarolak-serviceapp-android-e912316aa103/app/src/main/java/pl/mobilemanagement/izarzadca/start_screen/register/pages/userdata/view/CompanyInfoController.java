package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view;

import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.applySchedulers;
import static pl.mobilemanagement.izarzadca.tools.rx.Rx.safeUnsubscribe;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.flexbox.FlexboxLayout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.SpinnerTextView;
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi;
import pl.mobilemanagement.izarzadca.common.model.api.DistanceArea;
import pl.mobilemanagement.izarzadca.common.model.api.SimpleServiceModel;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.DistanceAreaSpinnerItem;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.ServiceSelectActivity;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.ServicesSpinnerItem;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.ServiceItem;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.spinner.HintAdapter;
import rx.Observable;
import rx.Subscription;

public class CompanyInfoController {

    private static final int MAX_COMPANY_NAME_LENGTH = 300;
    private static final int MAX_COMPANY_DESCRIPTION_LENGTH = 500;
    final private EditText companyName;

    final private EditText companyNip;

    final private TextView tlCompanyServices;

    final private EditText companyDescription;

    final private SpinnerTextView companyRange;

    private final FlexboxLayout servicesFrame;
    private Subscription typeServicesSubscription;
    private Subscription distanceSubscription;
    private DistanceArea selectedDistanceArea;
    private final List<ServiceModel> selectedTypeServices = new ArrayList<>();
    private final UnauthorizedApi unauthorizedApi;

    private List<ServiceItem> serviceItemList = Collections.emptyList();
    private final Activity activity;

    public CompanyInfoController(UnauthorizedApi unauthorizedApi,
                                 EditText companyName,
                                 EditText companyNip,
                                 TextView tlCompanyServices,
                                 Activity activity,
                                 EditText companyDescription,
                                 SpinnerTextView companyRange,
                                 FlexboxLayout servicesFrame) {
        this.unauthorizedApi = unauthorizedApi;
        this.companyName = companyName;
        this.companyNip = companyNip;
        this.tlCompanyServices = tlCompanyServices;
        this.companyDescription = companyDescription;
        this.companyRange = companyRange;
        this.servicesFrame = servicesFrame;
        this.activity = activity;
        initViews();
    }

    private void initViews() {
        HintAdapter.initEmpty(companyRange);
        companyName.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_COMPANY_NAME_LENGTH)});
        companyDescription.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_COMPANY_DESCRIPTION_LENGTH)});
        companyRange.setOnItemClickListener((parent, view, position, id) -> {
            final DistanceAreaSpinnerItem item = (DistanceAreaSpinnerItem) parent.getAdapter().getItem(position);
            this.selectedDistanceArea = item.getDistanceArea();
        });
        tlCompanyServices.setOnClickListener(v -> {
            Intent intent = new Intent(tlCompanyServices.getContext(), ServiceSelectActivity.class);
            intent.putExtra(ServiceSelectActivity.ARG_SERVICES, serviceItemList.toArray(new ServiceItem[0]));

            String[] checkedIds = new String[selectedTypeServices.size()];
            for (int i = 0; i < selectedTypeServices.size(); i++)
                checkedIds[i] = selectedTypeServices.get(i).serviceId;
            intent.putExtra(ServiceSelectActivity.ARG_CHECKED_SERVICES, checkedIds);
            activity.startActivityForResult(intent, ServiceSelectActivity.REQ_SERVICES_RESULT);
        });
    }

    private void fetchTypeService() {
        typeServicesSubscription = unauthorizedApi.getTypeServicesResponse()
                .compose(applySchedulers())
                .flatMap(Observable::from)
                .toSortedList((serviceModel, serviceModel2) -> serviceModel.name.compareTo(serviceModel2.name))
                .subscribe(
                    typeServices -> serviceItemList = ServicesSpinnerItem.createItems(typeServices),
                    throwable -> ApiErrorDialogHelper.show(getContext(), throwable)
                );
    }

    private void fetchDistanceArea() {
        distanceSubscription = unauthorizedApi.getDistanceArea()
                .compose(applySchedulers())
                .subscribe(distanceAreas -> {
                    List<DistanceAreaSpinnerItem> countrySpinnerItems = DistanceAreaSpinnerItem.createSpinnerItems(distanceAreas);
                    HintAdapter.setHintData(companyRange, countrySpinnerItems);
                }, throwable -> ApiErrorDialogHelper.show(getContext(), throwable));
    }

    public void setSelectedTypeServices(List<ServiceItem> serviceItems) {
        selectedTypeServices.clear();
        servicesFrame.removeAllViews();
        for (ServiceItem item : serviceItems) {
            ServiceModel serviceModel = new ServiceModel(item.getServiceId(), item.getText());
            addServiceItem(serviceModel);
        }
        servicesFrame.setVisibility(selectedTypeServices.size() > 0 ? View.VISIBLE : View.GONE);
    }

    private void addServiceItem(ServiceModel typeService) {
        if (selectedTypeServices.contains(typeService))
            return;
        selectedTypeServices.add(typeService);
        View serviceLayout = LayoutInflater.from(getContext()).inflate(R.layout.provider_service_row, servicesFrame, false);
        ((TextView) serviceLayout.findViewById(R.id.selectedService)).setText(typeService.name);
        serviceLayout.findViewById(R.id.removeService).setOnClickListener(v -> {
            selectedTypeServices.remove(typeService);
            servicesFrame.removeView(serviceLayout);
            servicesFrame.setVisibility(selectedTypeServices.size() > 0 ? View.VISIBLE : View.GONE);
        });
        servicesFrame.addView(serviceLayout);
    }


    public String getCompanyNIP() {
        return getTrimmedText(companyNip);
    }

    public String getCompanyName() {
        return getTrimmedText(companyName);
    }

    public String getDescription() {
        return getTrimmedText(companyDescription);
    }

    public Validator validateInput() {
        Validator validator = new Validator();
        if (selectedDistanceArea == null) {
            validator.addError(getContext().getString(R.string.comapy_data_no_distance));
        }
        if (selectedTypeServices.isEmpty()) {
            validator.addError(getContext().getString(R.string.company_data_no_service_type));
        }
        if (getCompanyName().isEmpty()) {
            validator.addError(getContext().getString(R.string.company_data_no_company_name));
        }
        return validator;
    }


    private Context getContext() {
        return companyName.getContext();
    }

    public String getSelectedDistanceArea() {
        return Long.toString(selectedDistanceArea.id);
    }

    public List<SimpleServiceModel> getSelectedSericeTypes() {
        List<SimpleServiceModel> simpleServiceModels = new ArrayList<>();
        for (ServiceModel selectedTypeService : selectedTypeServices) {
            simpleServiceModels.add(new SimpleServiceModel(selectedTypeService.serviceId));
        }
        return simpleServiceModels;
    }

    public void restore(DistanceArea distanceArea, List<ServiceModel> typeServices) {
        this.selectedDistanceArea = distanceArea;
        for (ServiceModel typeService : typeServices) {
            addServiceItem(typeService);
        }
        servicesFrame.setVisibility(selectedTypeServices.size() > 0 ? View.VISIBLE : View.GONE);
    }

    public void onCreate() {
        fetchTypeService();
        fetchDistanceArea();
    }

    public void onDestroy() {
        companyRange.dismissDropDown();
        safeUnsubscribe(typeServicesSubscription, distanceSubscription);
    }
}