package pl.mobilemanagement.izarzadca.tools.api;

import android.content.Context;

import pl.mobilemanagement.izarzadca.common.user.LogoutService;
import pl.mobilemanagement.izarzadca.start_screen.LoginOrRegisterActivity;
import retrofit2.adapter.rxjava.HttpException;

public class ErrorHelper {
    private ErrorHelper() {
    }

    public static boolean isAuthorizationError(Throwable throwable) {
        if (throwable instanceof HttpException) {
            final HttpException httpException = (HttpException) throwable;
            return httpException.code() == 403 || httpException.code() == 401;
        }
        return false;
    }

    public static boolean authorizationErrorHandled(Throwable throwable, Context context, LogoutService logoutService) {
        if (ErrorHelper.isAuthorizationError(throwable)) {
            logoutService.clearPersonalData();
            LoginOrRegisterActivity.startOnTop(context);
            return true;
        }
        return false;
    }
}