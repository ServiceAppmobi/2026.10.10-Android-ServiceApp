package pl.mobilemanagement.izarzadca.common.map;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;

public class MapWithPos {
        public final GoogleMap googleMap;
        public final LatLng userPos;

        public MapWithPos(GoogleMap googleMap, LatLng userPos) {
            this.googleMap = googleMap;
            this.userPos = userPos;
        }

        public MapWithPos(GoogleMap googleMap, double lat, double lng) {
            this.googleMap = googleMap;
            this.userPos = new LatLng(lat, lng);
        }
    }