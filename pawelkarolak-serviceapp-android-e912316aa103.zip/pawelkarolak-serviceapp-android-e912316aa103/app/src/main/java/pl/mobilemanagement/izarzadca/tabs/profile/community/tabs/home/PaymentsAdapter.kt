package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.databinding.ItemPaymentBinding
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models.Payment
import pl.mobilemanagement.izarzadca.tools.DateUtil

class PaymentsAdapter(
    private var paymentsList: List<Payment>
): RecyclerView.Adapter<PaymentsAdapter.PaymentViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PaymentViewHolder {
        val binding = ItemPaymentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PaymentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PaymentViewHolder, position: Int) {
        val payment = paymentsList[position]
        holder.bind(payment)
    }

    override fun getItemCount() = paymentsList.size

    inner class PaymentViewHolder(
            private val binding: ItemPaymentBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(payment: Payment) {
            val context = binding.root.context
            val date = DateUtil.getFormattedDateFromServerDate(payment.date, DateUtil.YYYY_MM_DD_FORMAT)
            binding.date.text = context.resources.getString(R.string.paid_on, date)
            binding.moneyValue.text = payment.amount
        }

    }

    fun update(paymentsList: List<Payment>) {
        this.paymentsList = paymentsList
        notifyDataSetChanged()
    }

}