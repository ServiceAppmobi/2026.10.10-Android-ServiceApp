package pl.mobilemanagement.izarzadca.tools;

public interface ItemClickListener {

    void onItemClick(int adapterPosition);
}
