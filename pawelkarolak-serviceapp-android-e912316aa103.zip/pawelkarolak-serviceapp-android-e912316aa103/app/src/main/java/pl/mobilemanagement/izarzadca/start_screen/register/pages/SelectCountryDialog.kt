package pl.mobilemanagement.izarzadca.start_screen.register.pages

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.Button
import androidx.core.os.bundleOf
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import pl.mobilemanagement.izarzadca.App
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.common.CountrySpinnerAdapter
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi
import pl.mobilemanagement.izarzadca.common.model.entity.Country
import pl.mobilemanagement.izarzadca.databinding.DialogSelectCountryBinding
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper
import pl.mobilemanagement.izarzadca.tools.rx.Rx
import rx.Subscription
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import javax.inject.Inject

class SelectCountryDialog : DialogFragment(), OnItemClickListener {

    private lateinit var binding: DialogSelectCountryBinding

    @Inject
    lateinit var unauthorizedApi: UnauthorizedApi

    private var countryFetchSubscription: Subscription? = null

    private var countryId: String? = null
    private var countries = emptyList<Country>()

    private lateinit var okButton: Button

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        App.component.inject(this)

        countryId = savedInstanceState?.getString(COUNTRY_ID)

        binding = DialogSelectCountryBinding.inflate(layoutInflater)
        binding.countrySpinner.onItemClickListener = this

        countryFetchSubscription = unauthorizedApi.countries
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ countries: List<Country>? ->
                    this.countries = countries.orEmpty()
                    val adapter = CountrySpinnerAdapter(requireContext(), android.R.layout.simple_list_item_1, this.countries)
                    binding.countrySpinner.setAdapter(adapter)
                }, { throwable: Throwable? -> ApiErrorDialogHelper.show(context, throwable) })

        binding.countrySpinner.setOnFocusChangeListener { _, _ ->
            binding.countrySpinner.showDropDown()
        }
        binding.countrySpinner.setOnTouchListener { _, _ ->
            binding.countrySpinner.showDropDown()
            false
        }

        val dialog = AlertDialog.Builder(requireContext())
                .setView(binding.root)
                .setTitle(R.string.registration_phone_number_select_country)
                .setPositiveButton(R.string.yes) { _, _ ->
                    setFragmentResult(RESULT_KEY, bundleOf(RESULT_KEY to countryId))
                    dismiss()
                }
                .create()

        return dialog
    }

    override fun onResume() {
        super.onResume()
        okButton = (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE)
        updateButton()
    }

    override fun onItemClick(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
        val item = parent.adapter.getItem(position) as Country
        countryId = item.id
        updateButton()
    }

    private fun updateButton() {
        okButton.isEnabled = !countryId.isNullOrBlank()
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        Rx.safeUnsubscribe(countryFetchSubscription)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(COUNTRY_ID, countryId)
    }

    companion object {
        const val RESULT_KEY = "SelectCountryDialog"
        private const val COUNTRY_ID = "COUNTRY_ID"
    }
}