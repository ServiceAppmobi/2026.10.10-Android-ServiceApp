package pl.mobilemanagement.izarzadca.tabs.profile.community.model

data class RequestDepositRequest(
    val amount: String,
    val apartmentId: String,
    val note: String
)
