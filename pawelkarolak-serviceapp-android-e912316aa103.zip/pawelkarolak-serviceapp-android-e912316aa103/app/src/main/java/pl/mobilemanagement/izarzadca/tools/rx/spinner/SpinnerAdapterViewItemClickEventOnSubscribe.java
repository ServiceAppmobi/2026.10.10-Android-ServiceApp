package pl.mobilemanagement.izarzadca.tools.rx.spinner;

import static rx.android.MainThreadSubscription.verifyMainThread;

import android.widget.AdapterView;
import pl.mobilemanagement.izarzadca.common.SpinnerTextView;
import rx.Observable;
import rx.Subscriber;
import rx.android.MainThreadSubscription;

final class SpinnerAdapterViewItemClickEventOnSubscribe<T>
        implements Observable.OnSubscribe<T> {
  final SpinnerTextView view;

  public SpinnerAdapterViewItemClickEventOnSubscribe(SpinnerTextView view) {
    this.view = view;
  }

    @Override
    public void call(final Subscriber<? super T> subscriber) {
        verifyMainThread();

        AdapterView.OnItemClickListener listener = (parent, view1, position, id) -> {
            if (!subscriber.isUnsubscribed()) {
                subscriber.onNext((T) parent.getAdapter().getItem(position));
            }
        };

        subscriber.add(new MainThreadSubscription() {
            @Override
            protected void onUnsubscribe() {
                view.setOnItemClickListener(null);
            }
        });

        view.setOnItemClickListener(listener);
    }
}