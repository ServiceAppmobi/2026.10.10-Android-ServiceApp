package pl.mobilemanagement.izarzadca.tabs.profile.creditcard.create.model;

public class CreditCardApiModel {
    public final int type;
    public final String name;
    public final String number;
    public final int expMonth;
    public final int expYear;
    public final String cvv;

    public CreditCardApiModel(int type, String name, String number, int expMonth, int expYear, String cvv) {
        this.type = type;
        this.name = name;
        this.number = number;
        this.expMonth = expMonth;
        this.expYear = expYear;
        this.cvv = cvv;
    }
}
