package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Date;

public class GetFailureReports implements Serializable {
    @SerializedName("title")
    public String title;

    @SerializedName("createDate")
    public Date createDate;

    @SerializedName("statusCode")
    public String statusCode;

    @SerializedName("priority")
    public String priority;

    @SerializedName("ticket")
    public String ticket;

    @SerializedName("description")
    public String description;

    @SerializedName("statusId")
    public int statusId;

    public final static int OPEN = 100000000;
    public final static int IN_PROGRESS = 1;
    public final static int HOLD = 2;
    public final static int WAITING_FOR_DETAILS = 3;
    public final static int RESEARCHING = 4;
}
