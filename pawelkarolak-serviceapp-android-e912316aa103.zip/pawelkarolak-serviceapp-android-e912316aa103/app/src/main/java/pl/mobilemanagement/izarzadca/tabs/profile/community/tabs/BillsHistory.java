package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;

import org.jetbrains.annotations.NotNull;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.CloseOrderClickListener;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.di.DaggerMyCommunityComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetPaidRents;
import rx.Observable;
import rx.Subscription;
import rx.schedulers.Schedulers;

/**
 * Created by katak on 10.01.2017.
 */

public class BillsHistory extends TitledTabFragment implements CloseOrderClickListener {

    @Inject
    CommunityApi communityApi;

    BarChart barChart;

    TableLayout tblAddLayout;

    private Subscription fetchSubscription;

    @Override
    public int getTitleResource() {
        return R.string.tab_my_payments;
    }

    @Override
    public void onCloseOrderClick(Order order) {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DaggerMyCommunityComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }

    @Override
    public void onResume() {
        Log.i("INFO", "onResume");
        super.onResume();
        fetchSubscription = getCommunityInformation().subscribe();
    }

    public Observable<List<GetPaidRents>> getCommunityInformation() {
        return communityApi.getPaidRents()
                .doOnNext(this::setData)
                .doOnError(this::showConnectionError)
                .onErrorResumeNext(throwable -> Observable.empty())
                .subscribeOn(Schedulers.io());
    }

    private void setData(List<GetPaidRents> getPaidRents) {
        Handler txtsettext = new Handler(Looper.getMainLooper());

        txtsettext.post(new Runnable() {
            public void run() {
                barChart.setDrawBarShadow(false);
                //barChart.setDrawValueAboveBar(true);
                Description assad = new Description();
                assad.setText("Wpłaty");
                barChart.setDescription(assad);
                barChart.setMaxVisibleValueCount(20);
                //barChart.setPinchZoom(false);
                barChart.setDrawGridBackground(false);

                barChart.setDrawValueAboveBar(true);

                //barChart.setDrawValuesForWholeStack(true);

                XAxis xl = barChart.getXAxis();

                xl.setDrawLabels(true);
                xl.setValueFormatter(new IAxisValueFormatter() {
                    int counter = 0;

                    @Override
                    public String getFormattedValue(float value, AxisBase axis) {
                        Log.i("zain2", "value " + value);
                        Log.i("zain2", String.valueOf(axis));
                        return "";
                    }
                });

                xl.setGranularity(1f);
                xl.setCenterAxisLabels(true);

                YAxis leftAxis = barChart.getAxisLeft();

                leftAxis.setValueFormatter(new IAxisValueFormatter() {
                    @Override
                    public String getFormattedValue(float value, AxisBase axis) {
                        // Log.i("zain3", "value " + value);
                        return "";
                    }
                });

                leftAxis.setDrawGridLines(false);
                leftAxis.setSpaceTop(30f);
                //   leftAxis.setAxisMinValue(0f); // this replaces setStartAtZero(true

                barChart.getAxisRight().setEnabled(false);

                List<BarEntry> yVals1 = new ArrayList<BarEntry>();

                Listview_2 holder = new Listview_2();
                ;
                int i = 0;
                Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                ArrayList<BarEntry> entries = new ArrayList<>();
                ArrayList<String> labels = new ArrayList<String>();

                for (GetPaidRents aaaa : getPaidRents) {

                    TableRow inflate = (TableRow) View.inflate(getContext(), R.layout.table_row, null);

                    holder.row1 = inflate.findViewById(R.id.row_one);
                    holder.row2 = inflate.findViewById(R.id.row_two);
                    // holder.row3 = (TextView) inflate.findViewById(R.id.row_three);

                    String createDate = "-";
                    if (aaaa.createDate != null) {
                        createDate = formatter.format(aaaa.createDate);
                    }

                    if (holder.row1 != null) {
                        holder.row1.setText(createDate);
                    }
                    if (holder.row2 != null) {
                        holder.row2.setText(String.format("%.2f", Float.parseFloat(aaaa.amount)) + " PLN");
                    }

                    inflate.setTag(holder);
                    tblAddLayout.addView(inflate);

                    yVals1.add(new BarEntry(i++, Float.parseFloat(aaaa.amount), aaaa.createDate));

            /*        entries.add(new BarEntry(Float.parseFloat(aaaa.amount), i++));
                    labels.add(aaaa.createDate+"D");*/
                }






    /*            BarDataSet dataset = new BarDataSet(entries, "# of Calls");


                BarData data = new BarData(labels, dataset);

                barChart.setData(data);*/

                BarDataSet set1;

                if (barChart.getData() != null && barChart.getData().getDataSetCount() > 0) {
                    set1 = (BarDataSet) barChart.getData().getDataSetByIndex(0);
                    set1.setValues(yVals1);
                    barChart.getData().notifyDataChanged();
                    barChart.notifyDataSetChanged();
                } else {
                    // create 2 datasets with different types
                    set1 = new BarDataSet(yVals1, "Zapłacone");
                    set1.setColor(Color.parseColor("#01b3eb"));

                    ArrayList<IBarDataSet> dataSets = new ArrayList<IBarDataSet>();
                    dataSets.add(set1);

                    BarData data = new BarData(dataSets);

                    barChart.setData(data);
                }
/*
                barChart.getBarData().setBarWidth(barWidth);
                barChart.getXAxis().setAxisMinValue(1);*/
                barChart.getLegend().setEnabled(false);
                barChart.getXAxis().setAxisMinimum(1);

                //barChart.setFitBars(true);
                barChart.invalidate();
            }
        });

        Log.i("BillsHistory", "setData");
        Log.i("BillsHistory", String.valueOf(getPaidRents));
    }

    public void showConnectionError(Throwable message) {

        Log.e("BillsHistory", "showConnectionError");
        Log.e("BillsHistory", String.valueOf(message));
    }

    @Override
    public void onViewCreated(@NotNull View view, @Nullable Bundle savedInstanceState) {
        Log.i("INFO", "onViewCreated");
        super.onViewCreated(view, savedInstanceState);

        barChart = view.findViewById(R.id.chart);
        tblAddLayout = view.findViewById(R.id.score_table);
    }

    @Override
    protected int getLayout() {
        return R.layout.bills_history_frame;
    }

    static class Listview_2 {
        TextView row1;
        TextView row2;
    }
}
