package pl.mobilemanagement.izarzadca.common

import android.content.Context
import android.widget.ArrayAdapter
import android.widget.Filter
import pl.mobilemanagement.izarzadca.common.model.entity.Country


class CountrySpinnerAdapter(
    context: Context,
    resource: Int,
    items: List<Country>
) : ArrayAdapter<Country?>(context, resource, items) {

    private val allCountries = items.toList()

    override fun getFilter(): Filter {
        return nameFilter
    }

    private val nameFilter: Filter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val filteredList = if (constraint.isNullOrBlank())
                allCountries
            else
                allCountries.filter {
                    it.name.lowercase().startsWith(constraint.toString().lowercase())
                }
            val filterResults = FilterResults()
            filterResults.values = filteredList
            filterResults.count = filteredList.size
            return filterResults
        }

        override fun publishResults(constraint: CharSequence?, results: FilterResults) {
            clear()
            addAll(results.values as List<Country>)
            notifyDataSetChanged()
        }
    }
}