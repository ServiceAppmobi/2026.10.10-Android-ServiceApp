package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models

data class Apartment(
    val id: String,
    val name: String,
    val role: String
) {
    val isTenant: Boolean
        get() = role == "Tenant"
}
