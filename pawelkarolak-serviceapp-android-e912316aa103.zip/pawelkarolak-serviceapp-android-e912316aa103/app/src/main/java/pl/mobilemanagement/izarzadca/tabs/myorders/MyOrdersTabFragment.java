package pl.mobilemanagement.izarzadca.tabs.myorders;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Arrays;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.badge.MyOrderBadge;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabsFragmentAdapter;
import pl.mobilemanagement.izarzadca.databinding.TabMyOrderBinding;
import pl.mobilemanagement.izarzadca.tabs.TabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.AcceptedOrderTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete.CompleteOrderTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.view.PendingOrderTabFragment;
import rx.android.schedulers.AndroidSchedulers;

public class MyOrdersTabFragment extends TabFragment {

    private TabMyOrderBinding binding;

    @Inject
    MyOrderBadge myOrderBadgeListener;

    public MyOrdersTabFragment() {
        App.component.inject(this);
    }

    @Override
    public int getIconResource() {
        return R.drawable.ico_tab_my_orders;
    }

    @Override
    public int getTitleResource() {
        return R.string.tabs_my_orders;
    }

    @Override
    protected int getLayout() {
        return R.layout.tab_my_order;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding = TabMyOrderBinding.bind(view);
        TitledTabsFragmentAdapter<TitledTabFragment> tabsFragmentAdapter = new TitledTabsFragmentAdapter<>(
                getContext(),
                getChildFragmentManager(),
                Arrays.asList(
                    new AcceptedOrderTabFragment(),
                    new PendingOrderTabFragment(),
                    new CompleteOrderTabFragment()
                )
        );
        binding.myOrderViewPager.setAdapter(tabsFragmentAdapter);
        binding.myOrderTabLayout.setupWithViewPager(binding.myOrderViewPager);
    }

    @Override
    protected void bindTabView(View indicator) {
        myOrderBadgeListener.getBadgeIsAvailable()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(hasUnreaded -> {
                    indicator.setVisibility(hasUnreaded ? View.VISIBLE : View.GONE);
                });
    }

    @Override
    public void onResume() {
        super.onResume();
        myOrderBadgeListener.informBadgeWatched();
    }

    /*@Override
    public void onTargetNotification(Observable<Message> oMessage) {
        oMessage.subscribe(message -> {
            myOrderBadgeListener.informBadgeWatched();
        });
    }

    @Override
    public void onMismatchTargetNotification(Observable<Message> oMessage) {

    }

    @Override
    public boolean matchesTarget(String key) {
        return PushType.isMyOrderPush(key);
    }*/
}
