package pl.mobilemanagement.izarzadca.common.user.token;

import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;

public class TokenDataSource {

    private static final String KEY = "token";
    private final DataSourceRepository repository;

    public TokenDataSource(DataSourceRepository repository) {
        this.repository = repository;
    }

    public String getTokenInfo() {
        return repository.readString(KEY);
    }

    public void saveTokenInfo(String token) {
        repository.write(KEY, token);
    }

    public void clear() {
        repository.clear(KEY);
    }

    public boolean hasToken() {
        return repository.has(KEY);
    }
}