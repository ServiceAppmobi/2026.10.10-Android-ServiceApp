package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model;

import java.io.Serializable;

public class ServiceGroup implements Serializable {
    public final String serviceGroupId;
    public final String name;

    public ServiceGroup(String serviceGroupId, String name) {
        this.serviceGroupId = serviceGroupId;
        this.name = name;
    }
}
