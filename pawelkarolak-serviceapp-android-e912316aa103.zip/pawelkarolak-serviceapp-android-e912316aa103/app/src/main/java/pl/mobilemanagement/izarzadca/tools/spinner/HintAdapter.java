package pl.mobilemanagement.izarzadca.tools.spinner;

import android.widget.AutoCompleteTextView;

import java.util.ArrayList;
import java.util.List;
import pl.mobilemanagement.izarzadca.common.AutoTextSpinnerArrayAdapter;
import pl.mobilemanagement.izarzadca.common.SpinnerTextView;

public class HintAdapter {

    public static void initEmpty(SpinnerTextView betterSpinner) {
        AutoTextSpinnerArrayAdapter adapter =
          new AutoTextSpinnerArrayAdapter(betterSpinner.getContext(), new ArrayList<>(), null, android.R.layout.simple_list_item_1, 0);
        betterSpinner.setAdapter(adapter);
    }

    public static void setHintData(SpinnerTextView betterSpinner, List<? extends SpinnerItem> data) {
        betterSpinner.setAdapter(new AutoTextSpinnerArrayAdapter(betterSpinner.getContext(), data, null, android.R.layout.simple_list_item_1, 0));
    }

    public static void setHintData(AutoCompleteTextView autoCompleteTextView, List<? extends SpinnerItem> data) {
        autoCompleteTextView.setAdapter(new AutoTextSpinnerArrayAdapter(autoCompleteTextView.getContext(), data, null, android.R.layout.simple_list_item_1, 0));
    }
}