package pl.mobilemanagement.izarzadca.common.model.api;

public class ContactApiModel {
    public String name;
    public String surname;
    public String phone;
    public String email;
    public int notificationType;

    public ContactApiModel(String name, String surname, String phone, String email, int notificationType) {
        this.name = name;
        this.surname = surname;
        this.phone = phone;
        this.email = email;
        this.notificationType = notificationType;
    }
}