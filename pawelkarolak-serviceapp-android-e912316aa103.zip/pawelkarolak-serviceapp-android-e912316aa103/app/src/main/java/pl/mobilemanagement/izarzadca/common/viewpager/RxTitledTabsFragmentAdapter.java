package pl.mobilemanagement.izarzadca.common.viewpager;

import android.content.Context;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import java.util.List;

public class RxTitledTabsFragmentAdapter<T extends TitledTabFragment> extends TitledTabsFragmentAdapter<T> {

    private T currentObject;
    private FragmentChangeListener<T> listener;

    public RxTitledTabsFragmentAdapter(Context context, @NonNull FragmentManager fm, @NonNull List<T> tabFragments) {
        super(context, fm, tabFragments);
    }

    @Override
    public void setPrimaryItem(ViewGroup container, int position, Object object) {
        super.setPrimaryItem(container, position, object);
        if (currentObject != object) {
            currentObject = (T) object;
            listener.onPagePrimary(currentObject);
        }
    }

    public void addOnPageChangeListener(FragmentChangeListener<T> listener) {
        this.listener = listener;
    }
}