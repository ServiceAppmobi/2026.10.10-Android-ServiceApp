package pl.mobilemanagement.izarzadca.common.user.token;

import pl.mobilemanagement.izarzadca.BuildConfig;
import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;
import pl.mobilemanagement.izarzadca.common.user.AccountType;

public class AccountTypeDataSource {

    private static final String KEY = "account_type";
    private final DataSourceRepository repository;

    public static final String COUNTRY_ID = "country_id";

    public static final String SERVER_URL_EU = "https://api-mobile-eu.propertiesplatform.com/api/";

    public static final String BANNER_URL = "https://serviceapp.mobi/";

    public static final String VERSION_CODE = "version_code";

    public AccountTypeDataSource(DataSourceRepository repository) {
        this.repository = repository;
    }

    public AccountType getAccountType() {
        return repository.read(KEY, AccountType.class);
    }

    public boolean isValidType() {
        return getAccountType() != null;
    }

    public void saveAccountType(AccountType accountType) {
        repository.write(KEY, accountType, AccountType.class);
    }

    public void clear() {
        repository.clear(KEY);
    }

    public void setCountry(String countryId) {
        repository.writeSync(COUNTRY_ID, countryId);
    }

    public String getServerUrl() {
        return SERVER_URL_EU;
    }

    public boolean hasCountry() {
        String countryId = repository.readString(COUNTRY_ID);
        return countryId != null && !countryId.isEmpty();
    }

    public String getBannerUrl() {
        return BANNER_URL;
    }

    public boolean isNeedToLogout() {
        int versionCode = repository.readInt(VERSION_CODE);
        return versionCode <= 82 && BuildConfig.VERSION_CODE > 82;
    }

    public void setVersionCode(int versionCode) {
        repository.write(VERSION_CODE, versionCode);
    }
}