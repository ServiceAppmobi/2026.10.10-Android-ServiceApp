package pl.mobilemanagement.izarzadca.common.model.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import pl.mobilemanagement.izarzadca.common.user.AccountType;

public class AccountTypeName implements Serializable {
    @Expose
    @SerializedName("id")
    public AccountType type;
    @Expose
    @SerializedName("name")
    public String name;

    public AccountTypeName(AccountType type) {
        this.type = type;
    }

    public AccountTypeName(AccountType type, String name) {
        this(type);
        this.name = name;
    }
}
