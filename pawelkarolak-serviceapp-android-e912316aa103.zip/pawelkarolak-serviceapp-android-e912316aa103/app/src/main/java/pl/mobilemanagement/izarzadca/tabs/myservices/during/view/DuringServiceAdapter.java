package pl.mobilemanagement.izarzadca.tabs.myservices.during.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.RowAdapter;
import pl.mobilemanagement.izarzadca.databinding.ServiceDuringRowBinding;
import pl.mobilemanagement.izarzadca.tabs.myservices.ServiceDetailsClickListener;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderServiceType;
import pl.mobilemanagement.izarzadca.tabs.myservices.during.model.DuringServiceOrder;
import pl.mobilemanagement.izarzadca.tools.DateUtil;
import rx.Observable;
import rx.subjects.BehaviorSubject;

class DuringServiceAdapter extends RowAdapter<DuringServiceOrder, DuringServiceAdapter.VH> {
    private final BehaviorSubject<ServiceOrder> listener = BehaviorSubject.create();
    private final ServiceDetailsClickListener serviceDetailsClickListener;

    public DuringServiceAdapter(ServiceDetailsClickListener serviceDetailsClickListener) {
        this.serviceDetailsClickListener = serviceDetailsClickListener;
    }

    public Observable<ServiceOrder> orderObservable() {
        return listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ServiceDuringRowBinding binding = ServiceDuringRowBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new VH(binding);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        holder.bind(getItem(position));
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).id.hashCode();
    }

    class VH extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final ServiceDuringRowBinding binding;

        private DuringServiceOrder item;

        VH(ServiceDuringRowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            binding.getRoot().setOnClickListener(this);
            binding.serviceDetails.setOnClickListener(this);
        }

        public void bind(DuringServiceOrder item) {
            this.item = item;
            String formatDateRange = DateUtil.getFormattedDate(binding.getRoot().getContext(), item.startDateTime, item.endDateTime);
            int number = getBindingAdapterPosition() + 1;
            String title = binding.getRoot().getContext().getResources().getString(R.string.text_with_number, number, item.serviceName);
            binding.title.setText(title);
            binding.distance.setText(item.distanceToCustomer);
            binding.dateValue.setText(formatDateRange);
            binding.addressValue.setText(item.getAddress());
        }

        @Override
        public void onClick(View v) {
            if (v == binding.getRoot())
                listener.onNext(item);
            else if (v == binding.serviceDetails)
                serviceDetailsClickListener.onOrderDetailsClick(item.id, OrderServiceType.DURING);
        }
    }
}
