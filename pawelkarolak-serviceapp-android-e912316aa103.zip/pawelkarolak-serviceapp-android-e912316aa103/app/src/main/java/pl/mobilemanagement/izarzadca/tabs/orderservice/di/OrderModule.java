package pl.mobilemanagement.izarzadca.tabs.orderservice.di;

import dagger.Module;
import dagger.Provides;
import pl.mobilemanagement.izarzadca.common.di.api.Auth;
import pl.mobilemanagement.izarzadca.tabs.orderservice.api.OrderServiceApi;
import retrofit2.Retrofit;

@OrderScope
@Module
public class OrderModule {

    @Provides
    @OrderScope
    public OrderServiceApi providesOrderApi(@Auth Retrofit retrofit) {
        return retrofit.create(OrderServiceApi.class);
    }
}