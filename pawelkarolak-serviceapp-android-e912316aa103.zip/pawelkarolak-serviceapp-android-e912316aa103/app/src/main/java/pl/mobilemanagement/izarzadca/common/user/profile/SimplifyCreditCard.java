package pl.mobilemanagement.izarzadca.common.user.profile;

import java.io.Serializable;

public class SimplifyCreditCard implements Serializable {
    public final String expirationDate;
    public final String cardType;
    public final String number;

    public SimplifyCreditCard(String expirationDate, String cardType, String number) {
        this.expirationDate = expirationDate;
        this.cardType = cardType;
        this.number = number;
    }
}
