package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models.Payment
import javax.inject.Inject

class HomeTabViewModel: ViewModel() {

    enum class Balance {
        BALANCE, MONTHLY_RENT
    }

    private val _selectedOption = MutableLiveData(Balance.BALANCE)
    val selectedOption: LiveData<Balance> = _selectedOption

    fun setOptionByIndex(index: Int) {
        _selectedOption.value = Balance.values()[index]
    }

}