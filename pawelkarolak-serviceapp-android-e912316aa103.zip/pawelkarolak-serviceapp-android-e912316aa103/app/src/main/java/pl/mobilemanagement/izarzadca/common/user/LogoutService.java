package pl.mobilemanagement.izarzadca.common.user;

import pl.mobilemanagement.izarzadca.common.user.profile.UserProfileDataSource;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import rx.Completable;

public class LogoutService {
    final private TokenDataSource tokenDataSource;
    final private UserProfileDataSource userDataSource;

    public LogoutService(TokenDataSource tokenDataSource, UserProfileDataSource userDataSource) {
        this.tokenDataSource = tokenDataSource;
        this.userDataSource = userDataSource;
    }

    public void clearPersonalData() {
        tokenDataSource.clear();
        userDataSource.clear();
    }

    public Completable logoutRemovePushKey() {
        return Completable.fromAction(this::clearPersonalData);
    }
}
