package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.impl;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.RowAdapter;
import pl.mobilemanagement.izarzadca.databinding.ReviewRowBinding;
import pl.mobilemanagement.izarzadca.tabs.orderservice.model.ProviderOpinionsApiModel;

class CompanyOpionAdapter extends RowAdapter<ProviderOpinionsApiModel, CompanyOpionAdapter.VH> {

    @NotNull
    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.review_row, parent, false));
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        holder.bind(getItem(position));
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).hashCode();
    }

    static class VH extends RecyclerView.ViewHolder {

        private final ReviewRowBinding binding = ReviewRowBinding.bind(itemView);

        VH(View itemView) {
            super(itemView);
        }

        public void bind(ProviderOpinionsApiModel item) {
            binding.opinionName.setText(item.name);
            binding.serviceRating.setRating(item.rating);
            binding.serviceRateOpinion.setText(item.opinion);
        }
    }
}
