package pl.mobilemanagement.izarzadca.common.notification;

import android.os.Bundle;

public class Push {
    public final String id;
    public final PushType pushType;

    public Push(String id, PushType pushType) {
        this.id = id;
        this.pushType = pushType;
    }

    public static Push parsePushMessage(String typeKey, Bundle payload) {
        final PushType pushType = PushType.parseOf(typeKey);
        final String orderId = payload.getString("id");
        return new Push(orderId, pushType);
    }
}
