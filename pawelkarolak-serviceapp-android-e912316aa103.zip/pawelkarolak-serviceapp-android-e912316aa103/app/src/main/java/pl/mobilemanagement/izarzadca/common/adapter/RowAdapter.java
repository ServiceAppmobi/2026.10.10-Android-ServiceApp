package pl.mobilemanagement.izarzadca.common.adapter;

import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public abstract class RowAdapter<T, K extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<K> {
    private final List<T> dataList = new ArrayList<>();

    public RowAdapter() {
        setHasStableIds(true);
    }

    public T getItem(int position) {
        return dataList.get(position);
    }

    public void setDataList(List<T> data) {
        dataList.clear();
        dataList.addAll(data);
        notifyDataSetChanged();
    }

    protected List<T> getDataList() {
        return dataList;
    }

    @Override
    public final int getItemCount() {
        return dataList.size();
    }
}
