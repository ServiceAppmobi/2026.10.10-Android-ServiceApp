package pl.mobilemanagement.izarzadca.common;

public interface BackHandlerInterface {
    boolean onBackPressed();
}
