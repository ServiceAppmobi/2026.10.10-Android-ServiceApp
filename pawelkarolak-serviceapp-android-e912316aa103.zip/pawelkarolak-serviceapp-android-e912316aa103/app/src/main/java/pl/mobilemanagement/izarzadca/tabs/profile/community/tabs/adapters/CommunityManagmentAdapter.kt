package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.adapters

import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DiffUtil.ItemCallback
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.databinding.ItemCommunityManagmentBinding
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.CommunityBoardMembers

class CommunityManagmentAdapter : ListAdapter<CommunityBoardMembers, CommunityManagmentAdapter.CommunityManagmentViewHolder>(DIFF_UTIL) {

    companion object {
        val DIFF_UTIL = object : ItemCallback<CommunityBoardMembers>() {
            override fun areItemsTheSame(oldItem: CommunityBoardMembers, newItem: CommunityBoardMembers): Boolean {
                return oldItem.email == newItem.email
            }

            override fun areContentsTheSame(oldItem: CommunityBoardMembers, newItem: CommunityBoardMembers): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommunityManagmentViewHolder {
        val binding = ItemCommunityManagmentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CommunityManagmentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CommunityManagmentViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CommunityManagmentViewHolder(
        private val binding: ItemCommunityManagmentBinding
    ): RecyclerView.ViewHolder(binding.root), View.OnClickListener, DialogInterface.OnClickListener {

        private val alertDialog = AlertDialog.Builder(binding.root.context, R.style.AlertDialog).create()

        private var item: CommunityBoardMembers? = null

        init {
            binding.details.setOnClickListener(this)
            val resources = binding.root.context.resources
            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, resources.getString(R.string.tab_close), this)
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, resources.getString(R.string.tab_call), this)
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, resources.getString(R.string.tab_email), this)
        }

        fun bind(item: CommunityBoardMembers) {
            this.item = item
            binding.title.text = item.fullName
            binding.position.text = item.position
            binding.emailValue.text = item.email
            binding.phoneValue.text = item.phone
        }

        override fun onClick(dialog: DialogInterface?, which: Int) {
            when (which) {
                AlertDialog.BUTTON_NEGATIVE -> dialog?.dismiss()
                AlertDialog.BUTTON_POSITIVE -> {
                    val callIntent = Intent(Intent.ACTION_VIEW)
                    callIntent.data = Uri.parse("tel:${item!!.phone}")
                    binding.root.context.startActivity(callIntent)
                }
                AlertDialog.BUTTON_NEUTRAL -> {
                    val emailIntent = Intent(Intent.ACTION_SENDTO)
                    emailIntent.data = Uri.parse("mailto:${item!!.email}")
                    emailIntent.putExtra(Intent.EXTRA_SUBJECT, "iZarzadca")
                    emailIntent.putExtra(Intent.EXTRA_TEXT, "Your message")
                    binding.root.context.startActivity(Intent.createChooser(emailIntent, "Send email..."))
                }
            }
        }

        override fun onClick(v: View?) {
            if (v == binding.details) {
                alertDialog.setTitle(item?.fullName)
                alertDialog.show()
            }
        }
    }

}