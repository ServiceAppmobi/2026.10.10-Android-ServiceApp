package pl.mobilemanagement.izarzadca.start_screen.register.pages.phoneactivate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CheckCodeVerification {
    @Expose
    @SerializedName("code")
    private String code;

    public CheckCodeVerification(String codeVerification) {
        this.code = codeVerification;
    }
}
