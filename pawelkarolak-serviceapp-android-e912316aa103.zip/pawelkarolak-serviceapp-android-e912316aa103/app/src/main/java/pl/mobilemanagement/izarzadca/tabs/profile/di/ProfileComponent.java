package pl.mobilemanagement.izarzadca.tabs.profile.di;

import dagger.Component;
import pl.mobilemanagement.izarzadca.common.di.ApplicationComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.ProfileTabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.creditcard.create.view.AddCreditCardActivity;
import pl.mobilemanagement.izarzadca.tabs.profile.creditcard.detail.DetailsCreditCardActivity;
import pl.mobilemanagement.izarzadca.tabs.profile.edit.EditProfileActivity;
import pl.mobilemanagement.izarzadca.tabs.profile.password.ChangePasswordActivity;
import pl.mobilemanagement.izarzadca.tabs.profile.promote.PromoteServiceActivity;

@ProfileScreenScope
@Component(dependencies = ApplicationComponent.class, modules = ProfileModule.class)
public interface ProfileComponent {
    void inject(ProfileTabFragment profileTabFragment);

    void inject(EditProfileActivity editProfileActivity);

    void inject(DetailsCreditCardActivity detailsCreditCardActivity);

    void inject(AddCreditCardActivity addCreditCardActivity);

    void inject(ChangePasswordActivity changePasswordActivity);
}
