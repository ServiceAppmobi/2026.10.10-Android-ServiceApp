package pl.mobilemanagement.izarzadca.common.viewpager;

import rx.Observable;
import rx.Subscriber;

final public class AdapterPageChangeOnSubscribe<T extends TitledTabFragment> implements Observable.OnSubscribe<T> {
    final RxTitledTabsFragmentAdapter<T> adapter;

    public AdapterPageChangeOnSubscribe(RxTitledTabsFragmentAdapter<T> adapter) {
        this.adapter = adapter;
    }

    @Override
    public void call(final Subscriber<? super T> subscriber) {
        final FragmentChangeListener<T> listener = fragment -> {
            if (!subscriber.isUnsubscribed()) {
                subscriber.onNext(fragment);
            }
        };
        adapter.addOnPageChangeListener(listener);

    }
}