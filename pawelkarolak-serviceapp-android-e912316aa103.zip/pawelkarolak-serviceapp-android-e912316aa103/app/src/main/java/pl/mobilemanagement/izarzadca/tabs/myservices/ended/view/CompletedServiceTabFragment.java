package pl.mobilemanagement.izarzadca.tabs.myservices.ended.view;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.databinding.RecyclerViewFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.myservices.ServiceDetailsClickListener;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceFragment;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.ServiceOrder;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.ProviderOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderDetailsActivity;
import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderServiceType;
import pl.mobilemanagement.izarzadca.tabs.myservices.di.DaggerMyServicesComponent;
import pl.mobilemanagement.izarzadca.tabs.myservices.ended.model.CompletedOrderService;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.LCE;
import pl.mobilemanagement.izarzadca.tools.Recycler;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;


public class CompletedServiceTabFragment extends ServiceFragment<CompletedOrderService> implements
        LCE<CompletedOrderService>, ServiceDetailsClickListener, View.OnClickListener {
    public Subscription subscription;
    @Inject
    ProviderOrdersApi providerOrdersApi;
    public Observable<List<CompletedOrderService>> completeOrderObservable = Observable.defer(this::createCompleteOrderObservable).share();

    private RecyclerViewFrameBinding binding;

    private final CompletedServiceAdapter completedServicesAdapter = new CompletedServiceAdapter(this);
    private EarthlyLoadingDialog earthlyDialog;

    public CompletedServiceTabFragment() {
        DaggerMyServicesComponent.builder().applicationComponent(App.component).build().inject(this);
    }

    @Override
    public int getTitleResource() {
        return R.string.my_services_tab_ended;
    }

    @Override
    protected int getLayout() {
        return R.layout.recycler_view_frame;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding = RecyclerViewFrameBinding.bind(view);
        initRecyclerView();
        binding.btnRefresh.setOnClickListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchCompletedServices();
    }

    private void fetchCompletedServices() {
        Rx.safeUnsubscribe(subscription);
        subscription = completeOrderObservable
                .compose(Rx.applyLCE(this))
                .compose(Rx.applyDataLoader(this))
                .subscribe(completedOrderServices -> {
                }, Throwable::new);
    }

    @Override
    public void setData(List<CompletedOrderService> data) {
        completedServicesAdapter.setDataList(data);
    }

    @Override
    public void showProgressBar() {
        earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager());
//        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgressBar() {
        ProgressHelper.safeDismiss(earthlyDialog);
//        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void hideError() {
        binding.errorGroup.setVisibility(View.GONE);
    }

    @Override
    public void showEmptyListError() {
        binding.errorGroup.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.complete_order_empty);
    }

    @Override
    public void showConnectionError() {
        binding.errorGroup.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.list_view_connection_error);
    }

    @Override
    public Observable<ServiceOrder> orderClickObservable() {
        return completedServicesAdapter.orderObservable();
    }

    @NonNull
    private Observable<List<CompletedOrderService>> createCompleteOrderObservable() {
        return providerOrdersApi.getCompletedOrders()
                .compose(Rx.applySchedulers());
    }

    private void initRecyclerView() {
        binding.listRecyclerView.setAdapter(completedServicesAdapter);
    }

    @Override
    public Observable<List<CompletedOrderService>> getOrdersObservable() {
        return completeOrderObservable;
    }

    @Override
    public void onOrderDetailsClick(String orderId, OrderServiceType orderType) {
        OrderDetailsActivity.start(getActivity(), orderId, orderType);
    }

    @Override
    public void onClick(View v) {
        if (v == binding.btnRefresh) {
            fetchCompletedServices();
        }
    }

    /*@Override
    public void onTargetNotification(Observable<Message> oMessage) {
        oMessage.subscribe(message -> {
            fetchCompletedServices();
        });
    }

    @Override
    public void onMismatchTargetNotification(Observable<Message> oMessage) {

    }

    @Override
    public boolean matchesTarget(String key) {
        return PushType.parseOf(key) == PushType.PROVIDER_SERVICE_CLOSED || PushType.parseOf(key) == PushType.PROVIDER_SERVICE_RATED;
    }*/

}
