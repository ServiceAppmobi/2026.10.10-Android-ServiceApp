package pl.mobilemanagement.izarzadca.common.model.api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import pl.mobilemanagement.izarzadca.common.model.entity.AccountTypeName;
import pl.mobilemanagement.izarzadca.common.model.entity.Country;
import pl.mobilemanagement.izarzadca.common.user.AccountType;
import pl.mobilemanagement.izarzadca.start_screen.register.RegisterBuilder;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model.PersonalData;

public class CustomerRegister {

    @SerializedName("Phone")
    @Expose
    public String phone;

    @SerializedName("password")
    @Expose
    public String password;

    @SerializedName("code")
    @Expose
    public String code;

    @SerializedName("login")
    @Expose
    public String login;

    @SerializedName("name")
    @Expose
    public String name;

    @SerializedName("surname")
    @Expose
    public String surname;

    @SerializedName("Email")
    @Expose
    public String email;

    @SerializedName("postalCode")
    @Expose
    public String postCode = "";

    @SerializedName("city")
    @Expose
    public String city = "";

    @SerializedName("street")
    @Expose
    public String street = "";

    @SerializedName("number")
    @Expose
    public String number = "";

    @SerializedName("countryId")
    @Expose
    public String countryId;

    @SerializedName("countryCode")
    @Expose
    public String countryCode;

    @SerializedName("accountType")
    @Expose
    public AccountType accountType;

    @Expose
    @SerializedName("lat")
    public Double latitude;

    @Expose
    @SerializedName("lng")
    public Double longitude;

    public static CustomerRegister create(RegisterBuilder registerBuilder) {
        CustomerRegister customerRegister = new CustomerRegister();
        customerRegister.login = registerBuilder.getUserName();
        customerRegister.password = registerBuilder.getPassword();
        customerRegister.phone = registerBuilder.getPhoneNumberWithPrefix();
        customerRegister.code = registerBuilder.getVerificationCode();
        AccountTypeName accountTypeName = registerBuilder.getAccountTypeName();
        customerRegister.accountType = accountTypeName.type;
        Country country = registerBuilder.getCountry();
        customerRegister.setCountryInfo(country);
        customerRegister.latitude = registerBuilder.getLatitude();
        customerRegister.longitude = registerBuilder.getLongitude();
        customerRegister.fillPersonalData(registerBuilder.getPersonalData());
        return customerRegister;
    }

    private void fillPersonalData(PersonalData personalData) {
        surname = personalData.getSurName();
        name = personalData.getUserName();
        email = personalData.getEmail();
    }

    private void setCountryInfo(Country c) {
        this.countryId = c.id;
        this.countryCode = c.areaCode;
    }
}