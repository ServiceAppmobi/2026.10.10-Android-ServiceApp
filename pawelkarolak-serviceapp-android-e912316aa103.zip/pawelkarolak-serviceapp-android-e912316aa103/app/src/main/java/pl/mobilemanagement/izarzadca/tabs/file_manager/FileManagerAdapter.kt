package pl.mobilemanagement.izarzadca.tabs.file_manager

import android.graphics.Color
import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.databinding.ItemFileBinding

class FileManagerAdapter(
    private val listener: Listener
): RecyclerView.Adapter<FileManagerAdapter.FileViewHolder>() {

    interface Listener {
        fun onItemClick(file: File)
    }

    private var files = emptyList<File>()

    fun submitList(files: List<File>) {
        this.files = files
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = files.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val binding = ItemFileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FileViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        holder.bind(files[position])
    }

    inner class FileViewHolder(
        private val binding: ItemFileBinding
    ) : RecyclerView.ViewHolder(binding.root), View.OnClickListener {

        private var file: File? = null

        init {
            binding.root.setOnClickListener(this)
        }

        fun bind(file: File) {
            this.file = file
            binding.ivIcon.clearColorFilter()
            binding.tvFileName.text = file.name
            binding.tvDate.text = file.lastModified
            val iconRes = when (file.extension.lowercase()) {
                "doc", "docx" -> R.drawable.file_word_regular
                "pdf" -> R.drawable.file_pdf_regular
                "jpg", "jpeg", "bmp", "gif", "png", "webp" -> R.drawable.file_image_regular
                "mp3", "wav", "3gp", "amr", "ogg" -> R.drawable.file_audio_regular
                "ppt", "pptx", "pptm" -> R.drawable.file_powerpoint_regular
                "xls", "xlsx", "xlsm" -> R.drawable.file_excel_regular
                "txt" -> R.drawable.file_lines_regular
                "mp4", "mov", "wmv", "webm", "avi", "flv", "mkv", "mts" -> R.drawable.file_video_regular
                "html", "css", "json" -> {
                    val colorRes = when (file.extension) {
                        "html" -> Color.parseColor("#fd7e14")
                        "css" -> Color.parseColor("#0168fa")
                        else -> Color.parseColor("#6f42c1")
                    }
                    binding.ivIcon.setColorFilter(ContextCompat.getColor(binding.root.context, colorRes), PorterDuff.Mode.SRC_IN)
                    R.drawable.file_code_regular
                }
                else -> R.drawable.file_regular
            }
            binding.ivIcon.setImageResource(iconRes)
        }

        override fun onClick(v: View?) {
            when (v) {
                binding.root -> file?.let { listener.onItemClick(it) }
            }
        }
    }
}