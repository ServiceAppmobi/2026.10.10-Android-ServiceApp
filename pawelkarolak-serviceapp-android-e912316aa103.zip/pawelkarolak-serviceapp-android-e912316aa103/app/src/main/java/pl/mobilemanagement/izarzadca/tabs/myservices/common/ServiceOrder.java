package pl.mobilemanagement.izarzadca.tabs.myservices.common;

import com.google.android.gms.maps.model.LatLng;

import java.util.Date;

import static java.lang.Double.parseDouble;

public class ServiceOrder {

    public String lat;
    public String lng;
    public String id;
    public String serviceName;
    public boolean paymentStarted;
    public Date startDateTime;
    public Date endDateTime;

    public LatLng getLatLng() {
        return new LatLng(parseDotDouble(lat), parseDotDouble(lng));
    }

    private double parseDotDouble(String wrongFormatDouble) {
        return parseDouble(wrongFormatDouble.replace(',', '.'));
    }
}
