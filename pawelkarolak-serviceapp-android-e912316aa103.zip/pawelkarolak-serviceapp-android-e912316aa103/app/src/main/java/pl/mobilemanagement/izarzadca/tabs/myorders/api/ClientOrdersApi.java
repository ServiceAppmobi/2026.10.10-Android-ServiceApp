package pl.mobilemanagement.izarzadca.tabs.myorders.api;

import java.util.List;

import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.model.api.OrderId;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete.model.CompleteOrder;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.ask_again.AskOrderAgainApiModel;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.rate_order.RateOrderApiModel;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import rx.Observable;

public interface ClientOrdersApi {

    @GET("Client/GetPendingOrders")
    public Observable<List<Order>> getPendingOrders();

    @GET("Client/GetAcceptedOrders")
    public Observable<List<Order>> getAcceptedOrders();

    @GET("Client/GetCompletedOrders")
    public Observable<List<CompleteOrder>> getCompletedOrders();

    @POST("Client/DeletePendingOrder")
    public Observable<Void> deletePendingOrder(@Body OrderId orderId);

    @POST("Client/CloseOrder")
    public Observable<Void> closeCompletedOrder(@Body OrderId orderId);

    @POST("Client/SetOrderOpinion")
    public Observable<Void> postOpinionAboutOrder(@Body RateOrderApiModel rateOrderApiModel);

    @POST("Client/SetDatesAndIssueDescription")
    public Observable<Void> postDatesAndIssueDescription(@Body AskOrderAgainApiModel dateDescOrder);

}
