package pl.mobilemanagement.izarzadca.common.user.profile;

import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tabs.profile.api.UploadUserPhoto;
import pl.mobilemanagement.izarzadca.tabs.profile.api.UserDataApiModel;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class UserService {
    private final ProfileApi profileApi;
    private final UserProfileDataSource userDataSource;
    private final AccountTypeDataSource accountTypeDataSource;

    public UserService(ProfileApi profileApi, UserProfileDataSource userDataSource, AccountTypeDataSource accountTypeDataSource) {
        this.profileApi = profileApi;
        this.userDataSource = userDataSource;
        this.accountTypeDataSource = accountTypeDataSource;
    }

    private Observable<UserProfile> getCachedUserProfile() {
        if (userDataSource.hasProfile()) {
            return Observable.fromCallable(userDataSource::getUserProfile);
        } else {
            return Observable.empty();
        }
    }

    public Observable<UserProfile> getProfileFromApi() {
        return profileApi.getUserData()
                .map(UserDataApiModel::toPersonalData)
                .doOnNext(userDataSource::saveProfile)
                .doOnNext(userProfile -> accountTypeDataSource.saveAccountType(userProfile.accountType))
                .subscribeOn(Schedulers.io());
    }

    public Observable<UserProfile> getProfileFromCacheAndApi() {
        return Observable.concat(
                getCachedUserProfile()
                        .subscribeOn(Schedulers.immediate())
                        .observeOn(AndroidSchedulers.mainThread()),
                getProfileFromApi()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
        );
    }

    public Observable<OrderAcceptCost> getOrderAcceptCost() {
        return profileApi.getOrderAcceptCost()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<Void> uploadUserImage(UploadUserPhoto uploadUserPhoto) {
        return profileApi.uploadUserImage(uploadUserPhoto)
                .subscribeOn(Schedulers.immediate());
    }

    public Observable<Void> deleteAccount() {
        return profileApi.deleteAccount()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    public Observable<Void> deleteUserImage() {
        return profileApi.deleteUserImage()
                .subscribeOn(Schedulers.immediate());
    }

    public Observable<UserProfile> getProfilePreferOnlyCache() {
        return Observable.concat(getCachedUserProfile(), getProfileFromApi()).first();
    }

}
