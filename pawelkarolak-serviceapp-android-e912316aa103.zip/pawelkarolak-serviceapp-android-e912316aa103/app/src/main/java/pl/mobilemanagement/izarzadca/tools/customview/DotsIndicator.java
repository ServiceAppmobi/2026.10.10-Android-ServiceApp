package pl.mobilemanagement.izarzadca.tools.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import pl.mobilemanagement.izarzadca.R;


public class DotsIndicator extends LinearLayout {
    private final static int DEFAULT_INDICATOR_WIDTH = 5;
    private final static int DEFAULT_INDICATOR_LINE_WIDTH = 10;
    private final static int DEFAULT_INDICATOR_LINE_HEIGHT = 2;

    private ViewPager mViewpager;
    private View currentSelectedDot;
    private int mIndicatorRadius = -1;
    private int mIndicatorLineWidth = -1;
    private int mIndicatorLineHeight = -1;
    private int mIndicatorBackgroundResId = R.drawable.blue_dot;
    private int mIndicatorUnselectedBackgroundResId = R.drawable.blue_dot;
    private int mIndicatorLineColor;

    public DotsIndicator(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        handleTypedArray(context, attrs);
        checkIndicatorConfig();
    }

    private void checkIndicatorConfig() {
        mIndicatorRadius = (mIndicatorRadius < 0) ? dip2px(DEFAULT_INDICATOR_WIDTH) : mIndicatorRadius;
        mIndicatorLineWidth = (mIndicatorLineWidth < 0) ? dip2px(DEFAULT_INDICATOR_LINE_WIDTH) : mIndicatorLineWidth;
        mIndicatorLineHeight = (mIndicatorLineHeight < 0) ? dip2px(DEFAULT_INDICATOR_LINE_HEIGHT) : mIndicatorLineHeight;

    }


    private void handleTypedArray(Context context, AttributeSet attrs) {
        if (attrs == null) {
            return;
        }

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.DotsIndicator);
        mIndicatorRadius =
                typedArray.getDimensionPixelSize(R.styleable.DotsIndicator_ci_radius, -1);
        mIndicatorLineWidth =
                typedArray.getDimensionPixelSize(R.styleable.DotsIndicator_ci_width, -1);
        mIndicatorLineColor =
                typedArray.getResourceId(R.styleable.DotsIndicator_ci_line_color, -1);
        mIndicatorBackgroundResId =
                typedArray.getResourceId(R.styleable.DotsIndicator_ci_drawable,
                        R.drawable.blue_dot);
        mIndicatorUnselectedBackgroundResId =
                typedArray.getResourceId(R.styleable.DotsIndicator_ci_drawable_unselected,
                        mIndicatorBackgroundResId);

        int orientation = typedArray.getInt(R.styleable.DotsIndicator_ci_orientation, -1);
        setOrientation(orientation == VERTICAL ? VERTICAL : HORIZONTAL);

        int gravity = typedArray.getInt(R.styleable.DotsIndicator_ci_gravity, -1);
        setGravity(gravity >= 0 ? gravity : Gravity.CENTER);

        typedArray.recycle();
    }


    public void setup(ViewPager viewPager) {
        this.mViewpager = viewPager;
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                selectDot(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        createDots();
        selectDot(mViewpager.getCurrentItem());
    }

    private void selectDot(int position) {
        final ViewGroup dotGroup = (ViewGroup) getChildAt(position);
        final View dotView = dotGroup.getChildAt(0);
        setColorDot(dotView, true);
        if (currentSelectedDot != null) {
            setColorDot(currentSelectedDot, false);
        }
        currentSelectedDot = dotView;
    }

    private void createDots() {
        final int count = mViewpager.getAdapter().getCount();
        for (int i = 0; i < count; i++) {
            LinearLayout group = new LinearLayout(getContext());
            group.setGravity(Gravity.CENTER_VERTICAL);
            addDot(group);
            if (i < count - 1) {
                addCenterLine(group);
            }
            addView(group);
        }
    }

    private void addDot(ViewGroup group) {
        CircleView dot = new CircleView(getContext(), null);
        dot.setBackgroundResource(mIndicatorUnselectedBackgroundResId);
        group.addView(dot, mIndicatorRadius, mIndicatorRadius);
    }

    private void setColorDot(View view, boolean isSelected) {
        view.setBackgroundResource(isSelected ? mIndicatorBackgroundResId : mIndicatorUnselectedBackgroundResId);
    }

    private void addCenterLine(ViewGroup group) {
        View view = new View(getContext());
        view.setBackgroundColor(ContextCompat.getColor(getContext(), mIndicatorLineColor));
        group.addView(view, mIndicatorLineWidth, mIndicatorLineHeight);
    }


    private int dip2px(float dpValue) {
        final float scale = getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }
}
