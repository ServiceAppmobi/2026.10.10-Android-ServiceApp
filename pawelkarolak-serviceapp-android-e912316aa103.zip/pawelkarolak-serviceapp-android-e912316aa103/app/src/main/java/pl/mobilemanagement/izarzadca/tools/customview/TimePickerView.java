package pl.mobilemanagement.izarzadca.tools.customview;

import android.app.TimePickerDialog;
import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

public class TimePickerView implements View.OnClickListener, TimePickerDialog.OnTimeSetListener {
    private TextView editText;
    private Context context;
    private TimeObject currentTimeObject;
    private Calendar calendar;

    public TimePickerView(Context context, TextView editText, Calendar calendar) {
        this.context = context;
        this.editText = editText;
        this.calendar = calendar;
        this.editText.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        TimePickerDialog dialog = new TimePickerDialog(context, this,
                calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE),
                true);
        dialog.show();
    }

    private void updateDisplay(int hourOfDay, int minute) {
        editText.setText(new StringBuilder().append(hourOfDay).append(":").append(minute));
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        currentTimeObject = new TimeObject(hourOfDay,minute);
        updateDisplay(hourOfDay, minute);
    }

    public TimeObject getTimeObject() {
        return currentTimeObject;
    }

    public static class TimeObject {
       public final int hourOfDay;
        public final int minute;

        public TimeObject(int hourOfDay, int minute) {

            this.hourOfDay = hourOfDay;
            this.minute = minute;
        }
    }
}