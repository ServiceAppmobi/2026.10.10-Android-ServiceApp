package pl.mobilemanagement.izarzadca.start_screen.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import java.util.Arrays;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.di.DaggerViewModelFactory;
import pl.mobilemanagement.izarzadca.common.notification.api.NotificationRegisterService;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.databinding.ActivityLoginBinding;
import pl.mobilemanagement.izarzadca.start_screen.forgot.ForgotActivity;
import pl.mobilemanagement.izarzadca.start_screen.login.di.LoginServiceApi;
import pl.mobilemanagement.izarzadca.start_screen.register.RegisterActivity;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.SelectCountryDialog;
import pl.mobilemanagement.izarzadca.tabs.MainActivity;
import pl.mobilemanagement.izarzadca.tabs.TabToMove;
import pl.mobilemanagement.izarzadca.tools.AdsBannerUtil;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.EditTextHelper;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import timber.log.Timber;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    @Inject
    TokenDataSource tokenDataSource;
    @Inject
    AccountTypeDataSource accountTypeDataSource;
    @Inject
    LoginServiceApi loginServiceApi;
    @Inject
    NotificationRegisterService notificationRegisterService;

    private AdsBannerUtil adsBannerUtil;

    private EarthlyLoadingDialog earthlyDialog = null;

    @Inject
    GoogleSignInClient googleSignInClient;

    @Inject
    DaggerViewModelFactory viewModelFactory;

    LoginViewModel viewModel;

    ActivityLoginBinding binding;

    private int signIn = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        App.component.inject(this);
        setContentView(binding.getRoot());

        if (savedInstanceState == null)
            signIn = 0;
        else
            signIn = savedInstanceState.getInt(SIGNIN_METHOD, 0);

        adsBannerUtil = new AdsBannerUtil(getApplication(), accountTypeDataSource);
        adsBannerUtil.init(binding.adsBanner.bottomAds);

        viewModel = ViewModelProviders.of(this, viewModelFactory).get(LoginViewModel.class);

        binding.loginButton.setOnClickListener(this);
        binding.forgotButton.setOnClickListener(this);
        binding.btnGoogle.setOnClickListener(this);
        binding.btnFacebook.setOnClickListener(this);
        binding.signUpText.setOnClickListener(this);

        getSupportFragmentManager().setFragmentResultListener(
                SelectCountryDialog.RESULT_KEY, this, (key, bundle) -> {
                String countryId = bundle.getString(SelectCountryDialog.RESULT_KEY);
                viewModel.setCountry(countryId);
                signIn();
            }
        );

        observe();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.login_button) {
            signIn = 2;
            signIn();
        } else if(id == R.id.forgot_button) {
            startActivity(new Intent(this, ForgotActivity.class));
        } else if(id == R.id.btnGoogle) {
            signIn = 0;
            signIn();
        } else if(id == R.id.btnFacebook) {
            signIn = 1;
            signIn();
        } else if(id == R.id.signUpText) {
            startActivity(new Intent(this, RegisterActivity.class));
        }
    }

    private void signIn() {
        if (signIn == 0)
            signInWithGoogle();
        else if (signIn == 1)
            viewModel.getLoginManager().logInWithReadPermissions(this, Arrays.asList("public_profile", "email"));
        else
            login();
    }

    private void login() {
        final String loginOrEmail = EditTextHelper.getText(binding.login);
        final String password = EditTextHelper.getText(binding.password);
        viewModel.login(loginOrEmail, password);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPause() {
        super.onPause();
        adsBannerUtil.releaseAdsView();
    }

    private void signInWithGoogle() {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        viewModel.getCallbackManager().onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            if (account != null) {
                viewModel.setGoogleAccount(account);
            }
        } catch (ApiException e) {
            Timber.e("signInResult:failed code=" + e.getStatusCode() + ", " + e.getMessage());
            Toast.makeText(this, "signInResult:failed code=" + e.getStatusCode() + ", " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void observe() {
        viewModel.isUserExist().observe(this, userState -> {
            if(userState == LoginViewModel.UserState.NEW_USER) {
                startRegistrationFlow();
            } else if(userState == LoginViewModel.UserState.USER_EXIST) {
                MainActivity.startActivity(this, TabToMove.PROFILE);
            } else if(userState == LoginViewModel.UserState.LOGIN_SUCCESS) {
                MainActivity.startActivity(LoginActivity.this, userState.isProvider() ? TabToMove.MY_SERVICES : TabToMove.ORDER_SERVICE);
            }
        });
        viewModel.getError().observe(this, error -> {
            if(!error.isEmpty())
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
        });
        viewModel.getLoading().observe(this, loading -> {
            if(loading && earthlyDialog == null)
                earthlyDialog = ProgressHelper.showEarthly(getSupportFragmentManager());
            else {
                ProgressHelper.safeDismiss(earthlyDialog);
                earthlyDialog = null;
            }
        });
        viewModel.getErrorDialog().observe(this, e -> {
            ApiErrorDialogHelper.show(this, e);
        });
    }

    private void startRegistrationFlow() {
        Intent intent = new Intent(this, RegisterActivity.class);
        intent.putExtra(RegisterActivity.SOCIAL_DATA_EXTRA, viewModel.getSocialData());
        startActivity(intent);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(SIGNIN_METHOD, signIn);
    }

    private static final int RC_SIGN_IN = 1;
    private static final String SIGNIN_METHOD = "SIGNIN_METHOD";

}
