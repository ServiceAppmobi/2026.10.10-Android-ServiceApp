package pl.mobilemanagement.izarzadca.start_screen.register.pages.company;

import android.app.Activity;
import android.content.Context;
import android.text.InputFilter;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.BuildConfig;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.SpinnerTextView;
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi;
import pl.mobilemanagement.izarzadca.common.model.api.CustomerRegister;
import pl.mobilemanagement.izarzadca.common.user.AccountType;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.databinding.RegisterCompanyDataBinding;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.PageRegisterView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.CompanyInfo;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.CompanyRegister;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model.PersonalData;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.AddressController;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.CompanyInfoController;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tabs.profile.edit.model.UpdateProviderApiModel;
import pl.mobilemanagement.izarzadca.tabs.profile.edit.model.UpdateUserApiModel;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;

import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;

import com.google.android.flexbox.FlexboxLayout;

public class CompanyDataView extends PageRegisterView {

    private static final int MAX_COMPANY_EMAIL_LENGTH = 200;
    private static final Pattern EMAIL_ADDRESS = Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+"
    );
    public final CompanyInfoController companyInfoController;
    private final AddressController addressController;

    public Subscription registerCompanySubscription;
    private Subscription updateUserDataSubscription;

    @Inject
    UnauthorizedApi unauthorizedApi;
    @Inject
    TokenDataSource tokenDataSource;

    EditText companyName;
    EditText companyNip;
    EditText companyEmail;
    EditText street;
    EditText flat;
    EditText postalCode;
    EditText city;
    TextView tlCompanyServices;
    FlexboxLayout companyServicesFrame;
    EditText companyDescription;
    SpinnerTextView companyRange;

    @Inject
    AccountTypeDataSource accountTypeDataSource;

    @Inject
    ProfileApi profileApi;

    public CompanyDataView(Context context, Activity activity) {
        super(context);

        App.component.inject(this);
        initViews();

        addressController = new AddressController(city, postalCode, street, flat);
        companyInfoController = new CompanyInfoController(unauthorizedApi, companyName, companyNip, tlCompanyServices, activity, companyDescription, companyRange, companyServicesFrame);
    }

    private void initViews() {
        RegisterCompanyDataBinding binding = RegisterCompanyDataBinding.bind(this);
        companyName = binding.companyName;
        companyNip = binding.companyNip;
        companyEmail = binding.companyEmail;
        street = binding.userDataStreet;
        flat = binding.userDataFlat;
        postalCode = binding.userDataPostal;
        city = binding.userDataCity;
        tlCompanyServices = binding.tlCompanyServices;
        companyServicesFrame = binding.companyServicesFrame;
        companyDescription = binding.companyDescription;
        companyRange = binding.companyRange;
        binding.next.setOnClickListener(v -> onNextButtonClick());

        companyEmail.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_COMPANY_EMAIL_LENGTH)});
    }

    private UpdateProviderApiModel createUserApiModel() {
        final String firstName = getCurrentBuilder().getPersonalData().getUserName();
        final String secondName = getCurrentBuilder().getPersonalData().getSurName();
        final String emailText = getCurrentBuilder().getPersonalData().getEmail();
        UpdateUserApiModel updateUserApiModel = new UpdateUserApiModel(
                firstName,
                secondName,
                emailText,
                addressController.getStreet(),
                addressController.getFlat(),
                addressController.getPostalCode(),
                addressController.getTown(),
                getCurrentBuilder().getCountry().id,
                getCurrentBuilder().getPhoneNumberWithPrefix()
        );
        updateUserApiModel.accountType = AccountType.SERVICE_PROVIDER;
        return new UpdateProviderApiModel(
            updateUserApiModel,
            companyInfoController.getCompanyName(),
            companyInfoController.getCompanyNIP(),
            companyInfoController.getDescription(),
            Long.parseLong(companyInfoController.getSelectedDistanceArea()),
            companyInfoController.getSelectedSericeTypes()
        );
    }

    @Override
    protected void onAttached() {
        companyInfoController.onCreate();
        restorePersonalInfo();
        boolean createdByPropertyManager = getCurrentBuilder().createdByPropertyManager;
        if(createdByPropertyManager && getCurrentBuilder().companyInfo != null) {
            CompanyInfo companyInfo = getCurrentBuilder().companyInfo;
            companyName.setText(companyInfo.companyName);
            companyNip.setText(companyInfo.companyNIP);
            companyEmail.setText(companyInfo.companyEmail);
            street.setText(companyInfo.companyAddress.getStreet());
            flat.setText(companyInfo.companyAddress.getFlat());
            postalCode.setText(companyInfo.companyAddress.getPostalCode());
            city.setText(companyInfo.companyAddress.getTown());
            companyDescription.setText(companyInfo.companyDesc);
            companyRange.setText(companyInfo.companyBusinessArea);
        }
    }

    @Override
    protected void onDetached() {
        super.onDetached();
        companyRange.dismissDropDown();
        companyInfoController.onDestroy();
        Rx.safeUnsubscribe(registerCompanySubscription, updateUserDataSubscription);
    }

    private void restorePersonalInfo() {
        final PersonalData personalData = pageViewListener.getCurrentBuilder().getPersonalData();
        companyEmail.setText(personalData.getEmail());
        companyName.setText(personalData.getUserName() + " " + personalData.getSurName());
    }

    void onNextButtonClick() {
        Validator validator = validateInput();
        if (validator.isValid()) {
            if (getCurrentBuilder().createdByPropertyManager) {
                UpdateProviderApiModel userDataApiModel = createUserApiModel();
                String accessToken = "Bearer " + getCurrentBuilder().accessToken;

                updateUserDataSubscription = profileApi
                        .updateProviderUserData(userDataApiModel, accessToken)
                        .compose(Rx.applySchedulers())
                        .compose(ProgressDialog.create(getContext()))
                        .toCompletable()
                        .subscribe(() -> {
                                tokenDataSource.saveTokenInfo(getCurrentBuilder().accessToken);
                                accountTypeDataSource.setVersionCode(BuildConfig.VERSION_CODE);
                                accountTypeDataSource.saveAccountType(getCurrentBuilder().getAccountTypeName().type);
                                pageViewListener.finishPaging();
                            }, throwable -> ApiErrorDialogHelper.show(getContext(), throwable)
                        );
            } else
                registerProvider();
        } else {
            ValidationErrorDialogHelper.show(getContext(), validator);
        }
    }

    private CompanyRegister createCompanyRegisterModel() {
        final CompanyInfo companyInfo = createCompanyInfo();
        final CustomerRegister customerRegisterModel = getCurrentBuilder().createCustomerRegisterModel();
        return CompanyRegister.create(customerRegisterModel, companyInfo);
    }

    private CompanyInfo createCompanyInfo() {
        return new CompanyInfo(companyInfoController.getCompanyName(),
                companyInfoController.getCompanyNIP(),
                getCompanyEmail(),
                companyInfoController.getDescription(),
                companyInfoController.getSelectedDistanceArea(),
                companyInfoController.getSelectedSericeTypes(),
                addressController.getAddress());
    }

    private String getCompanyEmail() {
        return getTrimmedText(companyEmail);
    }

    private void registerProvider() {
        updateAddressData();
        CompanyRegister companyRegister = createCompanyRegisterModel();
        registerCompanySubscription = unauthorizedApi.registerCompany(companyRegister)
                .compose(Rx.applySchedulers())
                .compose(ProgressDialog.create(getContext()))
                .subscribe(response -> {
                    tokenDataSource.saveTokenInfo(response.accessToken);
                    accountTypeDataSource.saveAccountType(response.accountType);
                    pageViewListener.finishPaging();
                    }, e -> ApiErrorDialogHelper.show(getContext(), e)
                );
    }

    private void updateAddressData() {
        final PersonalData personalData = getCurrentBuilder().getPersonalData();
        companyEmail.setText(personalData.getEmail());
        final PersonalData newPersonalData = new PersonalData(personalData.getUserName(), personalData.getSurName(), personalData.getEmail());
        getCurrentBuilder().setPersonalData(newPersonalData);
    }

    private Validator validateInput() {
        Validator validator = new Validator();
        if (getCompanyEmail().isEmpty() || !isValidEmail(getCompanyEmail())) {
            validator.addError(getString(R.string.user_data_wrong_email));
        }
        final Validator companyValidator = companyInfoController.validateInput();
        if (!companyValidator.isValid()) {
            validator.addError(companyValidator.getErrors());
        }
        final Validator addressValidator = addressController.validateInput();
        if (!addressValidator.isValid()) {
            validator.addError(addressValidator.getErrors());
        }
        return validator;
    }

    private boolean isValidEmail(String email) {
        return EMAIL_ADDRESS.matcher(email).matches();
    }

    @Override
    protected int titleResource() {
        return R.string.registration_company_data;
    }

    @Override
    protected int layoutResource() {
        return R.layout.register_company_data;
    }

}
