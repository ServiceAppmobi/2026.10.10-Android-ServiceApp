package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.rate_order;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RatingBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.jetbrains.annotations.NotNull;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.databinding.OrderMakeRateActivityBinding;
import pl.mobilemanagement.izarzadca.tabs.myorders.api.ClientOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myorders.di.DaggerMyOrdersComponent;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.EditTextHelper;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


public class OrderRateActivity extends AppCompatActivity {
    public static final String KEY_ORDER = "key_order";
    public Subscription subscription;

    @Inject
    ClientOrdersApi clientOrdersApi;

    RatingBar rateRatingBar;
    EditText rateDescription;

    private EarthlyLoadingDialog earthlyDialog;

    public static void start(Context context, String orderId) {
        Intent startIntent = new Intent(context, OrderRateActivity.class);
        startIntent.putExtra(KEY_ORDER, orderId);
        context.startActivity(startIntent);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OrderMakeRateActivityBinding binding = OrderMakeRateActivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        rateRatingBar = binding.rateRatingBar;
        rateDescription = binding.rateDescription;
        binding.rateBtn.setOnClickListener(v -> onClick());
        binding.btnSkip.setOnClickListener(v -> finish());

        DaggerMyOrdersComponent.builder().applicationComponent(App.component).build().inject(this);
    }

    public void onClick() {
        if (rateRatingBar.getRating() == 0)
            return;
        String orderId = getIntent().getStringExtra(KEY_ORDER);
        RateOrderApiModel rateOrderApiModel = new RateOrderApiModel((int) rateRatingBar.getRating(), EditTextHelper.getTrimmedText(rateDescription), orderId);
        subscription = clientOrdersApi.postOpinionAboutOrder(rateOrderApiModel)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(() -> earthlyDialog = ProgressHelper.showEarthly(getSupportFragmentManager()))
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                .subscribe((aVoid) -> finish(), (throwable) -> ApiErrorDialogHelper.show(this, throwable));
    }

    @Override
    public boolean onOptionsItemSelected(@NotNull MenuItem item) {
        finish();
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Rx.safeUnsubscribe(subscription);
    }
}
