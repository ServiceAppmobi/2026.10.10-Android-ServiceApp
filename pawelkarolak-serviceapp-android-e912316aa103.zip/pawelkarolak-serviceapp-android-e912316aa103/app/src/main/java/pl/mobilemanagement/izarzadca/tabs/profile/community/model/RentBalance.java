package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class RentBalance implements Serializable {
    @SerializedName("balance")
    public String balance;

    @SerializedName("lastRent")
    public lastRent lastRent;


}
