package pl.mobilemanagement.izarzadca.start_screen.forgot.di;

import dagger.Module;
import dagger.Provides;
import retrofit2.Retrofit;

@Module
public class ForgotModule {

    @Provides
    @ForgotScope
    public ForgotServiceApi providesLoginApi(Retrofit retrofit) {
        return retrofit.create(ForgotServiceApi.class);
    }
}