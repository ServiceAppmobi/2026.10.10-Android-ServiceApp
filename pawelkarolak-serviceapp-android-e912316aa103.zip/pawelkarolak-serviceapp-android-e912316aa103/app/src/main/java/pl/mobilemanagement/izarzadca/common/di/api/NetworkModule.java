package pl.mobilemanagement.izarzadca.common.di.api;

import android.os.Build;

import androidx.annotation.NonNull;
import dagger.Module;
import dagger.Provides;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.inject.Singleton;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import pl.mobilemanagement.izarzadca.BuildConfig;

@Module
public class NetworkModule {

    @Provides
    @NonNull
    @Singleton
    OkHttpClient provideOkHttpClient(@NonNull List<Interceptor> interceptors) {
        return createOkHttpClient(interceptors);
    }

    @NonNull
    private OkHttpClient createOkHttpClient(@NonNull List<Interceptor> interceptors) {
        final OkHttpClient.Builder okHttpBuilder = new OkHttpClient.Builder()
                .connectTimeout(2, TimeUnit.MINUTES)
                .readTimeout(2, TimeUnit.MINUTES)
                .writeTimeout(2, TimeUnit.MINUTES);

        for (Interceptor interceptor : interceptors) {
            okHttpBuilder.addInterceptor(interceptor);
        }

        if (BuildConfig.DEBUG && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            TrustManager trustManager = new TrustManager();
            okHttpBuilder.sslSocketFactory(trustManager.getSocketFactory(), trustManager);
            okHttpBuilder.hostnameVerifier((v1, v2) -> true);
        }

        return okHttpBuilder.build();
    }

    @Provides
    @NonNull
    @Singleton
    @Auth
    OkHttpClient provideAuthOkHttpClient(@NonNull List<Interceptor> interceptors, @Auth Interceptor interceptor) {
        final List<Interceptor> interceptorsList = new ArrayList<>(interceptors);
        interceptorsList.add(interceptor);
        return createOkHttpClient(interceptorsList);
    }

}
