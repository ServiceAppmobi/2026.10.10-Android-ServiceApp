package pl.mobilemanagement.izarzadca.tabs;

import android.view.View;
import com.google.android.material.tabs.TabLayout;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.tools.BaseFragment;

public abstract class TabFragment extends BaseFragment {


    public abstract int getIconResource();

    public abstract int getTitleResource();

    public final void bindTab(TabLayout.Tab tab) {
        tab.setText(getTitleResource());
        tab.setIcon(getIconResource());
        bindTabView(tab.getCustomView().findViewById(R.id.tab_indicator));
    }

    protected void bindTabView(View indicator) {

    }

}
