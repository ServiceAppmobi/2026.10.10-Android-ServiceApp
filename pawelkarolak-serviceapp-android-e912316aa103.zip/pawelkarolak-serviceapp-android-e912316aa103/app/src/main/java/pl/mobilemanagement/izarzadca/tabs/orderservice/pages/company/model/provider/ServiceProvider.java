package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider;

import com.google.android.gms.maps.model.LatLng;

import java.io.Serializable;

public class ServiceProvider implements Serializable {
    public final String id;
    public final String name;
    public final String street;
    public final String city;
    public final String postalCode;
    public final String streetNr;
    public final String country;
    public final int businessArea;
    public final String businessAreaValue;
    public final int ratingsNumber;
    public final int rating;
    public final String description;
    public final double lat;
    public final double lng;
    public final int distance;

    public ServiceProvider(String id, String name, String street, String city, String postalCode, String streetNr, String country, int businessArea, String businessAreaValue, int ratingsNumber, int rating, String description, double lat, double lng, int distance) {
        this.id = id;
        this.name = name;
        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
        this.streetNr = streetNr;
        this.country = country;
        this.businessArea = businessArea;
        this.businessAreaValue = businessAreaValue;
        this.ratingsNumber = ratingsNumber;
        this.rating = rating;
        this.description = description;
        this.lat = lat;
        this.lng = lng;
        this.distance = distance;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ServiceProvider that = (ServiceProvider) o;

        return id.equals(that.id);

    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    public LatLng getLatLng() {
        return new LatLng(lat, lng);
    }
}
