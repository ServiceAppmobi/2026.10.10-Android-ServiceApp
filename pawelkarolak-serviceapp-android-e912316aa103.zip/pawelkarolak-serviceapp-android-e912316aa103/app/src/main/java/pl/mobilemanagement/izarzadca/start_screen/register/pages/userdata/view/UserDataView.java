package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view;

import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getText;
import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;

import android.app.Activity;
import android.content.Context;
import android.widget.CompoundButton;
import android.widget.EditText;

import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.textfield.TextInputLayout;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.BuildConfig;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.SpinnerTextView;
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi;
import pl.mobilemanagement.izarzadca.common.invite.contact.InviteType;
import pl.mobilemanagement.izarzadca.common.location.CurrentLocationService;
import pl.mobilemanagement.izarzadca.common.model.api.CustomerRegister;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.common.user.token.TokenDataSource;
import pl.mobilemanagement.izarzadca.databinding.RegisterUserDataBinding;
import pl.mobilemanagement.izarzadca.start_screen.login_or_register.SocialData;
import pl.mobilemanagement.izarzadca.start_screen.register.LocationListener;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.PageRegisterView;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.CheckLoginOccupation;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model.PersonalData;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ChangePasswordApiModel;
import pl.mobilemanagement.izarzadca.tabs.profile.api.ProfileApi;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.ValidationErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class UserDataView extends PageRegisterView implements CompoundButton.OnCheckedChangeListener {

    public static final int PASSWORD_MINIMUM_LENGHT = 6;
    public static final int PASSWORD_MAXIMUM_LENGHT = 30;

    private final PersonalInfoController personalInfoController;
    public Subscription registerSubscription;

    SpinnerTextView accountTypeSpinner;
    EditText firstName;
    EditText surName;
    EditText email;
    EditText login;
    EditText password;
    TextInputLayout passwordLayout;
    MaterialCheckBox smsCheckbox;
    MaterialCheckBox emailCheckbox;

    @Inject
    UnauthorizedApi unauthorizedApi;
    @Inject
    TokenDataSource tokenDataSource;
    @Inject
    ProfileApi profileApi;
    @Inject
    AccountTypeDataSource accountTypeDataSource;

    CurrentLocationService currentLocationService;

    private Subscription checkLoginIsOccupiedSubscription;

    private final boolean isSocial;

    private final LocationListener locationListener;

    public UserDataView(Context context, Activity activity, SocialData socialData, LocationListener locationListener) {
        super(context);

        RegisterUserDataBinding binding = RegisterUserDataBinding.bind(this);
        accountTypeSpinner = binding.userDataAccountType;
        firstName = binding.userFirstName;
        surName = binding.userDataSurname;
        email = binding.userDataEmail;
        login = binding.userDataLogin;
        password = binding.userDataPassword;
        passwordLayout = binding.userDataPasswordLayout;
        smsCheckbox = binding.cbSms;
        emailCheckbox = binding.cbEmail;
        binding.next.setOnClickListener(v -> onNextButtonClick());

        App.component.inject(this);

        this.locationListener = locationListener;

        firstName.setText(socialData.getFirstName());
        surName.setText(socialData.getLastName());
        email.setText(socialData.getEmail());
        login.setText(socialData.getLogin());

        isSocial = socialData.getEmail() != null;
        passwordLayout.setVisibility(isSocial ? GONE : VISIBLE);

        personalInfoController = new PersonalInfoController(unauthorizedApi, login, surName, email, firstName, accountTypeSpinner, password);
        currentLocationService = new CurrentLocationService(activity);
    }

    @Override
    protected void onAttached() {
        personalInfoController.onCreate();

        locationListener.requestLocationPermissions(() -> {
            currentLocationService.fetchCurrentGPSPosition()
                    .observeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(
                            location -> getCurrentBuilder().setLocation(location.getLatitude(), location.getLongitude()),
                            throwable -> ApiErrorDialogHelper.show(getContext(), throwable)
                    );
        });

        boolean createdByPropertyManager = getCurrentBuilder().createdByPropertyManager;
        if(createdByPropertyManager) {
            personalInfoController.selectedAccountTypeName = getCurrentBuilder().getAccountTypeName();
            accountTypeSpinner.setText(getCurrentBuilder().getAccountTypeName().name);
            firstName.setText(getCurrentBuilder().getPersonalData().getUserName());
            surName.setText(getCurrentBuilder().getPersonalData().getSurName());
            email.setText(getCurrentBuilder().getPersonalData().getEmail());
            login.setText(getCurrentBuilder().getUserName());
        }
        firstName.setEnabled(!createdByPropertyManager);
        surName.setEnabled(!createdByPropertyManager);
        email.setEnabled(!createdByPropertyManager && !isSocial);
        login.setEnabled(!createdByPropertyManager);

        smsCheckbox.setOnCheckedChangeListener(this);
        emailCheckbox.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        int id = buttonView.getId();
        if(id == R.id.cbSms && buttonView.isChecked())
            emailCheckbox.setChecked(false);
        else if(id == R.id.cbEmail && buttonView.isChecked())
            smsCheckbox.setChecked(false);
    }

    @Override
    protected void onDetached() {
        accountTypeSpinner.dismissDropDown();
        personalInfoController.onDestroy();
        Rx.safeUnsubscribe(registerSubscription);
        Rx.safeUnsubscribe(checkLoginIsOccupiedSubscription);
    }

    private void fillPersonalData() {
        PersonalData personalData = new PersonalData(personalInfoController.getUserName(), personalInfoController.getSurname(), personalInfoController.getEmail());
        getCurrentBuilder().setPersonalData(personalData);
        getCurrentBuilder().setAccountTypeName(personalInfoController.getSelectedAccountTypeName());
        getCurrentBuilder().setPassword(getPassword());
    }

    void onNextButtonClick() {
        Validator validator = validateInput();
        if (validator.isValid()) {
            fillPersonalData();
            if(smsCheckbox.isChecked()) {
                getCurrentBuilder().inviteType = InviteType.PHONE;
            } else if(emailCheckbox.isChecked()) {
                getCurrentBuilder().inviteType = InviteType.EMAIL;
            } else {
                getCurrentBuilder().inviteType = null;
            }
            checkLoginOccupation();
        } else {
            ValidationErrorDialogHelper.show(getContext(), validator);
        }
    }

    private void registerCustomer() {
        CustomerRegister customerRegister = getCurrentBuilder().createCustomerRegisterModel();
        registerSubscription = unauthorizedApi.registerCustomer(customerRegister)
                .compose(Rx.applySchedulers())
                .compose(ProgressDialog.create(getContext()))
                .subscribe(response -> {
                    tokenDataSource.saveTokenInfo(response.accessToken);
                    accountTypeDataSource.setVersionCode(BuildConfig.VERSION_CODE);
                    accountTypeDataSource.saveAccountType(response.accountType);
                    pageViewListener.finishPaging();
                }, e -> ApiErrorDialogHelper.show(getContext(), e));
    }

    private void checkLoginOccupation() {
        final String userName = getUserName();
        final String email = personalInfoController.getEmail();
        boolean createdByPropertyManager = getCurrentBuilder().createdByPropertyManager;

        if(createdByPropertyManager) {
            ChangePasswordApiModel changePasswordApiModel = new ChangePasswordApiModel("", getPassword());
            checkLoginIsOccupiedSubscription = profileApi
                    .updatePassword(changePasswordApiModel, "Bearer " + getCurrentBuilder().accessToken)
                    .compose(Rx.applySchedulers())
                    .compose(ProgressDialog.create(getContext()))
                    .toCompletable()
                    .subscribe(() -> {
                            if (personalInfoController.isSelectedProvider())
                                pageViewListener.showNextPage();
                            else {
                                tokenDataSource.saveTokenInfo(getCurrentBuilder().accessToken);
                                accountTypeDataSource.saveAccountType(getCurrentBuilder().getAccountTypeName().type);
                                pageViewListener.finishPaging();
                            }
                        }, throwable -> ApiErrorDialogHelper.show(getContext(), throwable)
                    );
        } else {
            checkLoginIsOccupiedSubscription = unauthorizedApi.checkLoginExist(new CheckLoginOccupation(userName, email))
                    .compose(Rx.applySchedulers())
                    .compose(ProgressDialog.create(getContext()))
                    .toCompletable()
                    .subscribe(() -> {
                                getCurrentBuilder().setUserName(userName);
                                if (personalInfoController.isSelectedProvider()) {
                                    pageViewListener.showNextPage();
                                } else {
                                    registerCustomer();
                                }
                            }, throwable -> ApiErrorDialogHelper.show(getContext(), throwable)
                    );
        }
    }

    private Validator validateInput() {
        Validator validator = new Validator();

        if (getUserName().length() < 5) {
            validator.addError(getContext().getString(R.string.account_data_wrong_lenght));
            return validator;
        }

        if (!isSocial && !passwordHasProperLength()) {
            validator.addError(getContext().getString(R.string.password_confirm_wrong_size));
            return validator;
        }

        final Validator personalValidator = personalInfoController.validateInput();
        if (!personalValidator.isValid()) {
            validator.addError(personalValidator.getErrors());
        }
        return validator;
    }

    private String getUserName() {
        return getTrimmedText(login);
    }

    private String getPassword() {
        return getText(password);
    }

    @Override
    protected int titleResource() {
        return R.string.registration_user_data;
    }

    @Override
    protected int layoutResource() {
        return R.layout.register_user_data;
    }

    private boolean passwordHasProperLength() {
        final int passwordLength = getPassword().length();
        return passwordLength >= PASSWORD_MINIMUM_LENGHT && passwordLength <= PASSWORD_MAXIMUM_LENGHT;
    }
}
