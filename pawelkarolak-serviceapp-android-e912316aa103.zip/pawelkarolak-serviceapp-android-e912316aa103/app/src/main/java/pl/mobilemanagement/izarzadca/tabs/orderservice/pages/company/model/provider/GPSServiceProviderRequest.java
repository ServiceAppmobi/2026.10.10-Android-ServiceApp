package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.GPSPlace;

class GPSServiceProviderRequest extends ServiceProviderRequest {

    GPSServiceProviderRequest(String serviceId, GPSPlace place) {
        super(serviceId, place);
        this.lat = place.latGps;
        this.lng = place.longGps;
    }
}
