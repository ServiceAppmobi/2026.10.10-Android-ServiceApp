package pl.mobilemanagement.izarzadca.tools

import android.app.Application
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.media.MediaPlayer
import android.net.Uri
import android.view.MotionEvent
import android.view.View
import android.widget.VideoView
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource

class AdsBannerUtil(
    private val app: Application,
    private val accountTypeDataSource: AccountTypeDataSource
) : View.OnTouchListener {

    private var adsViewMediaPlayer: MediaPlayer? = null

    fun init(adsView: VideoView) {
        val path = "android.resource://" + app.packageName + "/" + R.raw.ads_banner
        val uri = Uri.parse(path)
        adsView.setVideoURI(uri)
        adsView.setOnPreparedListener(::initMediaPlayer)
        adsView.setOnTouchListener(this)
    }

    private fun initMediaPlayer(mp: MediaPlayer) {
        this.adsViewMediaPlayer = mp
        mp.isLooping = true
        mp.start()
    }

    override fun onTouch(p0: View?, event: MotionEvent?): Boolean {
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(accountTypeDataSource.bannerUrl))
        browserIntent.addFlags(FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(browserIntent)
        return true
    }

    fun releaseAdsView() {
        adsViewMediaPlayer?.reset()
        adsViewMediaPlayer = null
    }
}