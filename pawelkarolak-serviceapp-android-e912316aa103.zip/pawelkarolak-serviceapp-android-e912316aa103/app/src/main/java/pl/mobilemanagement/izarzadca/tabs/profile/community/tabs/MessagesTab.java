package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.inject.Inject;
import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.CloseOrderClickListener;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.common.listview_item;
import pl.mobilemanagement.izarzadca.tabs.profile.community.common.listview_popup;
import pl.mobilemanagement.izarzadca.tabs.profile.community.di.DaggerMyCommunityComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.GetEmails;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.schedulers.Schedulers;

/**
 * Created by katak on 10.01.2017.
 */

public class MessagesTab extends TitledTabFragment implements CloseOrderClickListener {

    @Inject
    CommunityApi communityApi;


    private Subscription fetchSubscription;

    @Override
    public int getTitleResource() {
         return R.string.menu_messages_emails_email;
    }

    @Override
    public void onCloseOrderClick(Order order) {

    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DaggerMyCommunityComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }
    @Override
    public void onResume() {
        Log.i("INFO", "onResume");
        super.onResume();
        fetchSubscription = getEmails().subscribe();
    }

    @Override
    public void onPause() {
        super.onPause();
        Rx.safeUnsubscribe(fetchSubscription);
    }

    public Observable<List<GetEmails>> getEmails() {
        return communityApi.GetEmails()
                .doOnNext(this::setData)
                .doOnError(this::showConnectionError)
                .onErrorResumeNext(throwable -> Observable.empty())
                .subscribeOn(Schedulers.io());
    }

    private void setData(List<GetEmails> getAnnouncementses) {
        Log.i("CommunityInfo", "setData");

        Handler txtsettext = new Handler(Looper.getMainLooper());
        txtsettext.post(new Runnable() {
            public void run() {

                listview_item[] listData = new listview_item[getAnnouncementses.size()];

                int i = 0;
                for (GetEmails aaaa : getAnnouncementses) {
                    Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String createDate = "-";

                    if(aaaa.createAt != null){
                        createDate = formatter.format(aaaa.createAt);
                    }
                    listData[i++] = new listview_item(
                        aaaa.topic,
                        aaaa.emailFrom,
                        createDate,
                        aaaa.emailTo,
                        "",
                        aaaa.messageBody
                    );
                }

                listview_popup adapter = new listview_popup(
                    getContext(), R.layout.list_annoucement_item, listData,
                    R.string.email_from,
                    R.string.email_date,
                    R.string.email_to,
                        0,
                        R.string.service_details
                );

                listView1.setAdapter(adapter);
            }
        });
    }

    public void showConnectionError(Throwable message) {
        Log.e("CommunityInfo", "showConnectionError");
        Log.e("CommunityInfo", String.valueOf(message));

    }

    private ListView listView1;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.i("INFO", "onViewCreated");
        super.onViewCreated(view,savedInstanceState);
        listView1 = view.findViewById(R.id.listViewAnn);
    }

    @Override
    protected int getLayout() {
         return R.layout.list_annoucement;
    }
}
