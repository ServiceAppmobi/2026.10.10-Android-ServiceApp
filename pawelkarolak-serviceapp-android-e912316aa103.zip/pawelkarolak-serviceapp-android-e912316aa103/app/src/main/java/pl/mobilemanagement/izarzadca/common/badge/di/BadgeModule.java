package pl.mobilemanagement.izarzadca.common.badge.di;

import androidx.annotation.NonNull;
import dagger.Module;
import dagger.Provides;
import javax.inject.Singleton;
import pl.mobilemanagement.izarzadca.common.badge.MyOrderBadge;
import pl.mobilemanagement.izarzadca.common.badge.MyServiceBadge;
import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;

@Module
public class BadgeModule {

    @Provides
    @NonNull
    @Singleton
    MyServiceBadge provideMyServiceBadge(DataSourceRepository dataSourceRepository) {
        return new MyServiceBadge(dataSourceRepository);
    }

    @Provides
    @NonNull
    @Singleton
    MyOrderBadge provideMyOrdersBadge(DataSourceRepository dataSourceRepository) {
        return new MyOrderBadge(dataSourceRepository);
    }
}
