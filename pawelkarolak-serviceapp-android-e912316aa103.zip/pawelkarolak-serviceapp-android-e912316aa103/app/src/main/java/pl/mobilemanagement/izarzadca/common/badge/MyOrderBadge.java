package pl.mobilemanagement.izarzadca.common.badge;

import pl.mobilemanagement.izarzadca.common.repository.DataSourceRepository;

public class MyOrderBadge extends BadgeListener {
    private static final String MY_ORDER_BADGE_WATCHED = "my_orders_watched";

    public MyOrderBadge(DataSourceRepository localDataRepository) {
        super(localDataRepository, MY_ORDER_BADGE_WATCHED);
    }
}
