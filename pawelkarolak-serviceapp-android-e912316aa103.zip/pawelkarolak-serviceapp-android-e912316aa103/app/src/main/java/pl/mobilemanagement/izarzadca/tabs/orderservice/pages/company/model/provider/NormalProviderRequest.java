package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.provider;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.Place;

class NormalProviderRequest extends ServiceProviderRequest {

    NormalProviderRequest(String serviceId, Place place) {
        super(serviceId, place);
    }
}
