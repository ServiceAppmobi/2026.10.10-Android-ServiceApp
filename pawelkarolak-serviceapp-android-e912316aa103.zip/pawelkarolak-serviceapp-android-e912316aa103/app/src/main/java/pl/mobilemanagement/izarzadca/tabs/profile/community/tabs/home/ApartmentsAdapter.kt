package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home

import android.content.Context
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.annotation.LayoutRes
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.databinding.DropdownItemMultilineBinding

class ApartmentsAdapter(
    context: Context,
    private val apartments: List<String>
): ArrayAdapter<String>(context, R.layout.dropdown_item_multiline, apartments) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val binding = if (convertView == null) {
            DropdownItemMultilineBinding.inflate(LayoutInflater.from(context), parent, false)
        } else {
            DropdownItemMultilineBinding.bind(convertView)
        }

        val spannable = SpannableStringBuilder(apartments[position])
        val end = apartments[position].indexOf('\n')
        if(end != -1) {
            spannable.setSpan(
                    StyleSpan(Typeface.BOLD),
                    0,
                    end,
                    Spannable.SPAN_EXCLUSIVE_INCLUSIVE
            )
            binding.item.text = spannable
        }

        return binding.root
    }

}