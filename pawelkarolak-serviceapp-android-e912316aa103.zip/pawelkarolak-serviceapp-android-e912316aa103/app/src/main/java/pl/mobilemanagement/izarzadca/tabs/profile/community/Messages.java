package pl.mobilemanagement.izarzadca.tabs.profile.community;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Collections;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.badge.MyOrderBadge;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabsFragmentAdapter;
import pl.mobilemanagement.izarzadca.databinding.TabMyCommunityBinding;
import pl.mobilemanagement.izarzadca.tabs.TabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.MessagesTab;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by katak on 10.01.2017.
 */
/*
 * Wspolnota
 * Informacje
 * Finanse
 * Czlonkowie
 * */
public class Messages extends TabFragment {

    @Inject
    MyOrderBadge myOrderBadgeListener;

    public Messages() {
        App.component.inject(this);
    }

    @Override
    public int getIconResource() {
        return R.drawable.ico_tab_my_orders;
    }

    @Override
    public int getTitleResource() {
        return R.string.tab_my_community;
    }

    @Override
    protected int getLayout() {
        return R.layout.tab_my_community;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        TabMyCommunityBinding binding = TabMyCommunityBinding.bind(view);
        TitledTabsFragmentAdapter<TitledTabFragment> tabsFragmentAdapter = new TitledTabsFragmentAdapter<>(
            getContext(),
            getChildFragmentManager(),
            Collections.singletonList(new MessagesTab())
        );
        binding.CommunityTabLayout.setVisibility(View.GONE);
        binding.CommunityViewPager.setAdapter(tabsFragmentAdapter);
    }

    @Override
    protected void bindTabView(View indicator) {
        myOrderBadgeListener.getBadgeIsAvailable()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(hasUnreaded -> {
                    indicator.setVisibility(hasUnreaded ? View.VISIBLE : View.GONE);
                });
    }

    @Override
    public void onResume() {
        super.onResume();
        myOrderBadgeListener.informBadgeWatched();
    }

  /*@Override
  public void onTargetNotification(Observable<Message> oMessage) {
    oMessage.subscribe(message -> {
      myOrderBadgeListener.informBadgeWatched();
    });
  }

  @Override
  public void onMismatchTargetNotification(Observable<Message> oMessage) {

  }

  @Override
  public boolean matchesTarget(String key) {
    return PushType.isMyOrderPush(key);
  }*/
}
