package pl.mobilemanagement.izarzadca.start_screen.register.pages.company;

import java.util.ArrayList;
import java.util.List;

import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.ServiceItem;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;
import pl.mobilemanagement.izarzadca.tools.spinner.SpinnerItem;


public class ServicesSpinnerItem implements SpinnerItem {

    private final ServiceModel typeService;

    public ServicesSpinnerItem(ServiceModel typeService) {
        this.typeService = typeService;
    }

    public static List<ServicesSpinnerItem> createSpinnerItems(List<ServiceModel> accountTypes) {
        final List<ServicesSpinnerItem> servicesSpinnerItems = new ArrayList<>();
        for (ServiceModel accountType : accountTypes) {
            servicesSpinnerItems.add(new ServicesSpinnerItem(accountType));
        }
        return servicesSpinnerItems;
    }

    public static List<ServiceItem> createItems(List<ServiceModel> accountTypes) {
        final List<ServiceItem> servicesSpinnerItems = new ArrayList<>();
        for (ServiceModel serviceModel : accountTypes) {
            servicesSpinnerItems.add(new ServiceItem(serviceModel.serviceId, serviceModel.name, false, true));
        }
        return servicesSpinnerItems;
    }

    public ServiceModel getTypeService() {
        return typeService;
    }

    @Override
    public String toString() {
        return typeService.name;
    }
}