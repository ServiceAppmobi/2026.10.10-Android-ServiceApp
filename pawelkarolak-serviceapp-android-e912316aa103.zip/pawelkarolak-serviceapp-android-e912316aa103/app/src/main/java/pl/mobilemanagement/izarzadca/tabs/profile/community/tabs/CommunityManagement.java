package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.databinding.ListCommunityManagmentBinding;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.CloseOrderClickListener;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.di.DaggerMyCommunityComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.CommunityBoardMembers;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.adapters.CommunityManagmentAdapter;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressDialog;
import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by katak on 10.01.2017.
 */

public class CommunityManagement extends TitledTabFragment implements CloseOrderClickListener {

    @Inject
    CommunityApi communityApi;

    private CharSequence lastTitle = "";
    public Activity activity = null;

    private Subscription fetchSubscription;

    private ListCommunityManagmentBinding binding;

    private final CommunityManagmentAdapter adapter = new CommunityManagmentAdapter();

    @Override
    public int getTitleResource() {
         return R.string.profile_CommunityManagement;
    }

    @Override
    public void onCloseOrderClick(Order order) {

    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DaggerMyCommunityComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);

        if (activity != null) {
            lastTitle = activity.getTitle();
            activity.setTitle(getTitleResource());
        }
    }

    @Override
    public void onResume() {
        Log.i("INFO", "onResume");
        super.onResume();
        fetchSubscription = getCommunityInformation().subscribe();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        fetchSubscription.unsubscribe();
        if (activity != null) {
            activity.setTitle(lastTitle);
        }
    }

    public Observable<List<CommunityBoardMembers>> getCommunityInformation() {
        return communityApi.getCommunityBoardMembers()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext(this::setData)
                .doOnError(this::showConnectionError)
                .onErrorResumeNext(throwable -> Observable.empty())
                .compose(ProgressDialog.create(requireContext()));
    }

    private void setData(List<CommunityBoardMembers> communityBoardMembers) {
        adapter.submitList(communityBoardMembers);
    }

    public void showConnectionError(Throwable message) {
        Log.e("CommunityInfo", "showConnectionError");
        Log.e("CommunityInfo", String.valueOf(message));
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.i("INFO", "onViewCreated");
        super.onViewCreated(view,savedInstanceState);
        binding = ListCommunityManagmentBinding.bind(view);
        binding.getRoot().setAdapter(adapter);
    }

    @Override
    protected int getLayout() {
         return R.layout.list_community_managment;
    }
}
