package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.jetbrains.annotations.NotNull;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.orders.OrdersAdapter;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.databinding.OrderAcceptedRowBinding;

public class AcceptedOrderAdapter extends OrdersAdapter<AcceptedOrderAdapter.AcceptedVH> {
    private final CloseOrderClickListener closeOrderClickListener;

    public AcceptedOrderAdapter(CloseOrderClickListener closeOrderClickListener) {
        this.closeOrderClickListener = closeOrderClickListener;
    }

    @NotNull
    @Override
    public AcceptedVH onCreateViewHolder(ViewGroup parent, int viewType) {
        return new AcceptedVH(LayoutInflater.from(parent.getContext()).inflate(R.layout.order_accepted_row, parent, false));
    }

    @Override
    public void onBindViewHolder(AcceptedVH holder, int position) {
        final Order item = getItem(position);
        holder.bind(item);
    }

    class AcceptedVH extends OrdersAdapter.VH implements View.OnClickListener {

        private Order item;

        AcceptedVH(View itemView) {
            super(itemView);
            OrderAcceptedRowBinding binding = OrderAcceptedRowBinding.bind(itemView);
            binding.closeOrder.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            closeOrderClickListener.onCloseOrderClick(item);
        }

        @Override
        public void bind(Order item) {
            super.bind(item);
            this.item = item;
        }
    }
}
