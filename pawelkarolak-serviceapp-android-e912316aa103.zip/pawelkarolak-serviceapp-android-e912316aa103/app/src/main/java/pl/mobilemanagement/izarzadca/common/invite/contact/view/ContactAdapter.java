package pl.mobilemanagement.izarzadca.common.invite.contact.view;

import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import pl.mobilemanagement.izarzadca.common.invite.contact.Contact;

/**
 * TODO Write javadoc
 *
 * @author Ulrich Raab
 */
public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ViewHolder> {

    private List<Contact> contacts = new ArrayList<>();
    private HashSet<Contact> selectedContacts = new HashSet<>();

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ContactView contactView = ContactView.inflate(parent, false);
        contactView.setOnClickListener(v -> {
            final Contact contact = ((ContactView) v).getContact();
            final boolean isSelected = selectedContacts.contains(contact);
            if (isSelected) {
                selectedContacts.remove(contact);
            } else {
                selectedContacts.add(contact);
             }
            notifyDataSetChanged();
        });
        return new ViewHolder(contactView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Contact contact = getContact(position);
        ContactView view = holder.getContactView();
        view.bind(contact);
        view.setSelected(selectedContacts.contains(contact));
    }

    @Override
    public long getItemId(int position) {
        Contact contact = getContact(position);
        return contact.hashCode();
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }

    public Contact getContact(int position) {
        return contacts.get(position);
    }

    public List<Contact> getSelectedContacts() {
        return new ArrayList<>(selectedContacts);
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ContactView contactView;

        public ViewHolder(ContactView contactView) {
            super(contactView);
            this.contactView = contactView;
        }

        public ContactView getContactView() {
            return contactView;
        }
    }
}
