package pl.mobilemanagement.izarzadca.tabs.profile.edit.model;

import com.google.gson.annotations.Expose;

import java.util.List;

import pl.mobilemanagement.izarzadca.common.model.api.SimpleServiceModel;
import pl.mobilemanagement.izarzadca.common.user.AccountType;

public class UpdateProviderApiModel extends UpdateUserApiModel {
    @Expose
    public final String companyName;
    @Expose
    public final String nip;
    @Expose
    public final String companyDescription;
    @Expose
    public final long companyBusinessAreaId;
    @Expose
    public final List<SimpleServiceModel> providedServices;

    public UpdateProviderApiModel(UpdateUserApiModel updateUserApiModel, String companyName, String nip, String companyDescription, long companyBusinessAreaId, List<SimpleServiceModel> providedServices) {
        super(updateUserApiModel);
        this.accountType = AccountType.SERVICE_PROVIDER;
        this.companyName = companyName;
        this.nip = nip;
        this.companyDescription = companyDescription;
        this.companyBusinessAreaId = companyBusinessAreaId;
        this.providedServices = providedServices;
    }

}
