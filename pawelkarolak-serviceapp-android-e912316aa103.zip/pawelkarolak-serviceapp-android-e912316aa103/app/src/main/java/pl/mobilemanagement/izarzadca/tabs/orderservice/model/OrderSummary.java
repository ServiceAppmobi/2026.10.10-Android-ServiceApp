package pl.mobilemanagement.izarzadca.tabs.orderservice.model;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class OrderSummary implements Serializable {
    public final Date startDateTime;
    public final Date endDateTime;
    public final String issueDescription;
    public final String serviceGroupName;
    public final String serviceTypeName;
    public final List<String> providersName;
    public final List<File> fileList;

    public OrderSummary(Date startDateTime, Date endDateTime, String issueDescription, String serviceGroupName, String serviceTypeName, List<String> providersName, List<File> fileList) {
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
        this.issueDescription = issueDescription;
        this.serviceGroupName = serviceGroupName;
        this.serviceTypeName = serviceTypeName;
        this.providersName = providersName;
        this.fileList = fileList;
    }
}
