package pl.mobilemanagement.izarzadca.tools.rx.spinner;

import pl.mobilemanagement.izarzadca.common.SpinnerTextView;
import rx.Observable;

public class RxSpinner {
  public static <T> Observable<T> itemClickChanges(SpinnerTextView betterSpinner) {
    return Observable.create(new SpinnerAdapterViewItemClickEventOnSubscribe<T>(betterSpinner));
  }
}
