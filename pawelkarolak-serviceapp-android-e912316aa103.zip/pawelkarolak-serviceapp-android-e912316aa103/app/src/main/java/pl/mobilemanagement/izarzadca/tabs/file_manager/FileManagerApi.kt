package pl.mobilemanagement.izarzadca.tabs.file_manager

import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Streaming

interface FileManagerApi {

    @GET("file/getall")
    suspend fun getAll() : List<File>

    @Streaming
    @POST("file/DownloadFile")
    suspend fun downloadFile(@Body url: String) : Response<ResponseBody>
}