package pl.mobilemanagement.izarzadca.common.model.api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OrderId {
    @Expose
    @SerializedName("Id")
    public String id;

    public OrderId(String id) {
        this.id = id;
    }
}
