package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import java.io.Serializable;

/**
 * Created by katak on 10.01.2017.
 */

public class CheckIfCommunityMember implements Serializable {

    public boolean bool;

    public boolean checkMe(){
        return this.bool;
    }
}
