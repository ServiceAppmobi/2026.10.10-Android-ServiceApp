package pl.mobilemanagement.izarzadca.tools;

import android.content.Context;
import android.text.format.DateUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import pl.mobilemanagement.izarzadca.R;

import static android.text.format.DateUtils.FORMAT_SHOW_DATE;
import static android.text.format.DateUtils.FORMAT_SHOW_TIME;

public final class DateUtil {
    private final static String SERVER_FORMAT = "dd-MM-yyyy HH:mm:ss";
    public final static String MMM_DD_FORMAT = "MMM dd";
    public final static String DD_MM_YYYY_FORMAT = "dd MMM yyyy";
    public final static String YYYY_MM_DD_FORMAT = "yyyy.MM.dd";

    public static String getFormattedDate(Context context, Date startDate, Date endDate) {
        if (startDate == null || endDate == null)
            return context.getString(R.string.order_service_select_date_as_soon_is_possible);
        else
            return DateUtils.formatDateRange(context, startDate.getTime(), endDate.getTime(), FORMAT_SHOW_TIME | FORMAT_SHOW_DATE);
    }

    public static Date getDateFromServerFormat(String dateString) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(SERVER_FORMAT, Locale.getDefault());
        try {
            return simpleDateFormat.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new Date();
    }

    public static String formatDate(Date date, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
        return sdf.format(date);
    }

    public static String getFormattedDateFromServerDate(String dateString, String pattern) {
        return formatDate(getDateFromServerFormat(dateString), pattern);
    }
}
