package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model;

import android.location.Location;

public class GPSPlace extends Place {
    public static final String GPS_PLACE = "100000002";

    public final String latGps;
    public final String longGps;

    public GPSPlace(String latGps, String longGps) {
        super(GPS_PLACE);
        this.latGps = latGps;
        this.longGps = longGps;
    }

    public GPSPlace(Location location) {
        this(Double.toString(location.getLatitude()), Double.toString(location.getLongitude()));
    }
}
