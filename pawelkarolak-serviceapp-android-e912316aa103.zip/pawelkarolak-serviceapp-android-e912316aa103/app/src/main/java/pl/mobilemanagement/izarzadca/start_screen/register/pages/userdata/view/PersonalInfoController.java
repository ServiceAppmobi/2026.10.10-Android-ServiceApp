package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view;

import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;

import android.content.Context;
import android.text.InputFilter;
import android.widget.EditText;
import java.util.List;
import java.util.regex.Pattern;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.SpinnerTextView;
import pl.mobilemanagement.izarzadca.common.di.api.UnauthorizedApi;
import pl.mobilemanagement.izarzadca.common.model.entity.AccountTypeName;
import pl.mobilemanagement.izarzadca.common.user.AccountType;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model.AccountTypeSpinnerItem;
import pl.mobilemanagement.izarzadca.tools.EditTextHelper;
import pl.mobilemanagement.izarzadca.tools.PartialRegexInputFilter;
import pl.mobilemanagement.izarzadca.tools.Validator;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import pl.mobilemanagement.izarzadca.tools.spinner.HintAdapter;
import rx.Subscription;

public class PersonalInfoController {
    private static final int MAX_EMAIL_LENGTH = 200;
    private static final int MIN_USER_NAME_LENGTH = 2;
    private static final int MAX_NAME_LENGTH = 30;
    private static final int MIN_SURNAME_LENGTH = 2;
    private static final int MAX_SURNAME_LENGTH = 200;
    private static final Pattern EMAIL_ADDRESS = Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+"
    );

    private EditText login = null;
    private final EditText firstName;
    private final EditText surName;

  private final EditText email;
  private EditText password = null;

  private final SpinnerTextView accountTypeSpinner;

  private final UnauthorizedApi unauthorizedApi;
    private Subscription subscription;
    public AccountTypeName selectedAccountTypeName;
    private AccountTypeChangeListener listener;

  public PersonalInfoController(UnauthorizedApi unauthorizedApi, EditText surName, EditText email, EditText firstName, SpinnerTextView accountTypeSpinner) {
    this.unauthorizedApi = unauthorizedApi;
    this.firstName = firstName;
    this.surName = surName;
    this.email = email;
    this.accountTypeSpinner = accountTypeSpinner;
    initViews();
  }

    public PersonalInfoController(UnauthorizedApi unauthorizedApi, EditText login, EditText surName, EditText email, EditText firstName, SpinnerTextView accountTypeSpinner, EditText password) {
        this.unauthorizedApi = unauthorizedApi;
        this.login = login;
        this.firstName = firstName;
        this.surName = surName;
        this.email = email;
        this.accountTypeSpinner = accountTypeSpinner;
        this.password = password;
        initViews();
    }

    public void onCreate() {
        fetchAccountTypes();
    }

    public void onCreate(AccountTypeChangeListener listener) {
        this.listener = listener;
        onCreate();
    }


    private void fetchAccountTypes() {
        subscription = unauthorizedApi.getAvailableAccountsTypes()
                .compose(Rx.applySchedulers())
                .subscribe(accountTypes -> {
                            List<AccountTypeSpinnerItem> spinnerItems = AccountTypeSpinnerItem.createSpinnerItems(accountTypes);
                            HintAdapter.setHintData(accountTypeSpinner, spinnerItems);
                        }, throwable -> ApiErrorDialogHelper.show(getContext(), throwable)
                );
    }

    public void onDestroy() {
        Rx.safeUnsubscribe(subscription);
    }

    private void initViews() {
        HintAdapter.initEmpty(accountTypeSpinner);
        firstName.setFilters(new InputFilter[]{new EditTextHelper.AlphabetInputFilter(),
                new InputFilter.LengthFilter(MAX_NAME_LENGTH)});
        surName.setFilters(new InputFilter[]{new EditTextHelper.AlphabetInputFilter(),
                new InputFilter.LengthFilter(MAX_SURNAME_LENGTH)});
        email.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_EMAIL_LENGTH)});
        accountTypeSpinner.setOnItemClickListener((parent, view, position, id) -> {
            final AccountTypeSpinnerItem item = (AccountTypeSpinnerItem) parent.getAdapter().getItem(position);
            selectedAccountTypeName = item.getAccountTypeName();
            notifyAccountTypeChanged();
        });
        if(login != null)
            login.setFilters(
                new InputFilter[] {
                    new InputFilter.LengthFilter(20)
                }
            );

    }

    public String getEmail() {
        return getTrimmedText(email);
    }

    public String getSurname() {
        return getTrimmedText(surName);
    }

    public String getUserName() {
        return getTrimmedText(firstName);
    }

    public static boolean isValidEmail(String email) {
        return EMAIL_ADDRESS.matcher(email).matches();
    }

    public Validator validateInput() {
        Validator validator = new Validator();
        if (isAccountTypeNotSelected()) {
            validator.addError(getContext().getString(R.string.user_data_select_account_type));
        }
        if (getUserName().length() < MIN_USER_NAME_LENGTH) {
            validator.addError(getContext().getString(R.string.user_data_no_name));
        }
        if (getSurname().length() < MIN_SURNAME_LENGTH) {
            validator.addError(getContext().getString(R.string.user_data_no_surname));
        }
        if (getEmail().isEmpty() || !isValidEmail(getEmail())) {
            validator.addError(getContext().getString(R.string.user_data_wrong_email));
        }
        return validator;
    }

    private boolean isAccountTypeNotSelected() {
        return selectedAccountTypeName == null;
    }

    private Context getContext() {
        return email.getContext();
    }

    public boolean isSelectedProvider() {
        return selectedAccountTypeName != null && selectedAccountTypeName.type.isProvider();
    }

    public AccountTypeName getSelectedAccountTypeName() {
        return selectedAccountTypeName;
    }

    public void restoreAccountType(AccountType accountType, String accountName) {
        selectedAccountTypeName = new AccountTypeName(accountType, accountName);
        accountTypeSpinner.setText(accountName);
        notifyAccountTypeChanged();
    }

    private void notifyAccountTypeChanged() {
        if (listener != null) {
            listener.onTypeChanged(selectedAccountTypeName);
        }
    }
}