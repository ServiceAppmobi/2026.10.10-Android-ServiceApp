package pl.mobilemanagement.izarzadca.common.di.api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view.PersonalInfoController;

public class UserLoginRequest {
    @Expose
    @SerializedName("userName")
    private String username = null;
    @Expose
    @SerializedName("email")
    private String email = null;
    @Expose
    @SerializedName("password")
    private final String password;

    public UserLoginRequest(String loginOrEmail, String password) {
        if(PersonalInfoController.isValidEmail(loginOrEmail))
            email = loginOrEmail;
        else
            username = loginOrEmail;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
