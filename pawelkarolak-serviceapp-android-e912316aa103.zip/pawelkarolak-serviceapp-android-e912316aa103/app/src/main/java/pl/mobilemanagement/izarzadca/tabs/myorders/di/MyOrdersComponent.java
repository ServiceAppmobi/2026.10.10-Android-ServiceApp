package pl.mobilemanagement.izarzadca.tabs.myorders.di;

import dagger.Component;
import pl.mobilemanagement.izarzadca.common.di.ApplicationComponent;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.rate_order.OrderRateActivity;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.AcceptedOrderTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.complete.CompleteOrderTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.ask_again.AskProvidersAgainActivity;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.view.PendingOrderTabFragment;

@MyOrdersScope
@Component(dependencies = ApplicationComponent.class, modules = MyOrdersModule.class)
public interface MyOrdersComponent {

    void inject(AcceptedOrderTabFragment myOrdersTabFragment);

    void inject(CompleteOrderTabFragment completeOrderTabFragment);

    void inject(PendingOrderTabFragment pendingOrderTabFragment);

    void inject(OrderRateActivity orderRateActivity);

    void inject(AskProvidersAgainActivity askProvidersAgainActivity);
}
