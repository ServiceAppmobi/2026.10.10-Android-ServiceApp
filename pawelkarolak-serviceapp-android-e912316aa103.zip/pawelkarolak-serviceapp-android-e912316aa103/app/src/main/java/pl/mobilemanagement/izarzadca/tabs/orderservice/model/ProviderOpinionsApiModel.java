package pl.mobilemanagement.izarzadca.tabs.orderservice.model;

public class ProviderOpinionsApiModel {
    public final String name;
    public final int rating;
    public final String opinion;

    public ProviderOpinionsApiModel(String name, int rating, String opinion) {
        this.name = name;
        this.rating = rating;
        this.opinion = opinion;
    }
}
