package pl.mobilemanagement.izarzadca.tools.api;

import android.content.Context;
import android.content.DialogInterface;

import com.afollestad.materialdialogs.MaterialDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import pl.mobilemanagement.izarzadca.R;
import retrofit2.adapter.rxjava.HttpException;

public class ApiErrorDialogHelper {
    public static String getMessage(Context context, Throwable t) {
        final String message;
        if (t instanceof IOException) {
            message = context.getString(R.string.connection_error);
        } else {

            if (t instanceof HttpException) {
                message = getMsgErrorFromApi((HttpException) t);
            } else {
                message = "Unknown";
            }
        }
        return message;
    }

    private static String getMsgErrorFromApi(HttpException e) {
        try {
            return new JSONObject(e.response().errorBody().string()).getString("message");
        } catch (JSONException | IOException ignored) {
        }
        return "Response error: Code " + e.code();
    }

    public static MaterialDialog show(Context context, Throwable error) {
        return show(context, error, null);
    }

    public static MaterialDialog show(Context context, Throwable error, DialogInterface.OnCancelListener cancelListener) {
        MaterialDialog.Builder builder = createDialogBuilder(context, error);
        if (cancelListener != null)
            builder = builder.cancelListener(cancelListener);
        return builder.show();
    }

    public static MaterialDialog.Builder createDialogBuilder(Context context, Throwable error) {
        String message = getMessage(context, error);
        return new MaterialDialog.Builder(context)
                .title(R.string.error_title)
                .content(message);

    }

}
