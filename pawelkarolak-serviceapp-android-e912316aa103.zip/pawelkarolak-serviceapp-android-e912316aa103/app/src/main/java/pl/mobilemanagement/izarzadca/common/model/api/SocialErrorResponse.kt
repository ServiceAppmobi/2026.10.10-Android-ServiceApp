package pl.mobilemanagement.izarzadca.common.model.api

data class SocialErrorResponse(
    val code: String? = null,
    val message: String? = null
)
