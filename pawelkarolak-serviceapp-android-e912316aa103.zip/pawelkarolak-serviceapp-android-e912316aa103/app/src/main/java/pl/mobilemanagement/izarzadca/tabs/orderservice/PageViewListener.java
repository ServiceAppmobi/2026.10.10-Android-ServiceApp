package pl.mobilemanagement.izarzadca.tabs.orderservice;

import pl.mobilemanagement.izarzadca.tabs.orderservice.model.OrderSummary;

public interface PageViewListener {
    void showNextPage();

    OrderServiceTabFragment getCurrentFragment();

    void finishOrder(OrderSummary orderSummary);

    OrderBuilder getOrderBuilder();

    void dispatchTakePictureIntent();
    void dispatchChooseFromGalleryIntent();
}
