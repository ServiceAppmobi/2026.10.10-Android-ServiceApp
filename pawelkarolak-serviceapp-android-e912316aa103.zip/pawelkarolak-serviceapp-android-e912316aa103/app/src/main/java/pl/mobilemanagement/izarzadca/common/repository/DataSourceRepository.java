package pl.mobilemanagement.izarzadca.common.repository;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

public class DataSourceRepository {
    private static final String PREFERENCES_NAME = "izarzadca_preference";
    private final SharedPreferences sharedPreference;
    private final Gson gson;

    public DataSourceRepository(Context context, Gson gson) {
        sharedPreference = context.getSharedPreferences(PREFERENCES_NAME, Activity.MODE_PRIVATE);
        this.gson = gson;
    }

    public void clear(String key) {
        sharedPreference.edit().remove(key).apply();
    }

    public void write(String key, Object objectToSave, Class classType) {
        sharedPreference.edit()
                .putString(key, gson.toJson(objectToSave, classType))
                .apply();

    }

    public void write(String key, String value) {
        sharedPreference.edit()
                .putString(key, value)
                .apply();
    }

    public void writeSync(String key, String value) {
        sharedPreference.edit()
                .putString(key, value)
                .commit();
    }

    public void write(String key, Boolean value) {
        sharedPreference.edit()
                .putBoolean(key, value)
                .apply();
    }

    public void write(String key, int value) {
        sharedPreference.edit()
                .putInt(key, value)
                .apply();
    }

    public <T> T read(String key, Class classToRead) {
        return (T) gson.fromJson(sharedPreference.getString(key, null), classToRead);
    }

    public Boolean readBoolean(String key, Boolean defValue) {
        return sharedPreference.getBoolean(key, defValue);
    }

    public boolean has(String key) {
        return sharedPreference.contains(key);
    }

    public String readString(String key) {
        return sharedPreference.getString(key, null);
    }

    public int readInt(String key) {
        return sharedPreference.getInt(key, 0);
    }
}
