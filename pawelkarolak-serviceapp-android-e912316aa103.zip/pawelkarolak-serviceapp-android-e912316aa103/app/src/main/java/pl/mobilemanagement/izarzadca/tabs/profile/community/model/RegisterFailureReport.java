package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class RegisterFailureReport implements Serializable {
    @SerializedName("subjectId")
    public String subjectId;

    @SerializedName("title")
    public String title;

    @SerializedName("description")
    public String description;

    @SerializedName("photo")
    public String photo;


}
