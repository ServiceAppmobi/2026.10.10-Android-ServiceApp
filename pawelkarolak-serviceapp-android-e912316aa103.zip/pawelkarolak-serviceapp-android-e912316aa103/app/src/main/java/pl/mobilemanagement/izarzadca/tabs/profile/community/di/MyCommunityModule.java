package pl.mobilemanagement.izarzadca.tabs.profile.community.di;

import dagger.Module;
@Module
public class MyCommunityModule {

}