package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs;

import java.util.List;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.CloseOrderClickListener;
import pl.mobilemanagement.izarzadca.tools.LCE;
import rx.Observable;

/**
 * Created by katak on 10.01.2017.
 */

public class CommunityInformation extends TitledTabFragment implements CloseOrderClickListener, LCE<Order> {
    @Override
    public int getTitleResource() {
         return R.string.profile_CommunityInformation;
    }

    @Override
    public void onCloseOrderClick(Order order) {

    }



    @Override
    protected int getLayout() {
         return R.layout.recycler_pull_view_frame;
    }

    @Override
    public void showProgressBar() {

    }

    @Override
    public void hideProgressBar() {

    }

    @Override
    public void hideError() {

    }

    @Override
    public void showEmptyListError() {

    }

    @Override
    public void showConnectionError() {

    }

    @Override
    public void setData(List<Order> data) {

    }
}
