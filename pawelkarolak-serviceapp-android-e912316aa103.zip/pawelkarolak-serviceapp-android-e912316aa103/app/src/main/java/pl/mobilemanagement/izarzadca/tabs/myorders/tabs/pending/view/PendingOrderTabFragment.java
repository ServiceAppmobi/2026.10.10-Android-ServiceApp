package pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.view;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.afollestad.materialdialogs.MaterialDialog;
import com.jakewharton.rxbinding.support.v4.widget.RxSwipeRefreshLayout;

import java.util.List;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.model.api.OrderId;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.databinding.RecyclerPullViewFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.myorders.api.ClientOrdersApi;
import pl.mobilemanagement.izarzadca.tabs.myorders.di.DaggerMyOrdersComponent;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.pending.ask_again.AskProvidersAgainActivity;
import pl.mobilemanagement.izarzadca.tools.EarthlyLoadingDialog;
import pl.mobilemanagement.izarzadca.tools.LCE;
import pl.mobilemanagement.izarzadca.tools.api.ApiErrorDialogHelper;
import pl.mobilemanagement.izarzadca.tools.api.progress.ProgressHelper;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Observable;
import rx.Subscription;
import rx.subscriptions.CompositeSubscription;

public class PendingOrderTabFragment extends TitledTabFragment implements PendingOrderClickListener, LCE<Order>, View.OnClickListener {
    public CompositeSubscription compositeSubscription;

    public Subscription dataLoadSubscription;

    public MaterialDialog progressDialog;

    private RecyclerPullViewFrameBinding binding;

    @Inject
    ClientOrdersApi clientOrdersApi;

    private EarthlyLoadingDialog earthlyDialog;

    private PendingOrdersAdapter ordersAdapter;

    @Override
    public int getTitleResource() {
        return R.string.my_order_tab_wait_for_contractor;
    }

    @Override
    protected int getLayout() {
        return R.layout.recycler_pull_view_frame;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DaggerMyOrdersComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        binding = RecyclerPullViewFrameBinding.bind(view);
        compositeSubscription = new CompositeSubscription();
        initRecyclerView();
        dataLoadSubscription = fetchPendingOrders().subscribe();
        compositeSubscription.add(RxSwipeRefreshLayout.refreshes(binding.refreshLayout)
                .flatMap(aVoid -> fetchPendingOrders())
                .subscribe());
        binding.noItems.noItemsMessage.setText(getString(R.string.no_orders));
        binding.noItems.btnRefresh.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnRefresh) {
            dataLoadSubscription = fetchPendingOrders().subscribe();
        }
    }

    private void initRecyclerView() {
        ordersAdapter = new PendingOrdersAdapter(this);
        binding.listRecyclerView.setAdapter(ordersAdapter);
    }

    private Observable<List<Order>> fetchPendingOrders() {
        hideProgressBar();
        Rx.safeUnsubscribe(dataLoadSubscription);
        return clientOrdersApi.getPendingOrders()
                .compose(Rx.applySchedulers())
                .compose(Rx.applyLCE(this))
                .compose(Rx.applyDataLoader(this));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        compositeSubscription.unsubscribe();
    }

    @Override
    public void setData(List<Order> data) {
        ordersAdapter.setDataList(data);
        binding.noItems.getRoot().setVisibility(data.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onCancelClick(Order order) {
        hideProgressBar();
        showProgressBar();
        compositeSubscription.add(clientOrdersApi.deletePendingOrder(new OrderId(order.id))
                .compose(Rx.applySchedulers())
                .flatMap(aVoid -> fetchPendingOrders())
                .doOnUnsubscribe(() -> ProgressHelper.safeDismiss(earthlyDialog))
                .subscribe(orders -> hideProgressBar(), throwable -> {
                    hideProgressBar();
                    ApiErrorDialogHelper.show(getContext(), throwable);
                }));
    }

    @Override
    public void onAskAgainClick(Order order) {
        AskProvidersAgainActivity.start(getContext(), order.id, order.issueDescription);
    }

    @Override
    public void showProgressBar() {
        earthlyDialog = ProgressHelper.showEarthly(getChildFragmentManager());
        //        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgressBar() {
        //        progressBar.setVisibility(View.GONE);
        ProgressHelper.safeDismiss(earthlyDialog);
        binding.refreshLayout.setRefreshing(false);
    }

    @Override
    public void hideError() {
        binding.noItems.getRoot().setVisibility(View.GONE);
        binding.listError.setVisibility(View.GONE);
    }

    @Override
    public void showEmptyListError() {
        binding.noItems.getRoot().setVisibility(View.VISIBLE);
    }

    @Override
    public void showConnectionError() {
        binding.noItems.getRoot().setVisibility(View.GONE);
        binding.listError.setVisibility(View.VISIBLE);
        binding.listError.setText(R.string.list_view_connection_error);
    }

    /*@Override
    public void onTargetNotification(Observable<Message> oMessage) {
        oMessage.subscribe(message -> {
            fetchPendingOrders();
        });
    }

    @Override
    public void onMismatchTargetNotification(Observable<Message> oMessage) {

    }

    @Override
    public boolean matchesTarget(String key) {
        return PushType.parseOf(key) == PushType.CLIENT_ORDER_ACCEPTED;
    }*/
}
