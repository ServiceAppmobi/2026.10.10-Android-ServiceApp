package pl.mobilemanagement.izarzadca.start_screen.register;

public interface OnTitleChangedListener {
    void titleChange(CharSequence newTitle);
}