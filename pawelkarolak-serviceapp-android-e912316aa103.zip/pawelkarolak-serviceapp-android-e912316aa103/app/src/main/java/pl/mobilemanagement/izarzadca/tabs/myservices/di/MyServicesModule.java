package pl.mobilemanagement.izarzadca.tabs.myservices.di;

import dagger.Module;
import dagger.Provides;
import pl.mobilemanagement.izarzadca.common.di.api.Auth;
import pl.mobilemanagement.izarzadca.tabs.myservices.common.api.ProviderOrdersApi;
import retrofit2.Retrofit;

@Module
public class MyServicesModule {

    @Provides
    @MyServicesScope
    public ProviderOrdersApi providesProviderOrdersApi(@Auth Retrofit retrofit) {
        return retrofit.create(ProviderOrdersApi.class);
    }
}