package pl.mobilemanagement.izarzadca.common.model.api;

import java.io.Serializable;

public class BraintreeCheckoutResult implements Serializable {

    public String transactionId;
    public String status;

}
