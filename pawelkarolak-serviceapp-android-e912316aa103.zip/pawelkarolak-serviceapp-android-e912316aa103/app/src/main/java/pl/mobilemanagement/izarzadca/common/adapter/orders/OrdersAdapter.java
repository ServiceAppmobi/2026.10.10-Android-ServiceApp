package pl.mobilemanagement.izarzadca.common.adapter.orders;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.adapter.RowAdapter;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.tools.DateUtil;
import pl.mobilemanagement.izarzadca.tools.StringUtil;

public abstract class OrdersAdapter<K extends OrdersAdapter.VH> extends RowAdapter<Order, K> {
    @Override
    public long getItemId(int position) {
        return getItem(position).id.hashCode();
    }

    public abstract static class VH extends OrderRowViewHolder {

        @Nullable
        protected TextView dateTitle;

        protected TextView serviceTypeSubtitle;

        @Nullable
        protected View orderProviderFrame;

        @Nullable
        protected TextView serviceProviderName;

        protected TextView serviceLocation;

        public VH(View itemView) {
            super(itemView);
            dateTitle = itemView.findViewById(R.id.dateTitle);
            serviceTypeSubtitle = itemView.findViewById(R.id.serviceTypeSubtitle);
            orderProviderFrame = itemView.findViewById(R.id.orderProviderFrame);
            serviceProviderName = itemView.findViewById(R.id.serviceType);
            serviceLocation = itemView.findViewById(R.id.customerDetails);
        }

        public void bind(Order item) {
            if (dateTitle != null) {
                String formatDateRange = DateUtil.getFormattedDate(dateTitle.getContext(), item.startDateTime, item.endDateTime);
                dateTitle.setText(formatDateRange);
            }
            serviceTypeSubtitle.setText(item.serviceName);
            String location = getLocation(item);
            serviceLocation.setText(location);
            if (StringUtil.isEmpty(item.serviceProvider)) {
                if (orderProviderFrame != null)
                    orderProviderFrame.setVisibility(View.GONE);
                else if (serviceProviderName != null)
                    serviceProviderName.setVisibility(View.GONE);
            } else {
                if (orderProviderFrame != null)
                    orderProviderFrame.setVisibility(View.VISIBLE);
                else if (serviceProviderName != null)
                    serviceProviderName.setVisibility(View.VISIBLE);
            }
            if (serviceProviderName != null)
                serviceProviderName.setText(item.serviceProvider);
        }

        @NonNull
        private String getLocation(Order item) {
            String location = item.street;
            if (item.number != null) {
                location += " " + item.number;
            }
            location += ", " + item.postalCode + " " + item.city;
            return location;
        }


    }
}
