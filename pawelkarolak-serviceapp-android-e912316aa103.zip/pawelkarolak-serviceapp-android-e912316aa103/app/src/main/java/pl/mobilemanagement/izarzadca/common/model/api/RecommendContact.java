package pl.mobilemanagement.izarzadca.common.model.api;

import java.util.List;

public class RecommendContact {
    List<ContactApiModel> contacts;

    public RecommendContact(List<ContactApiModel> contacts) {
        this.contacts = contacts;
    }
}