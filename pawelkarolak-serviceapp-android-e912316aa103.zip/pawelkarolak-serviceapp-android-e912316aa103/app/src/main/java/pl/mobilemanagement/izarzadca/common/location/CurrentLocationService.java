package pl.mobilemanagement.izarzadca.common.location;

import android.app.Activity;
import android.location.Address;
import android.location.Location;

import com.google.android.gms.location.LocationRequest;

import pl.charmas.android.reactivelocation.ReactiveLocationProvider;
import rx.Observable;

public class CurrentLocationService {
    private final ReactiveLocationProvider locationProvider;

    public CurrentLocationService(Activity activity) {
        this.locationProvider = new ReactiveLocationProvider(activity);
    }

    @SuppressWarnings({"MissingPermission"})
    public Observable<Location> fetchCurrentGPSPosition() {
        LocationRequest request = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setNumUpdates(1);

        return locationProvider.getUpdatedLocation(request);
    }

    public Observable<Address> getReverseGeocodeObservable(Location location) {
        return locationProvider.getReverseGeocodeObservable(location.getLatitude(), location.getLongitude(), 1)
                .map(addresses -> addresses.get(0));
    }
}
