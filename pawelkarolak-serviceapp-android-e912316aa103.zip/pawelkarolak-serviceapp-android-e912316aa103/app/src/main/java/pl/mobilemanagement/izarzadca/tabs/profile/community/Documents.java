package pl.mobilemanagement.izarzadca.tabs.profile.community;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.Arrays;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.badge.MyOrderBadge;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabsFragmentAdapter;
import pl.mobilemanagement.izarzadca.databinding.TabMyCommunityBinding;
import pl.mobilemanagement.izarzadca.tabs.TabFragment;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.DocumentsAnnouncements;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.DocumentsApplications;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by katak on 10.01.2017.
 */
/*
 * Wspolnota
 * Informacje
 * Finanse
 * Czlonkowie
 * */
public class Documents extends TabFragment {
    TabLayout tabLayout;
    ViewPager viewPager;

    @Inject
    MyOrderBadge myOrderBadgeListener;

    public Documents() {
        App.component.inject(this);
    }

    @Override
    public int getIconResource() {
        return R.drawable.ico_tab_my_orders;
    }

    @Override
    public int getTitleResource() {
        return R.string.tab_my_community;
    }

    @Override
    protected int getLayout() {
        return R.layout.tab_my_community;
    }

    @Override
    public void onViewCreated(@NotNull View view, @Nullable Bundle savedInstanceState) {
        TabMyCommunityBinding binding = TabMyCommunityBinding.bind(view);
        tabLayout = binding.CommunityTabLayout;
        viewPager = binding.CommunityViewPager;

        try {
            Bundle bundle = getArguments();
            Serializable usicList = bundle.getSerializable("result");

            Log.i("TEST", String.valueOf(usicList));
            Toast.makeText(getContext(), getString(R.string.post_failure_send), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.i("TEST", "BRAK");
        }

        TitledTabsFragmentAdapter<TitledTabFragment> tabsFragmentAdapter = new TitledTabsFragmentAdapter<>(
            getContext(),
            getChildFragmentManager(),
            Arrays.asList(
                new DocumentsApplications(),
                new DocumentsAnnouncements()
            )
        );
        viewPager.setAdapter(tabsFragmentAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }

    @Override
    protected void bindTabView(View indicator) {
        myOrderBadgeListener.getBadgeIsAvailable()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(hasUnreaded -> {
                    indicator.setVisibility(hasUnreaded ? View.VISIBLE : View.GONE);
                });
    }

    @Override
    public void onResume() {
        super.onResume();
        myOrderBadgeListener.informBadgeWatched();
    }

    /*@Override
    public void onTargetNotification(Observable<Message> oMessage) {
        oMessage.subscribe(message -> {
            myOrderBadgeListener.informBadgeWatched();
        });
    }

    @Override
    public void onMismatchTargetNotification(Observable<Message> oMessage) {

    }

    @Override
    public boolean matchesTarget(String key) {
        return PushType.isMyOrderPush(key);
    }*/
}
