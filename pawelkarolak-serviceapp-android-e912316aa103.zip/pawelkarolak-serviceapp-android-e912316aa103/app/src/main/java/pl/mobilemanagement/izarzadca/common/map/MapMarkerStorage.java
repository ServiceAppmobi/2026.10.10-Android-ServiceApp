package pl.mobilemanagement.izarzadca.common.map;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

public class MapMarkerStorage {
    private List<Marker> previousMarkers = new ArrayList<>();


    public void removePreviousMarkers() {
        for (Marker previousMarker : previousMarkers) {
            previousMarker.remove();
        }
    }

    public void addMarkers(GoogleMap googleMap, List<MarkerOptions> markerOptionList) {
        for (MarkerOptions orderMarker : markerOptionList) {
            final Marker marker = googleMap.addMarker(orderMarker);
            previousMarkers.add(marker);
        }
    }

}
