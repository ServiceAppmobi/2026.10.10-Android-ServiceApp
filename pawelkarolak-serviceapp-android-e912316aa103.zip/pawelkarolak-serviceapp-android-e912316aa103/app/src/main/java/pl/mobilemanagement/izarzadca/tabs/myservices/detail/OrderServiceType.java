package pl.mobilemanagement.izarzadca.tabs.myservices.detail;

public enum OrderServiceType {
    PENDING, DURING, ENDED
}
