package pl.mobilemanagement.izarzadca.tabs.profile.api;

public class ChangePasswordApiModel {

    public final String currentPassword;
    public final String newPassword;

    public ChangePasswordApiModel(String currentPassword, String newPassword) {
        this.currentPassword = currentPassword;
        this.newPassword = newPassword;
    }
}
