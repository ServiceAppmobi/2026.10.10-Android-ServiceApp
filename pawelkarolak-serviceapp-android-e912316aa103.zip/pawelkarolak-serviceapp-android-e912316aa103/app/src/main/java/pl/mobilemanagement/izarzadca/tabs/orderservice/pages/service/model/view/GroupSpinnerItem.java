package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.view;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceGroup;
import pl.mobilemanagement.izarzadca.tools.spinner.SpinnerItem;


public class GroupSpinnerItem implements SpinnerItem {

    private final ServiceGroup serviceGroup;

    public GroupSpinnerItem(ServiceGroup serviceGroup) {
        this.serviceGroup = serviceGroup;
    }


    public ServiceGroup getServiceGroup() {
        return serviceGroup;
    }

    @Override
    public String toString() {
        return serviceGroup.name;
    }
}