package pl.mobilemanagement.izarzadca.common.viewpager;

import pl.mobilemanagement.izarzadca.tools.BaseFragment;

public abstract class TitledTabFragment extends BaseFragment {

    public abstract int getTitleResource();

}
