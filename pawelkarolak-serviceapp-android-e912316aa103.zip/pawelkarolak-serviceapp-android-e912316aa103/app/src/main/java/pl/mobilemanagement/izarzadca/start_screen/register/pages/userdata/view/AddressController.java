package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.view;

import android.content.Context;
import android.text.InputFilter;
import android.widget.EditText;

import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.map.Address;
import pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.FlatNumberValidator;
import pl.mobilemanagement.izarzadca.tools.Validator;

import static pl.mobilemanagement.izarzadca.tools.EditTextHelper.getTrimmedText;

public class AddressController {

    private static final int MIN_TOWN_LENGTH = 2;
    private static final int MAX_CITY_LENGTH = 200;
    private static final int MIN_POSTAL_LENGTH = 5;
    private static final int MAX_POSTAL_LENGTH = 50;
    private static final int MIN_STREET_LENGTH = 2;
    private static final int MAX_STREET_LENGTH = 300;
    private static final int MAX_FLAT_LENGTH = 6;

    final private EditText street;
    final private EditText flat;
    final private EditText postalCode;
    final private EditText city;

    public AddressController(EditText city, EditText postalCode, EditText street, EditText flat) {
        this.street = street;
        this.flat = flat;
        this.postalCode = postalCode;
        this.city = city;
        initViews();
    }


    private void initViews() {
        street.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_STREET_LENGTH)});
        postalCode.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_POSTAL_LENGTH)});
        city.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_CITY_LENGTH)});
        flat.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_FLAT_LENGTH)});
    }


    public String getFlat() {
        return getTrimmedText(flat);
    }

    public String getPostalCode() {
        return getTrimmedText(postalCode);
    }

    public String getStreet() {
        return getTrimmedText(street);
    }

    public String getTown() {
        return getTrimmedText(city);
    }

    public Validator validateInput() {
        Validator validator = new Validator();
        if (getTown().length() < MIN_TOWN_LENGTH) {
            validator.addError(getContext().getString(R.string.user_data_no_town));
        }
        if (getStreet().length() < MIN_STREET_LENGTH) {
            validator.addError(getContext().getString(R.string.user_data_no_street));
        }
        if (getPostalCode().length() < MIN_POSTAL_LENGTH) {
            validator.addError(getContext().getString(R.string.user_data_wrong_postal_code));
        }
        if (getFlat().isEmpty()) {
            validator.addError(getContext().getString(R.string.user_data_no_flat));
        }
        if (!new FlatNumberValidator().isValid(getFlat())) {
            validator.addError(getContext().getString(R.string.user_data_wrong_flat_format));
        }
        return validator;
    }

    public void restoreState(Address address) {
        city.setText(address.getTown());
        postalCode.setText(address.getPostalCode());
        street.setText(address.getStreet());
        flat.setText(address.getFlat());
    }

    private Context getContext() {
        return street.getContext();
    }

    public Address getAddress() {
        return new Address(getTown(), getPostalCode(), getStreet(), getFlat());
    }

}