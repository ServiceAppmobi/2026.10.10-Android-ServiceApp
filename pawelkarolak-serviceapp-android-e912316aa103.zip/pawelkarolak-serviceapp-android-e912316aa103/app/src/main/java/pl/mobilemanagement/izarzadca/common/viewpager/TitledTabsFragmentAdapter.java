package pl.mobilemanagement.izarzadca.common.viewpager;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import java.util.List;

public class TitledTabsFragmentAdapter<T extends TitledTabFragment> extends TabsFragmentAdapter<T> {
    private final Context context;

    public TitledTabsFragmentAdapter(Context context, @NonNull FragmentManager fm, @NonNull List<T> tabFragments) {
        super(fm, tabFragments);
        this.context = context;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        TitledTabFragment page = getItem(position);
        return getTitleFromPage(page);
    }

    private String getTitleFromPage(TitledTabFragment page) {
        final int titleResource = page.getTitleResource();
        return context.getString(titleResource);
    }
}