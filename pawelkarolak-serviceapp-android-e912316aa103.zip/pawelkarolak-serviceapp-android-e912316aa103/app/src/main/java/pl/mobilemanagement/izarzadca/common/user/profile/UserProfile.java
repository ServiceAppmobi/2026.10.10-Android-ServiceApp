package pl.mobilemanagement.izarzadca.common.user.profile;

import java.util.List;

import pl.mobilemanagement.izarzadca.common.user.AccountType;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;

public class UserProfile {
    public String userId;
    public AccountType accountType;
    public String accountName;
    public String name;
    public String lastName;
    public String image;
    public String email;
    public String street;
    public String number;
    public String postalCode;
    public String city;
    public String country;
    public String countryId;
    public String phone;
    public String companyName;
    public String nip;
    public String companyDescription;
    public int companyBusinessAreaId;
    public String companyBusinessArea;
    public boolean orderAcceptingFee;
    public String priceList;
    public boolean convertBalance;


    public List<ServiceModel> providedServices;

    public SimplifyCreditCard card;
    public double lng;
    public double lat;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserProfile that = (UserProfile) o;

        if (companyBusinessAreaId != that.companyBusinessAreaId) return false;
        if (Double.compare(that.lng, lng) != 0) return false;
        if (Double.compare(that.lat, lat) != 0) return false;
        if (accountType != that.accountType) return false;
        if (accountName != null ? !accountName.equals(that.accountName) : that.accountName != null)
            return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (lastName != null ? !lastName.equals(that.lastName) : that.lastName != null)
            return false;
        if (image != null ? !image.equals(that.image) : that.image != null) return false;
        if (email != null ? !email.equals(that.email) : that.email != null) return false;
        if (street != null ? !street.equals(that.street) : that.street != null) return false;
        if (number != null ? !number.equals(that.number) : that.number != null) return false;
        if (postalCode != null ? !postalCode.equals(that.postalCode) : that.postalCode != null)
            return false;
        if (city != null ? !city.equals(that.city) : that.city != null) return false;
        if (country != null ? !country.equals(that.country) : that.country != null) return false;
        if (countryId != null ? !countryId.equals(that.countryId) : that.countryId != null)
            return false;
        if (phone != null ? !phone.equals(that.phone) : that.phone != null) return false;
        if (companyName != null ? !companyName.equals(that.companyName) : that.companyName != null)
            return false;
        if (nip != null ? !nip.equals(that.nip) : that.nip != null) return false;
        if (companyDescription != null ? !companyDescription.equals(that.companyDescription) : that.companyDescription != null)
            return false;
        if (companyBusinessArea != null ? !companyBusinessArea.equals(that.companyBusinessArea) : that.companyBusinessArea != null)
            return false;
        if (providedServices != null ? !providedServices.equals(that.providedServices) : that.providedServices != null)
            return false;
        if (orderAcceptingFee != that.orderAcceptingFee)
            return false;
        if (priceList != null ? !priceList.equals(that.priceList) : that.priceList != null)
            return false;
        if (convertBalance != that.convertBalance)
            return false;
        return card != null ? card.equals(that.card) : that.card == null;

    }

    public boolean hasAdress() {
        return postalCode != null && city != null && street != null && number != null;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = accountType != null ? accountType.hashCode() : 0;
        result = 31 * result + (accountName != null ? accountName.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (lastName != null ? lastName.hashCode() : 0);
        result = 31 * result + (image != null ? image.hashCode() : 0);
        result = 31 * result + (email != null ? email.hashCode() : 0);
        result = 31 * result + (street != null ? street.hashCode() : 0);
        result = 31 * result + (number != null ? number.hashCode() : 0);
        result = 31 * result + (postalCode != null ? postalCode.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (country != null ? country.hashCode() : 0);
        result = 31 * result + (countryId != null ? countryId.hashCode() : 0);
        result = 31 * result + (phone != null ? phone.hashCode() : 0);
        result = 31 * result + (companyName != null ? companyName.hashCode() : 0);
        result = 31 * result + (nip != null ? nip.hashCode() : 0);
        result = 31 * result + (companyDescription != null ? companyDescription.hashCode() : 0);
        result = 31 * result + companyBusinessAreaId;
        result = 31 * result + (companyBusinessArea != null ? companyBusinessArea.hashCode() : 0);
        result = 31 * result + (providedServices != null ? providedServices.hashCode() : 0);
        result = 31 * result + (card != null ? card.hashCode() : 0);
        result = 31 * result + (orderAcceptingFee ? 1 : 0);
        result = 31 * result + (priceList != null ? priceList.hashCode() : 0);
        result = 31 * result + (convertBalance ? 1 : 0);
        temp = Double.doubleToLongBits(lng);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(lat);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    public boolean isProvider() {
        return accountType != null && accountType.isProvider();
    }
}
