package pl.mobilemanagement.izarzadca.common.map;

import android.content.Context;
import android.graphics.Bitmap;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

import pl.mobilemanagement.izarzadca.tools.StringUtil;

public class MapCircleFactory {

    public static List<MarkerOptions> createServiceOrdersMarkers(Context context, List<LatLng> latLngs) {
        final List<MarkerOptions> markerOptionsList = new ArrayList<>(latLngs.size());
        for (int i = 0; i < latLngs.size(); i++) {
            final LatLng pos = latLngs.get(i);
            final String letter = StringUtil.getNumberForPosition(i);
            final Bitmap bitmap = new BitpamCircleWithCharacter(context).drawCharacterAtCenter(letter);
            final MarkerOptions marker = new MarkerOptions()
                    .position(pos)
                    .icon(BitmapDescriptorFactory
                            .fromBitmap(bitmap)).anchor(0.5f, 1);
            markerOptionsList.add(marker);
        }
        return markerOptionsList;
    }
}
