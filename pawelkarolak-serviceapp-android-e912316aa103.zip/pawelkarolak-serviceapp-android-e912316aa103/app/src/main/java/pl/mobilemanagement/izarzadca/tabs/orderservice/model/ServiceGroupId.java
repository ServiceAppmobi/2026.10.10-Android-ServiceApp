package pl.mobilemanagement.izarzadca.tabs.orderservice.model;

public class ServiceGroupId {

    public final String serviceGroupId;

    public ServiceGroupId(String serviceGroupId) {
        this.serviceGroupId = serviceGroupId;
    }
}


