package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CheckLoginOccupation {
    @Expose
    @SerializedName("login")
    String login;

    @Expose
    @SerializedName("email")
    String email;

    public CheckLoginOccupation(String login, String email) {
        this.login = login;
        this.email = email;
    }
}
