package pl.mobilemanagement.izarzadca.common.notification;

import java.util.HashMap;
import java.util.Map;

public enum PushType {
    PROVIDER_NEW_PENDING("ProviderServicePending"),
    CLIENT_ORDER_ACCEPTED("ClientServiceAccepted"),
    PROVIDER_SERVICE_CLOSED("ProviderServiceClosed"),
    PROVIDER_SERVICE_RATED("ProviderServiceRating");
    private static Map<String, PushType> map = new HashMap<>();

    static {
        for (PushType pushEnum : PushType.values()) {
            map.put(pushEnum.name, pushEnum);
        }
    }

    private final String name;

    PushType(String name) {
        this.name = name;
    }

    public static PushType parseOf(String pushType) {
        return map.get(pushType);
    }

    public static boolean isMyOrderPush(String key) {
        final PushType pushType = parseOf(key);
        return CLIENT_ORDER_ACCEPTED == pushType;
    }

    public static boolean isServicesPush(String key) {
        final PushType pushType = parseOf(key);
        return PROVIDER_NEW_PENDING == pushType ||
                PROVIDER_SERVICE_RATED == pushType ||
                PROVIDER_SERVICE_CLOSED == pushType;
    }
}

