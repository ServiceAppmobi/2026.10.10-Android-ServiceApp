package pl.mobilemanagement.izarzadca.start_screen.register

import rx.functions.Action0

interface LocationListener {
    fun requestLocationPermissions(onSuccess: Action0)
}