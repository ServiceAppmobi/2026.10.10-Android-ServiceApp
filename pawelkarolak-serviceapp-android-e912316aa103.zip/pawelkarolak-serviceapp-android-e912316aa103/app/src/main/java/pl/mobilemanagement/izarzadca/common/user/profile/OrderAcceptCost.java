package pl.mobilemanagement.izarzadca.common.user.profile;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class OrderAcceptCost implements Serializable {

    @SerializedName("value")
    public boolean value;
    @SerializedName("price")
    public String price;
    @SerializedName("currency")
    public String currency;

}
