package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.view.impl;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.databinding.RecyclerViewFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.orderservice.api.OrderServiceApi;
import pl.mobilemanagement.izarzadca.tabs.orderservice.model.ProviderOpinionsApiModel;
import pl.mobilemanagement.izarzadca.tabs.orderservice.model.UserId;
import pl.mobilemanagement.izarzadca.tools.LCE;
import pl.mobilemanagement.izarzadca.tools.Recycler;
import pl.mobilemanagement.izarzadca.tools.rx.Rx;
import rx.Subscription;

public class CompanyOpinionDialog implements LCE<ProviderOpinionsApiModel> {
    private final Dialog dialog;
    private final OrderServiceApi orderServiceApi;
    private final CompanyOpionAdapter companyOpionAdapter = new CompanyOpionAdapter();
    public Subscription subscription;

    ProgressBar listProgress;
    TextView listError;
    RecyclerView listRecyclerView;

    public CompanyOpinionDialog(Context context, OrderServiceApi orderServiceApi) {
        this.orderServiceApi = orderServiceApi;

        final Dialog dialog = new Dialog(context);
        dialog.setOnDismissListener(dialog1 -> Rx.safeUnsubscribe(subscription));

        RecyclerViewFrameBinding binding = RecyclerViewFrameBinding.inflate(LayoutInflater.from(context));
        dialog.setContentView(binding.getRoot());

        listProgress = binding.listProgress;
        listError = binding.listError;
        listRecyclerView = binding.listRecyclerView;

        this.dialog = dialog;

        Recycler.initVerticalRecyclerView(listRecyclerView);
        listRecyclerView.setAdapter(companyOpionAdapter);
    }

    public void show(String providerId) {
        dialog.show();
        subscription = orderServiceApi.getProviderOpinion(new UserId(providerId))
                .compose(Rx.applySchedulers())
                .compose(Rx.applyLCE(this))
                .subscribe();
    }

    public void hide() {
        Rx.safeUnsubscribe(subscription);
        dialog.hide();
    }

    @Override
    public void showProgressBar() {
        listProgress.setVisibility(View.VISIBLE);
        listRecyclerView.setVisibility(View.INVISIBLE);
    }

    @Override
    public void hideProgressBar() {
        listProgress.setVisibility(View.GONE);
    }

    @Override
    public void hideError() {
        listError.setVisibility(View.GONE);
    }

    @Override
    public void showEmptyListError() {
        listError.setVisibility(View.VISIBLE);
        listError.setText(R.string.service_opinion_empty);
    }

    @Override
    public void showConnectionError() {
        listError.setVisibility(View.VISIBLE);
        listError.setText(R.string.connection_error);
    }

    @Override
    public void setData(List<ProviderOpinionsApiModel> data) {
        listRecyclerView.setVisibility(View.VISIBLE);
        companyOpionAdapter.setDataList(data);
    }
}
