package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

import org.jetbrains.annotations.NotNull;

import java.text.Format;
import java.text.SimpleDateFormat;

import javax.inject.Inject;

import pl.mobilemanagement.izarzadca.App;
import pl.mobilemanagement.izarzadca.R;
import pl.mobilemanagement.izarzadca.common.model.api.Order;
import pl.mobilemanagement.izarzadca.common.viewpager.TitledTabFragment;
import pl.mobilemanagement.izarzadca.databinding.BillsSummaryFrameBinding;
import pl.mobilemanagement.izarzadca.tabs.myorders.tabs.accepted.view.CloseOrderClickListener;
import pl.mobilemanagement.izarzadca.tabs.profile.community.api.CommunityApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.di.DaggerMyCommunityComponent;
import pl.mobilemanagement.izarzadca.tabs.profile.community.model.RentBalance;
import rx.Observable;
import rx.Subscription;
import rx.schedulers.Schedulers;

/**
 * Created by katak on 10.01.2017.
 */

public class BillsSummary extends TitledTabFragment implements CloseOrderClickListener {

    @Inject
    CommunityApi communityApi;


    TextView serviceDetailsPay;
    TextView TcreateDate;
    TextView TpaymentDate;
    TextView TserviceDetailsB;

    private Subscription fetchSubscription;

    @Override
    public int getTitleResource() {
        return R.string.tab_my_ballance;
    }

    @Override
    public void onCloseOrderClick(Order order) {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        DaggerMyCommunityComponent.builder()
                .applicationComponent(App.component)
                .build()
                .inject(this);
    }

    @Override
    public void onResume() {
        Log.i("BillsSummary", "onResume");
        super.onResume();
        fetchSubscription = getRentBalance().subscribe();
    }

    public Observable<RentBalance> getRentBalance() {
        return communityApi.getRentBalance()
                .doOnNext(this::setData)
                .doOnError(this::showConnectionError)
                .onErrorResumeNext(throwable -> Observable.empty())
                .subscribeOn(Schedulers.io());
    }

    private void setData(RentBalance rentBalance) {
        Log.i("BillsSummary", "setData");
        Log.i("BillsSummary", String.valueOf(rentBalance.balance));

        Handler txtsettext = new Handler(Looper.getMainLooper());
        txtsettext.post(() -> {

            serviceDetailsPay.setText(rentBalance.balance);

            if (rentBalance.balance.toLowerCase().contains("-"))
                serviceDetailsPay.setTextColor(Color.RED);

            Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            if (rentBalance.lastRent != null) {
                String createDate = "-";
                String paymentDate = "-";
                if (rentBalance.lastRent.createDate != null) {
                    createDate = formatter.format(rentBalance.lastRent.createDate);
                }
                if (rentBalance.lastRent.paymentDate != null) {
                    paymentDate = formatter.format(rentBalance.lastRent.paymentDate);
                }
                TcreateDate.setText(createDate);
                TpaymentDate.setText(paymentDate);

                TserviceDetailsB.setText(rentBalance.lastRent.amount);
            }
        });
    }


    public void showConnectionError(Throwable message) {
        serviceDetailsPay.setText("Wystąpił błąd połączenia");
        Log.e("BillsSummary", "showConnectionError");
        Log.e("BillsSummary", String.valueOf(message));

    }

    @Override
    public void onViewCreated(@NotNull View view, @Nullable Bundle savedInstanceState) {
        Log.i("BillsSummary", "onViewCreated");
        super.onViewCreated(view, savedInstanceState);

        BillsSummaryFrameBinding binding = BillsSummaryFrameBinding.bind(view);
        serviceDetailsPay = binding.serviceDetailsA;
        TcreateDate = binding.biillsSummary1;
        TpaymentDate = binding.biillsSummary2;
        TserviceDetailsB = binding.serviceDetailsB;
    }


    @Override
    protected int getLayout() {
        return R.layout.bills_summary_frame;
    }
}
