package pl.mobilemanagement.izarzadca.tabs.orderservice.model;

import com.google.gson.annotations.Expose;

public class UserId {
    @Expose
    public final String userId;

    public UserId(String userId) {
        this.userId = userId;
    }
}


