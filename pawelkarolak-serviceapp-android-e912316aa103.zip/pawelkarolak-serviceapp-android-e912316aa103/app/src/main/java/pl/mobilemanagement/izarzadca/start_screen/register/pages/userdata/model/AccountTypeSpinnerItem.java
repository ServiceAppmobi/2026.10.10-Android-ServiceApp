package pl.mobilemanagement.izarzadca.start_screen.register.pages.userdata.model;

import java.util.ArrayList;
import java.util.List;

import pl.mobilemanagement.izarzadca.common.model.entity.AccountTypeName;
import pl.mobilemanagement.izarzadca.tools.spinner.SpinnerItem;

public class AccountTypeSpinnerItem implements SpinnerItem {
    private AccountTypeName accountTypeName;

    public AccountTypeSpinnerItem(AccountTypeName accountTypeName) {
        this.accountTypeName = accountTypeName;
    }

    public static List<AccountTypeSpinnerItem> createSpinnerItems(List<AccountTypeName> accountTypeNames) {
        final List<AccountTypeSpinnerItem> accountTypeSpinnerItems = new ArrayList<>();
        for (AccountTypeName accountTypeName : accountTypeNames) {
            accountTypeSpinnerItems.add(new AccountTypeSpinnerItem(accountTypeName));
        }
        return accountTypeSpinnerItems;
    }

    @Override
    public String toString() {
        return accountTypeName.name;
    }

    public AccountTypeName getAccountTypeName() {
        return accountTypeName;
    }
}
