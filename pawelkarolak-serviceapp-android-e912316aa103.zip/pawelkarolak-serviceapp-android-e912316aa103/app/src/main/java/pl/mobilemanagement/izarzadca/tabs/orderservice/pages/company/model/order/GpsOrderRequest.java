package pl.mobilemanagement.izarzadca.tabs.orderservice.pages.company.model.order;

import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.place.model.GPSPlace;

public class GpsOrderRequest extends OrderRequest {
    final String lat;
    final String lng;

    public GpsOrderRequest(GPSPlace place) {
        super(place);
        lat = place.latGps;
        lng = place.longGps;
    }
}
