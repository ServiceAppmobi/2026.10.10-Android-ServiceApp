package pl.mobilemanagement.izarzadca.tabs.file_manager

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProviders
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.bumptech.glide.Glide
import com.rajat.pdfviewer.PdfViewerActivity
//import com.rajat.pdfviewer.PdfViewerActivity
import com.stfalcon.imageviewer.StfalconImageViewer
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import pl.mobilemanagement.izarzadca.App
import pl.mobilemanagement.izarzadca.common.di.DaggerViewModelFactory
import pl.mobilemanagement.izarzadca.databinding.FragmentFileManagerBinding
import javax.inject.Inject

class FileManagerFragment : Fragment(), FileManagerAdapter.Listener {

    private lateinit var binding: FragmentFileManagerBinding

    @Inject
    lateinit var viewModelFactory: DaggerViewModelFactory

    private lateinit var viewModel : FileManagerViewModel

    private val fileManagerAdapter = FileManagerAdapter(this)

    private lateinit var file: File

    private val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
    ) {
        if (it) {
            viewModel.downloadFile(file)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.component.inject(this)
        viewModel = ViewModelProviders.of(this, viewModelFactory)[FileManagerViewModel::class.java]
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        binding = FragmentFileManagerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvFiles.adapter = fileManagerAdapter
        observe()
    }

    private fun observe() {
        viewModel.loading.observe(viewLifecycleOwner) {
            binding.progressBar.isVisible = it
        }
        viewModel.files.observe(viewLifecycleOwner) {
            fileManagerAdapter.submitList(it)
        }
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.openFile.collectLatest { (file, contentUri) ->
                    val extension = file.extension.lowercase()
                    val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
                    when {
                        extension == "pdf" -> {
                            startActivity(
                                PdfViewerActivity.launchPdfFromPath(
                                    context = requireContext(),
                                    path = file.absolutePath,
                                    pdfTitle = file.nameWithoutExtension,
                                    directoryName = null,
                                    enableDownload = false,
                                    fromAssets = false
                                )
                            )
                        }
                        mimeType?.startsWith("image") == true -> {
                            StfalconImageViewer.Builder(context, listOf(file.absolutePath)) { view, image ->
                                Glide.with(view).load(image).into(view)
                            }.show()
                        }
                        else -> {
                            val intent = Intent(Intent.ACTION_VIEW)
                            intent.setDataAndType(contentUri, mimeType)
                            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            startActivity(intent)
                        }
                    }
                }
            }
        }
    }

    override fun onItemClick(file: File) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            this.file = file
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            viewModel.downloadFile(file)
        }
    }

}