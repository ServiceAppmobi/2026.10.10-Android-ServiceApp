package pl.mobilemanagement.izarzadca.common.di.api;

import androidx.annotation.NonNull;

import com.google.gson.Gson;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;
import pl.mobilemanagement.izarzadca.BuildConfig;
import pl.mobilemanagement.izarzadca.common.notification.api.NotificationApi;
import pl.mobilemanagement.izarzadca.common.user.token.AccountTypeDataSource;
import pl.mobilemanagement.izarzadca.start_screen.login_or_register.SocialApiService;
import pl.mobilemanagement.izarzadca.tabs.file_manager.FileManagerApi;
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.HomeApi;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

@Module
public class ApiModule {

    @Provides
    @NonNull
    @Named("server_url")
    String provideBaseUrl(AccountTypeDataSource accountTypeDataSource) {
        String serverUrl =  accountTypeDataSource.getServerUrl();
        if (serverUrl == null || serverUrl.isEmpty())
            return AccountTypeDataSource.SERVER_URL_EU;
        return serverUrl;
    }

    @Provides
    @NonNull
    Retrofit provideNonAuthRetrofit(@NonNull OkHttpClient okHttpClient, @NonNull Gson gson, @Named("server_url") String serverUrl) {
        return getRetrofitBuilder(okHttpClient, gson, serverUrl)
                .build();
    }

    @Provides
    @NonNull
    @Auth
    Retrofit provideAuthRetrofit(@NonNull @Auth OkHttpClient okHttpClient, @NonNull Gson gson, @Named("server_url") String serverUrl) {
        return getRetrofitBuilder(okHttpClient, gson, serverUrl)
                .build();
    }

    @NonNull
    private Retrofit.Builder getRetrofitBuilder(@NonNull OkHttpClient okHttpClient, @NonNull Gson gson, String serverUrl) {
        return new Retrofit.Builder()
                .baseUrl(serverUrl)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .validateEagerly(BuildConfig.DEBUG);
    }

    //  Prod url:
    //  https://api.serviceapp.mobi/api/
    //  http://apiserviceappmobi-env.eba-bpckg86d.eu-west-2.elasticbeanstalk.com/api/
    //  Dev url:
    //  http://apiserviceappmobi-env-staging.eba-bpckg86d.eu-west-2.elasticbeanstalk.com/api/
    //  http://8e008904d19c.ngrok.io/api/

    @Provides
    @NonNull
    UnauthorizedApi provideIzarzadcaRegisterApi(@NonNull Retrofit retrofit) {
        return retrofit.create(UnauthorizedApi.class);
    }

    @Provides
    @NonNull
    NotificationApi provideNotificationApi(@NonNull @Auth Retrofit retrofit) {
        return retrofit.create(NotificationApi.class);
    }

    @Provides
    @NonNull
    SocialApiService provideSocialApiService(@NonNull Retrofit retrofit) {
        return retrofit.create(SocialApiService.class);
    }

    @Provides
    @NonNull
    HomeApi provideHomeApiService(@NonNull @Auth Retrofit retrofit) {
        return retrofit.create(HomeApi.class);
    }

    @Provides
    @NonNull
    FileManagerApi provideFileManagerApi(@NonNull @Auth Retrofit retrofit) {
        return retrofit.create(FileManagerApi.class);
    }

}

