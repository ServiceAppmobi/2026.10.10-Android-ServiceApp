package pl.mobilemanagement.izarzadca.tabs.myservices.pending.model;

public class StripePaymentAnswer {
    public String id;
    public String message;
}
