package pl.mobilemanagement.izarzadca.tabs.profile.edit.model;

import pl.mobilemanagement.izarzadca.common.user.AccountType;

public class UpdateUserApiModel {
    public final String name;
    public final String lastName;
    public final String email;
    public final String street;
    public final String number;
    public final String postalCode;
    public final String city;
    public final String countryId;
    public final String phone;
    public AccountType accountType;

    public UpdateUserApiModel(String name, String lastName, String email, String street, String number, String postalCode, String city, String countryId, String phone) {
        this.name = name;
        this.lastName = lastName;
        this.email = email;
        this.street = street;
        this.number = number;
        this.postalCode = postalCode;
        this.city = city;
        this.countryId = countryId;
        this.phone = phone;
        this.accountType = AccountType.CUSTOMER;
    }

    public UpdateUserApiModel(UpdateUserApiModel updateUserApiModel) {
        this.name = updateUserApiModel.name;
        this.lastName = updateUserApiModel.lastName;
        this.email = updateUserApiModel.email;
        this.street = updateUserApiModel.street;
        this.number = updateUserApiModel.number;
        this.postalCode = updateUserApiModel.postalCode;
        this.city = updateUserApiModel.city;
        this.countryId = updateUserApiModel.countryId;
        this.phone = updateUserApiModel.phone;
    }
}
