package pl.mobilemanagement.izarzadca.tabs.profile.api;

import java.util.List;

import pl.mobilemanagement.izarzadca.common.map.Address;
import pl.mobilemanagement.izarzadca.common.user.AccountType;
import pl.mobilemanagement.izarzadca.common.user.profile.SimplifyCreditCard;
import pl.mobilemanagement.izarzadca.common.user.profile.UserProfile;
import pl.mobilemanagement.izarzadca.tabs.orderservice.pages.service.model.ServiceModel;

import static java.lang.Double.parseDouble;

public class UserDataApiModel {
    public String userId;
    public String name;
    public String lastName;
    public String image;
    public String email;
    public String street;
    public String number;
    public String postalCode;
    public String city;
    public String country;
    public String countryId;
    public String phone;
    public String companyName;
    public String nip;
    public String companyDescription;
    public int accountType;
    public String accountName;
    public int companyBusinessAreaId;
    public String companyBusinessArea;
    public List<ServiceModel> providedServices;
    public SimplifyCreditCard creditCard;
    public String lng;
    public String lat;
    public boolean orderAcceptingFee;
    public String priceList;
    public boolean convertBalance;
    public String accessToken = "";
    public String userName = "";
    public boolean isProfessional;

    public Address getAddress() {
        return new Address(city, postalCode, street, number);
    }

    public UserProfile toPersonalData() {
        final UserProfile userData = new UserProfile();
        userData.accountType = AccountType.createAccountTypeFromInt(accountType);
        userData.accountName = accountName;

        userData.userId = userId;
        userData.name = name;
        userData.lastName = lastName;
        userData.image = image;
        userData.country = country;
        userData.countryId = countryId;
        userData.phone = phone;
        userData.postalCode = postalCode;
        userData.city = city;
        userData.street = street;
        userData.number = number;
        userData.email = email;

        userData.companyName = companyName;
        userData.nip = nip;
        userData.card = creditCard;

        userData.companyBusinessAreaId = companyBusinessAreaId;
        userData.companyBusinessArea = companyBusinessArea;
        userData.companyDescription = companyDescription;
        userData.providedServices = providedServices;

        userData.orderAcceptingFee = orderAcceptingFee;
        userData.priceList = priceList;
        userData.convertBalance = convertBalance;

        if(lat != null)
            userData.lat = parseDotDouble(lat);
        else
            userData.lat = 1.1;
        if(lng != null)
        userData.lng = parseDotDouble(lng);
        else
            userData.lng = 1.1;

        return userData;
    }
     private double parseDotDouble(String wrongFormatDouble) {
        return parseDouble(wrongFormatDouble.replace(',', '.'));
    }
}
