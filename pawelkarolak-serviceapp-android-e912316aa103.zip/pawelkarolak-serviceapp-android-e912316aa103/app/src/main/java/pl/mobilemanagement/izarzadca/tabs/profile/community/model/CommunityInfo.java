package pl.mobilemanagement.izarzadca.tabs.profile.community.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CommunityInfo implements Serializable {
    @SerializedName("name")
    public String name;
    @SerializedName("address")
    public String address;
    @SerializedName("nr")
    public String nr;
    @SerializedName("city")
    public String city;
    @SerializedName("postalCode")
    public String postalCode;
    @SerializedName("region")
    public String region;
    @SerializedName("country")
    public String country;
    @SerializedName("phone")
    public String phone;
    @SerializedName("email")
    public String email;
    @SerializedName("contact")
    public String contact;
    @SerializedName("skype")
    public String skype;
    @SerializedName("accountant")
    public String accountant;
    @SerializedName("phoneNr")
    public String phoneNr;
}
