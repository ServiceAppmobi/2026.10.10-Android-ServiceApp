package pl.mobilemanagement.izarzadca.tabs;

import pl.mobilemanagement.izarzadca.tabs.myservices.detail.OrderServiceType;

public interface ServiceDetailsPayClickListener {

    void onOrderDetailsPayClick(String orderId, OrderServiceType orderType);


}
