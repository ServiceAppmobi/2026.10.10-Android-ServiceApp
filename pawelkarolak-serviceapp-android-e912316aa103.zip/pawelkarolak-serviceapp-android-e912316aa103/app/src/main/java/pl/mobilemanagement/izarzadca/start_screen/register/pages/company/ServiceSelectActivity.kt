package pl.mobilemanagement.izarzadca.start_screen.register.pages.company

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.databinding.ActivityServicesSelectionBinding
import pl.mobilemanagement.izarzadca.start_screen.register.pages.company.model.ServiceItem


class ServiceSelectActivity : AppCompatActivity(), SelectServiceAdapter.OnItemCheckedChange, View.OnClickListener {

    private lateinit var binding: ActivityServicesSelectionBinding

    private val adapter = SelectServiceAdapter(emptyList(), this)
    private var serviceList = emptyList<ServiceItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityServicesSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.save.setOnClickListener(this)
        binding.backArrow.setOnClickListener(this)

        val checkedItemIds = intent.getStringArrayExtra(ARG_CHECKED_SERVICES).orEmpty()

        serviceList = if(savedInstanceState == null)
            intent.getParcelableArrayExtra(ARG_SERVICES).orEmpty().map {
                (it as ServiceItem).copy(checked = checkedItemIds.contains(it.serviceId))
            }
        else
            savedInstanceState.getParcelableArray(ARG_SERVICES).orEmpty().map { it as ServiceItem }

        adapter.submitList(serviceList)
        binding.serviceList.adapter = adapter

        val dividerItemDecoration = DividerItemDecoration(
                binding.serviceList.context,
                (binding.serviceList.layoutManager as LinearLayoutManager).orientation
        )
        binding.serviceList.addItemDecoration(dividerItemDecoration)

        binding.search.doAfterTextChanged { query ->
            val newItems = serviceList.filter {
                it.text.lowercase().contains(query?.toString().orEmpty().lowercase())
            }
            adapter.submitList(newItems)
        }
    }

    override fun onChange(item: ServiceItem, checked: Boolean) {
        serviceList = serviceList.map {
            if(it == item) it.copy(checked = checked)
            else it
        }
        adapter.submitList(serviceList)
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        super.onSaveInstanceState(outState, outPersistentState)
        outState.putParcelableArray(ARG_SERVICES, serviceList.toTypedArray())
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.save -> {
                val intent = Intent().apply {
                    putExtra(ARG_SERVICES, serviceList.filter { it.checked }.toTypedArray())
                }
                setResult(RESULT_OK, intent)
                finish()
            }
            R.id.backArrow -> finish()
        }
    }

    companion object {
        const val ARG_SERVICES = "ARG_SERVICES"
        const val ARG_CHECKED_SERVICES = "ARG_CHECKED_SERVICES"
        const val REQ_SERVICES_RESULT = 90
    }

}