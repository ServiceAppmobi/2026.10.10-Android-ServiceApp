package pl.mobilemanagement.izarzadca.tabs.orderservice;

import androidx.appcompat.app.AppCompatActivity;

public class ProviderDetailActivity extends AppCompatActivity {
}
