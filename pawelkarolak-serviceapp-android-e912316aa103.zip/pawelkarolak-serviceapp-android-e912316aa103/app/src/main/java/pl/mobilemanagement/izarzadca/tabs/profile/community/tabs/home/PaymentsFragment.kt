package pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home

import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import pl.mobilemanagement.izarzadca.R
import pl.mobilemanagement.izarzadca.tabs.profile.community.tabs.home.models.Payment

class PaymentsFragment : Fragment() {

    private val paymentsAdapter by lazy {
        PaymentsAdapter(emptyList())
    }

    var paymentsList = emptyList<Payment>()

    private var lastTitle = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lastTitle = requireActivity().title.toString()
        requireActivity().setTitle(R.string.menu_documents_bills)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val recyclerView = RecyclerView(requireContext())
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        paymentsAdapter.update(paymentsList)
        recyclerView.adapter = paymentsAdapter
        return recyclerView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            val margin = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 16f, resources.displayMetrics).toInt()
            marginStart = margin
            marginEnd = margin
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        requireActivity().title = lastTitle
    }

}